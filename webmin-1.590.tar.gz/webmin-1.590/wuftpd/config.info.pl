ftpd_path=Pe�na �cie�ka do <tt>wuftpd</tt>,0
ftpaccess=Pe�na �cie�ka do pliku <tt>ftpaccess</tt>,0
ftpconversions=Pe�na �cie�ka do pliku <tt>ftpconversions</tt>,0
ftpgroups=Pe�na �cie�ka do pliku <tt>ftpgroups</tt>,0
ftphosts=Pe�na �cie�ka do pliku <tt>ftphosts</tt>,0
ftpusers=Pe�na �cie�ka do pliku <tt>ftpusers</tt>,0
pid_file=Plik z&nbsp;numerem PID serwera FTP,0
