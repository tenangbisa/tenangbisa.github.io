sshd_path=Pe�na �cie�ka do programu <tt>sshd</tt>,0
sshd_config=Pe�na �cie�ka do pliku konfiguracyjnego sshd,0
client_config=Pe�na �cie�ka do pliku konfiguracyjnego klienta ssh,0
pid_file=Pe�na �cie�ka do pliku z&nbsp;numerem PID sshd,0
start_cmd=Polecenie uruchamiaj�ce sshd,3,Po prostu uruchomi� serwer
