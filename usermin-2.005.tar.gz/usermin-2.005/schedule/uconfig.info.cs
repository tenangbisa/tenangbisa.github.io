sort_mode=Třídit zprávy podle,1,0-pořadí vytvoření,1-Času přeposlání,2-Příjemce
