desc_cs=Naplánovaná pošta
