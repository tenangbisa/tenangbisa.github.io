desc_cs=Uživatelské příkazy
