desc_pl=Wybrane polecenia
