desc_pl=Apache - opcje htaccess
