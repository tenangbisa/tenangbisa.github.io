
require 'virtual-server-lib.pl';

# acl_security_form(&options)
# Output HTML for editing security options for the virtual server module
sub acl_security_form
{
print "<tr> <td valign=top rowspan=4><b>$text{'acl_domains'}</b></td>\n";
printf "<td rowspan=4><input type=radio name=domains_def value=1 %s> %s\n",
	$_[0]->{'domains'} eq '*' ? "checked" : "", $text{'acl_all'};
printf "<input type=radio name=domains_def value=0 %s> %s<br>\n",
	$_[0]->{'domains'} eq '*' ? "" : "checked", $text{'acl_sel'};
local %doms = map { $_, 1 } split(/\s+/, $_[0]->{'domains'});
print "<select name=domains multiple size=5>\n";
local $d;
foreach $d (&list_domains()) {
	printf "<option value=%s %s>%s\n",
		$d->{'id'}, $doms{$d->{'id'}} ? "selected" : "", $d->{'dom'};
	}
print "</select></td>\n";

foreach $q ('create', 'import', 'edit', 'local', 'stop') {
	print "<td><b>",$text{'acl_'.$q},"</b></td>\n";
	printf "<td><input type=radio name=%s value=1 %s> %s\n",
		$q, $_[0]->{$q} ? "checked" : "", $text{'yes'};
	printf "<input type=radio name=%s value=0 %s> %s</td> </tr>\n",
		$q, $_[0]->{$q} ? "" : "checked", $text{'no'};
	}
}

# acl_security_save(&options)
# Parse the form for security options for the useradmin module
sub acl_security_save
{
$_[0]->{'domains'} = $in{'domains_def'} ? "*" :
			join(" ", split(/\0/, $in{'domains'}));
$_[0]->{'create'} = $in{'create'};
$_[0]->{'import'} = $in{'import'};
$_[0]->{'edit'} = $in{'edit'};
$_[0]->{'local'} = $in{'local'};
$_[0]->{'stop'} = $in{'stop'};
}

