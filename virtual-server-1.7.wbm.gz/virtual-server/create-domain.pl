#!/usr/local/bin/perl
# create-domain.pl
# Adds a new virtual host, based on command-line parameters

$no_acl_check++;
$ENV{'WEBMIN_CONFIG'} ||= "/etc/webmin";
$ENV{'WEBMIN_VAR'} ||= "/var/webmin";
if ($0 =~ /^(.*\/)[^\/]+$/) {
	chdir($1);
	}
chop($pwd = `pwd`);
$0 = "$pwd/create-domain.pl";
require './virtual-server-lib.pl';
$< == 0 || die "create-domain.pl must be run as root";
&require_apache();
&require_bind();
&require_useradmin();
&require_mail();
&require_mysql();
&require_acl();

$first_print = \&first_text_print;
$second_print = \&second_text_print;

# Parse command-line args
$name = 1;
while(@ARGV > 0) {
	local $a = shift(@ARGV);
	if ($a eq "--domain") {
		$domain = lc(shift(@ARGV));
		}
	elsif ($a eq "--desc") {
		$owner = shift(@ARGV);
		}
	elsif ($a eq "--email") {
		$email = shift(@ARGV);
		}
	elsif ($a eq "--user") {
		$user = lc(shift(@ARGV));
		}
	elsif ($a eq "--pass") {
		$pass = shift(@ARGV);
		}
	elsif ($a eq "--quota") {
		$quota = shift(@ARGV);
		}
	elsif ($a eq "--uquota") {
		$uquota = shift(@ARGV);
		}
	elsif ($a eq "--mail") {
		$config{'mail'} || die "The --mail option cannot be used unless mailboxes and aliases are enabled in the module configuration";
		$mail++;
		}
	elsif ($a eq "--web") {
		$config{'web'} || die "The --web option cannot be used unless Apache is enabled in the module configuration";
		$web++;
		}
	elsif ($a eq "--dns") {
		$config{'dns'} || die "The --dns option cannot be used unless BIND is enabled in the module configuration";
		$dns++;
		}
	elsif ($a eq "--mysql") {
		$config{'mysql'} || die "The --mysql option cannot be used unless MySQL is enabled in the module configuration";
		$mysql++;
		}
	elsif ($a eq "--postgres") {
		$config{'postgres'} || die "The --postgres option cannot be used unless PostgreSQL is enabled in the module configuration";
		$postgres++;
		}
	elsif ($a eq "--webalizer") {
		$config{'webalizer'} || die "The --webalizer option cannot be used unless Webalizer is enabled in the module configuration";
		$webalizer++;
		}
	elsif ($a eq "--webmin") {
		$webmin++;
		}
	elsif ($a eq "--ip") {
		$ip = shift(@ARGV);
		$virt++;
		$name = 0;
		}
	elsif ($a eq "--mailboxlimit") {
		$mailboxlimit = shift(@ARGV);
		}
	}

# Make sure all needed args are set
$domain && $pass || &usage();
if ($config{'home_quotas'}) {
	$quota && $uquota || &usage();
	}

# Validate args and work out defaults for those unset
$domain =~ /^[A-Za-z0-9\.\-]+$/ || die($text{'setup_edomain'});
foreach $d (&list_domains()) {
        die($text{'setup_edomain2'}) if (lc($d->{'dom'}) eq lc($domain));
        }
if (!$user) {
	$domain =~ /^([^\.]+)/;
        $try1 = $user = $1;
        if (defined(getpwnam($1)) || $config{'longname'}) {
                $user = $domain;
                $try2 = $user;
                if (defined(getpwnam($user))) {
                        die(&text('setup_eauto', $try1, $try2));
                        }
                }
	}
else {
	$user =~ /^[^\t :]+$/ || die($text{'setup_euser2'});
	defined(getpwnam($user)) && die($text{'setup_euser'});
	}
if ($ip) {
	&check_ipaddress($ip) || die($text{'setup_eip'});
	}
else {
	$ip = &get_default_ip();
	}
$owner ||= $domain;
!defined($mailboxlimit) || $mailboxlimit =~ /^[1-9]\d*$/ ||
	die($text{'setup_emailboxlimit'});

# Work out group name
defined(getgrnam($user)) && die(&text('setup_egroup', $user));
$home_base || die($text{'setup_ehomebase'});
if ($config{'home_quotas'}) {
        $quota =~ /^\d+$/ || die($text{'setup_equota'});
        $uquota =~ /^\d+$/ || die($text{'setup_euquota'});
        }
($db = $user) =~ s/[\.\-]/_/g;

# Check for various clashes
$dns && &check_bind_clash($dom) &&
        die($text{'setup_edns'});
$web && &check_apache_clash($dom) &&
        die($text{'setup_eweb'});
$mysql && &check_mysql_clash($db) &&
        die(&text('setup_emysql', $db));
$postgres && &check_postgres_clash($db) &&
        die(&text('setup_epostgres', $db));
$webmin && &check_webmin_clash($user) &&
        die(&text('setup_ewebmin', $user));

# Make sure default Apache directives are sensible
!web || !($err = &check_apache_directives()) ||
	die(&text('setup_edirectives', $err));

# Check if we have the virtual interface
&foreign_require("net", "net-lib.pl");
@boot = &net::boot_interfaces();
@active = &net::active_interfaces();
($got) = grep { $_->{'address'} eq $ip } @active;
if ($virt && !$got) {
        ($iface) = grep { $_->{'fullname'} eq $config{'iface'} } @boot;
        die(&text('setup_eiface', $config{'iface'})) if (!$iface);
        die(&text('setup_eiface2', $config{'iface'}))
                if (!$iface->{'address'});
        }

print "Beginning domain creation ..\n\n";

# Work out user and group IDs
&build_group_taken(\%gtaken, \%ggtaken);
$gid = &allocate_gid(\%gtaken);
$ugid = $gid;
&build_taken(\%taken, \%utaken);
$uid = &allocate_uid(\%taken);

# Build up domain object
%dom = ( 'dom', $domain,
         'user', $user,
         'group', $user,
         'ugroup', $user,
         'quota', $quota,
         'uquota', $uquota,
         'uid', $uid,
         'gid', $gid,
         'ugid', $gid,
         'owner', $owner,
         'email', $email,
         'mail', $mail,
         'web', $web,
         'webalizer', $webalizer,
         'mysql', $mysql,
         'postgres', $postgres,
         'webmin', $webmin,
         'name', $name,
         'ip', $ip,
         'dns', $dns,
         'pass', $pass,
         'db', $db,
         'mailboxlimit', $mailboxlimit,
	 'source', 'create-domain.pl'
        );

# Work out home directory
$dom{'home'} = &server_home_directory(\%dom);

# Run the before command
&set_domain_envs(\%dom, "CREATE_DOMAIN");
$merr = &making_changes();
if (defined($merr)) {
	print "Before creation command failed : $merr\n";
	exit 1;
	}

# Create the Unix group
print &text('setup_group', $user),"\n";
&useradmin::lock_user_files();
%ginfo = ( 'group', $user,
           'gid', $gid );
&useradmin::set_group_envs(\%ginfo, 'CREATE_GROUP');
&useradmin::making_changes();
&useradmin::create_group(\%ginfo);
&useradmin::made_changes();
print $text{'setup_done'},"\n\n";

# Create the Unix user
print &text('setup_user', $user),"\n";
%uinfo = ( 'user', $user,
           'uid', $uid,
           'gid', $gid,
           'pass', &useradmin::encrypt_password($pass),
           'real', $owner,
           'home', $dom{'home'},
           'shell', $config{'unix_shell'} );
&set_pass_change(\%uinfo);
&useradmin::set_user_envs(\%uinfo, 'CREATE_USER', $pass, [ ]);
&useradmin::making_changes();
&useradmin::create_user(\%uinfo);
&useradmin::made_changes();
&useradmin::unlock_user_files();
print $text{'setup_done'},"\n\n";

if ($config{'home_quotas'}) {
        # Set his quota
        print $text{'setup_quota'},"\n";
	&set_server_quotas(\%dom);
        print $text{'setup_done'},"\n";
        }

# Create his home directory, and copy files into it
print $text{'setup_home'},"\n";
&system_logged("mkdir '$uinfo{'home'}'");
&system_logged("chmod '$uconfig{'homedir_perms'}' '$uinfo{'home'}'");
&system_logged("chown $uid:$gid '$uinfo{'home'}'");
&copy_skel_files($config{'virtual_skel'}, \%uinfo, $user);

# Setup web directories
foreach $d ( [ $config{'html_dir'} || 'public_html', '755' ],
             [ 'cgi-bin', '755' ],
             [ 'logs', '755' ],
             [ 'homes', '755' ] ) {
        &system_logged("mkdir '$uinfo{'home'}/$d->[0]' 2>/dev/null");
        &system_logged("chmod $d->[1] '$uinfo{'home'}/$d->[0]'");
        &system_logged("chown $uid:$gid '$uinfo{'home'}/$d->[0]'");
        }
print $text{'setup_done'},"\n\n";

if ($mail) {
	# Add domain to the local domains list
	&setup_mail(\%dom);
	}

if ($web) {
        # Create the website as www.domain and domain
        &setup_apache(\%dom);
        &restart_apache();
        }

if ($webalizer) {
        # Set up webalizer on the logs
        &setup_webalizer(\%dom);
        }

if ($dns) {
        # Add to BIND config
        &setup_bind(\%dom);
        &restart_bind(\%dom);
        }
 
if ($mysql) {
        # Create MySQL database
        &setup_mysql(\%dom);
        }
 
if ($postgres) {
        # Create PostgreSQL database
        &setup_postgres(\%dom);
        }
 
# Add virtual IP address, if needed
if ($virt && !$got) {
        print $text{'setup_virt'},"\n";
        local $vmax = 0;
        foreach $b (@boot) {
                $vmax = $b->{'virtual'}
                        if ($b->{'name'} eq $iface->{'name'} &&
                            $b->{'virtual'} > $vmax);
                }
        $virt = { 'address' => $ip,
                  'netmask' =>
                        $net::virtual_netmask || $iface->{'netmask'},
                  'broadcast' =>
                        $net::virtual_netmask eq "255.255.255.255" ?
                                $ip : $iface->{'broadcast'},
                  'name' => $iface->{'name'},
                  'virtual' => $vmax+1,
                  'up' => 1 };
        $virt->{'fullname'} = $virt->{'name'}.":".$virt->{'virtual'};
        &net::save_interface($virt);
        &net::activate_interface($virt);
        $virtiface = $virt->{'fullname'};
        print $text{'setup_done'},"\n\n";
        }

# Save domain details
print $text{'setup_save'},"\n";
$dom{'iface'} = $virtiface;
&save_domain(\%dom);
print $text{'setup_done'},"\n\n";
 
if ($webmin) {
        # Create Webmin user to manage domain
        &setup_webmin(\%dom);
        &restart_webmin();
        }

# Notify the owner via email
&send_domain_email(\%dom);

# Run the after creation command
&made_changes();

print "All done!\n";

sub usage
{
print "Adds a new Virtualmin virtual server, with the settings and features\n";
print "specified on the command line.\n";
print "\n";
print "usage: create-domain.pl  --domain domain.name\n";
print "                         --pass password-for-unix-user\n";
print "                        [--desc description-for-domain]\n";
print "                        [--email contact-email]\n";
print "                        [--user new-unix-user]\n";
print "                        [--mail]\n";
print "                        [--web]\n";
print "                        [--webalizer]\n";
print "                        [--dns]\n";
print "                        [--mysql]\n";
print "                        [--postgres]\n";
print "                        [--webmin]\n";
print "                        [--ip virtual.ip.address]\n";
print "                        [--mailboxlimit boxes]\n";
if ($config{'home_quotas'}) {
	print "                         --quota quota-for-domain]\n";
	print "                         --uquota quota-for-unix-user]\n";
	}
exit(1);
}

sub first_text_print
{
print @_,"\n";
}

sub second_text_print
{
print @_,"\n\n";
}

