# virtual-server-lib.pl
# Common functions for Virtualmin
# XXX qmail support
#	XXX importing
#	XXX stop/start server
#	XXX user aliases
#	XXX all use of mail_system
#	XXX test all the alias types
#	XXX qmail not accepting mail! (works for users, not aliases?)
#	XXX 'all mailboxes' support (use default)

do '../web-lib.pl';
&init_config();
%access = &get_module_acl();
$single_domain_mode = $access{'domains'} =~ /^\d+$/ &&
		      !$access{'edit'} && !$access{'create'} &&
		      !$access{'stop'} && !$access{'local'};
if ($access{'noconfig'}) {
	# Allowed alias types are set by module config
	%can_alias_types = map { $_, 1 } split(/,/, $config{'alias_types'});
	}
else {
	# All types are allowed
	%can_alias_types = map { $_, 1 } (0 .. 7);
	}

$first_print = \&first_html_print;
$second_print = \&second_html_print;

@features = ( 'mail', 'web', 'webalizer', 'mysql', 'postgres', 'dns', 'webmin' );

sub require_apache
{
return if ($require_apache++);
&foreign_require("apache", "apache-lib.pl");
%aconfig = &foreign_config("apache");
}

sub require_bind
{
return if ($require_bind++);
&foreign_require("bind8", "bind8-lib.pl");
%bconfig = &foreign_config("bind8");
}

sub require_useradmin
{
return if ($require_useradmin++);
&foreign_require("useradmin", "user-lib.pl");
%uconfig = &foreign_config("useradmin");
&foreign_require("quota", "quota-lib.pl");
$home_base = $config{'home_base'} || $uconfig{'home_base'};
}

sub require_mail
{
return if ($require_mail++);
if ($config{'mail_system'} == 1) {
	# Using sendmail for email
	&foreign_require("sendmail", "sendmail-lib.pl");
	&foreign_require("sendmail", "virtusers-lib.pl");
	&foreign_require("sendmail", "aliases-lib.pl");
	&foreign_require("sendmail", "boxes-lib.pl");
	%sconfig = &foreign_config("sendmail");
	$sendmail_conf = &sendmail::get_sendmailcf();
	$sendmail_vfile = &sendmail::virtusers_file($sendmail_conf);
	($sendmail_vdbm, $sendmail_vdbmtype) =
		&sendmail::virtusers_dbm($sendmail_conf);
	$sendmail_afiles = &sendmail::aliases_file($sendmail_conf);
	}
elsif ($config{'mail_system'} == 0) {
	# Using postfix for email
	&foreign_require("postfix", "postfix-lib.pl");
	&foreign_require("postfix", "boxes-lib.pl");
	%pconfig = &foreign_config("postfix");
	$virtual_type = $postfix::virtual_maps || "virtual_maps";
	$virtual_maps = &postfix::get_current_value($virtual_type);
	$postfix_afiles = [ &postfix::get_aliases_files(
				&postfix::get_current_value("alias_maps")) ];
	}
elsif ($config{'mail_system'} == 2) {
	# Using qmail for email
	&foreign_require("qmailadmin", "qmail-lib.pl");
	%qmconfig = &foreign_config("qmailadmin");
	$can_alias_types{2} = 0;
	$can_alias_types{7} = 0;
	}
}

sub require_mysql
{
return if ($require_mysql++);
&foreign_require("mysql", "mysql-lib.pl");
%mconfig = &foreign_config("mysql");
}

sub require_acl
{
return if ($require_acl++);
&foreign_require("acl", "acl-lib.pl");
}

sub require_webalizer
{
return if ($require_webalizer++);
&foreign_require("webalizer", "webalizer-lib.pl");
%wconfig = &foreign_config("webalizer");
}

sub require_postgres
{
return if ($require_postgres++);
&foreign_require("postgresql", "postgresql-lib.pl");
%qconfig = &foreign_config("postgresql");
}

$domains_dir = "$module_config_directory/domains";

# list_domains()
# Returns a list of structures containing information about hosted domains
sub list_domains
{
local (@rv, $d);
opendir(DIR, $domains_dir);
foreach $d (readdir(DIR)) {
	if ($d !~ /^\./) {
		push(@rv, &get_domain($d));
		}
	}
closedir(DIR);
return @rv;
}

# get_domain(id)
sub get_domain
{
local %dom;
&read_file("$domains_dir/$_[0]", \%dom) || return undef;
$dom{'id'} = $_[0];
$dom{'mail'} = 1 if (!defined($dom{'mail'}));	# compat - assume mail is on
$dom{'ugid'} = $dom{'gid'} if (!defined($dom{'ugid'}));	# compat - assume same
if ($dom{'disabled'} eq '1') {
	# compat - assume everything was disabled
	$dom{'disabled'} = "user,web,dns,mail,mysql,postgres";
	}
if (!defined($dom{'created'})) {
        $dom{'id'} =~ /^(\d{10})/;
        $dom{'created'} = $1;
        }
if (!defined($dom{'gid'})) {
	# compat - get GID from group name
	$dom{'gid'} = getgrnam($dom{'group'});
	}
return \%dom;
}

# get_domain_by(field, value)
sub get_domain_by
{
local $d;
foreach $d (&list_domains()) {
	if ($d->{$_[0]} eq $_[1]) {
		return $d;
		}
	}
return undef;
}

# save_domain(&domain)
sub save_domain
{
mkdir($domains_dir, 0700);
$_[0]->{'id'} = time().$$ if (!$_[0]->{'id'});
$_[0]->{'created'} = time() if (!$_[0]->{'created'});
&write_file("$domains_dir/$_[0]->{'id'}", $_[0]) || return 0;
return 1;
}

# delete_domain(&domain)
sub delete_domain
{
unlink("$domains_dir/$_[0]->{'id'}");
}

# list_domain_users(&domain, [skipunix])
# List all Unix users who are in the domain's primary group, except the owner
sub list_domain_users
{
# Get all aliases to look for those that match users
local %aliases;
if ($config{'mail'}) {
	&require_mail();
	if ($config{'mail_system'} == 1) {
		%aliases = map { $_->{'name'}, $_ } grep { $_->{'enabled'} }
			       &sendmail::list_aliases($sendmail_afiles);
		}
	elsif ($config{'mail_system'} == 0) {
		%aliases = map { $_->{'name'}, $_ }
			       &postfix::list_aliases($postfix_afiles);
		}
	}

# Get all virtusers to look for those for users
local @virts = &list_virtusers();

local @users = &list_all_users_quotas();
@users = grep { $_->{'gid'} == $_[0]->{'gid'} ||
		($_->{'user'} eq $_[0]->{'user'} && !$_[1]) } @users;
foreach $u (@users) {
	if ($aliases{$u->{'user'}}) {
		$u->{'alias'} = $aliases{$u->{'user'}};
		$u->{'to'} = $u->{'alias'}->{'values'};
		}
	local $pop3 = &remove_userdom($u->{'user'}, $_[0]);
	local $email = "$pop3\@$_[0]->{'dom'}";
	foreach $v (@virts) {
		if (@{$v->{'to'}} == 1 && $v->{'to'}->[0] eq $u->{'user'}) {
			if ($v->{'from'} eq $email) {
				$u->{'email'} = $email;
				$u->{'virt'} = $v;
				}
			else {
				push(@{$u->{'extraemail'}}, $v->{'from'});
				push(@{$u->{'extravirt'}}, $v);
				}
			}
		}
	}
return @users;
}

# list_all_users_quotas()
# Returns a list of all Unix users, with quota info
sub list_all_users_quotas
{
# Get quotas for all users
&require_useradmin();
local $qv = $config{'hard_quotas'} ? 'hblocks' : 'sblocks';
if (!defined(%home_quotas) && $config{'home_quotas'}) {
	local $n = &quota::filesystem_users($config{'home_quotas'});
	local $i;
	for($i=0; $i<$n; $i++) {
		$home_quota{$quota::user{$i,'user'}} = $quota::user{$i,$qv};
		$used_home_quota{$quota::user{$i,'user'}} =
			$quota::user{$i,'ublocks'};
		}
	}
if (!defined(%mail_quotas) && $config{'mail_quotas'} &&
    $config{'mail_quotas'} ne $config{'home_quotas'}) {
	local $n = &quota::filesystem_users($config{'mail_quotas'});
	local $i;
	for($i=0; $i<$n; $i++) {
		$mail_quota{$quota::user{$i,'user'}} = $quota::user{$i,$qv};
		$used_mail_quota{$quota::user{$i,'user'}} =
			$quota::user{$i,'ublocks'};
		}
	}

# Get user list and add in quota info
local @users = &useradmin::list_users();
local $u;
foreach $u (@users) {
	$u->{'quota'} = $home_quota{$u->{'user'}};
	$u->{'uquota'} = $used_home_quota{$u->{'user'}};
	$u->{'mquota'} = $mail_quota{$u->{'user'}};
	$u->{'umquota'} = $used_mail_quota{$u->{'user'}};
	}
return @users;
}

# create_user(&user, &domain)
# Create a mailbox user, his virtuser and possibly his alias
sub create_user
{
&require_useradmin();
&require_mail();

# Add the user
&useradmin::set_user_envs($_[0], 'CREATE_USER', $_[0]->{'plainpass'}, [ ]);
&useradmin::making_changes();
&useradmin::create_user($_[0]);
&useradmin::made_changes();

# Add his virtusers addresses
if ($_[0]->{'email'}) {
	local $virt = { 'from' => $_[0]->{'email'},
			'to' => [ $_[0]->{'user'} ] };
	&create_virtuser($virt);
	$_[0]->{'virt'} = $virt;
	}
local @extravirt;
foreach $e (@{$_[0]->{'extraemail'}}) {
	local $virt = { 'from' => $e,
			'to' => [ $_[0]->{'user'} ] };
	&create_virtuser($virt);
	push(@extravirt, $virt);
	}
$_[0]->{'extravirt'} = \@extravirt;

# Add his alias, if any
if ($_[0]->{'to'}) {
	local $alias = { 'name' => $_[0]->{'user'},
			 'enabled' => 1,
			 'values' => $_[0]->{'to'} };
	if ($config{'mail_system'} == 1) {
		&sendmail::create_alias($alias, $sendmail_afiles);
		}
	elsif ($config{'mail_system'} == 0) {
		&postfix::create_alias($alias, $postfix_afiles);
		&postfix::regenerate_aliases();
		}
	elsif ($config{'mail_system'} == 2) {
		# XXX
		}
	$_[0]->{'alias'} = $alias;
	}
}

# modify_user(&user, &old, &domain)
sub modify_user
{
&require_useradmin();
&require_mail();

# Update the unix user
&useradmin::set_user_envs($_[0], 'MODIFY_USER', $_[0]->{'plainpass'});
&useradmin::making_changes();
&useradmin::modify_user($_[1], $_[0]);
&useradmin::made_changes();

# Take away all virtusers and add new ones
&delete_virtuser($_[1]->{'virt'}) if ($_[1]->{'virt'});
local $e;
foreach $e (@{$_[1]->{'extravirt'}}) {
	&delete_virtuser($e);
	}
if ($_[0]->{'email'}) {
	local $virt = { 'from' => $_[0]->{'email'},
			'to' => [ $_[0]->{'user'} ] };
	&create_virtuser($virt);
	$_[0]->{'virt'} = $virt;
	}
local @extravirt;
foreach $e (@{$_[0]->{'extraemail'}}) {
	local $virt = { 'from' => $e,
			'to' => [ $_[0]->{'user'} ] };
	&create_virtuser($virt);
	push(@extravirt, $virt);
	}
$_[0]->{'extravirt'} = \@extravirt;

# Update, create or delete alias
if ($_[0]->{'to'} && !$_[1]->{'to'}) {
	# Need to add alias
	local $alias = { 'name' => $_[0]->{'user'},
			 'enabled' => 1,
			 'values' => $_[0]->{'to'} };
	if ($config{'mail_system'} == 1) {
		&sendmail::create_alias($alias, $sendmail_afiles);
		}
	elsif ($config{'mail_system'} == 0) {
		&postfix::create_alias($alias, $postfix_afiles);
		&postfix::regenerate_aliases();
		}
	$_[0]->{'alias'} = $alias;
	}
elsif (!$_[0]->{'to'} && $_[1]->{'to'}) {
	# Need to delete alias
	if ($config{'mail_system'} == 1) {
		&sendmail::delete_alias($_[0]->{'alias'});
		}
	elsif ($config{'mail_system'} == 0) {
		&postfix::delete_alias($_[0]->{'alias'});
		&postfix::regenerate_aliases();
		}
	}
elsif ($_[0]->{'to'} && $_[1]->{'to'}) {
	# Need to update the alias
	local $alias = { 'name' => $_[0]->{'user'},
			 'enabled' => 1,
			 'values' => $_[0]->{'to'} };
	if ($config{'mail_system'} == 1) {
		&sendmail::modify_alias($_[1]->{'alias'}, $alias);
		}
	elsif ($config{'mail_system'} == 0) {
		&postfix::modify_alias($_[1]->{'alias'}, $alias);
		&postfix::regenerate_aliases();
		}
	$_[0]->{'alias'} = $alias;
	}
}

# delete_user(&user, domain)
# Delete a mailbox user and all associated virtusers and aliases
sub delete_user
{
$_[0]->{'user'} eq 'root' && &error("Cannot delete root user!");
$_[0]->{'uid'} == 0 && &error("Cannot delete UID 0 user!");
&require_useradmin();
&require_mail();

# Delete the user
&useradmin::set_user_envs($_[0], 'DELETE_USER')
&useradmin::making_changes();
&useradmin::delete_user($_[0]);
&useradmin::made_changes();

# Delete any virtusers
&delete_virtuser($_[0]->{'virt'}) if ($_[0]->{'virt'});
local $e;
foreach $e (@{$_[0]->{'extravirt'}}) {
	&delete_virtuser($e);
	}

# Delete his alias, if any
if ($_[0]->{'alias'}) {
	if ($config{'mail_system'} == 1) {
		&sendmail::delete_alias($_[0]->{'alias'});
		}
	elsif ($config{'mail_system'} == 0) {
		&postfix::delete_alias($_[0]->{'alias'});
		&postfix::regenerate_aliases();
		}
	}
}

# list_domain_aliases(&domain)
sub list_domain_aliases
{
&require_mail();
local $g = $_[0]->{'group'};
local ($u, %foruser);
foreach $u (&list_domain_users($_[0])) {
	local $pop3 = &remove_userdom($u->{'user'}, $_[0]);
	$foruser{$pop3."\@".$_[0]->{'dom'}} = $u->{'user'};
	}
if ($d->{'mailbox'}) {
	$foruser{$d->{'user'}."\@".$_[0]->{'dom'}} = $d->{'user'};
	}
local @virts = &list_virtusers();
return grep { $_->{'from'} =~ /\@(\S+)$/ && $1 eq $_[0]->{'dom'} &&
	      ($foruser{$_->{'from'}} ne $_->{'to'}->[0] ||
	       @{$_->{'to'}} != 1) } @virts;
}

# setup_mail(&domain)
# Adds a domain to the list of those accepted by the mail system
sub setup_mail
{
&$first_print($text{'setup_doms'});
&require_mail();
if ($config{'mail_system'} == 1) {
	# Just add to sendmail local domains file
	local $cwfile = &sendmail_locals_file();
	open(LOCALS, ">>$cwfile");
	print LOCALS $_[0]->{'dom'},"\n";
	close(LOCALS);
	&sendmail::restart_sendmail();
	}
elsif ($config{'mail_system'} == 0) {
	# Add a special postfix virtual entry just for the domain
	&create_virtuser({ 'from' => $_[0]->{'dom'}, 'to' => [ 'anything' ] });
	}
elsif ($config{'mail_system'} == 2) {
	# Add to qmail locals file, rcpthosts file  and virtualdomains file
	local $dlist = &qmailadmin::list_control_file("locals");
	push(@$dlist, $_[0]->{'dom'});
	&qmailadmin::save_control_file("locals", $dlist);

	local $rlist = &qmailadmin::list_control_file("rcpthosts");
	push(@$rlist, $_[0]->{'dom'});
	&qmailadmin::save_control_file("rcpthosts", $rlist);

	local $virtmap = { 'domain' => $_[0]->{'dom'},
			   'prepend' => $_[0]->{'group'} };
	&qmailadmin::create_virt($virtmap);
	&qmailadmin::restart_qmail();
	}
&$second_print($text{'setup_done'});
}

# delete_mail(&domain)
# Removes a domain from the list of those accepted by the mail system
sub delete_mail
{
&$first_print($text{'delete_doms'});
&require_mail();
if ($config{'mail_system'} == 1) {
	# Delete domain from sendmail local domains file
	local $cwfile = &sendmail_locals_file();
	local @locals;
	open(LOCALS, $cwfile);
	while(<LOCALS>) {
		s/\r|\n//;
		push(@locals, "$_\n") if ($_ ne $_[0]->{'dom'});
		}
	close(LOCALS);
	open(LOCALS, ">$cwfile");
	print LOCALS @locals;
	close(LOCALS);
	&sendmail::restart_sendmail();
	}
elsif ($config{'mail_system'} == 0) {
	# Delete the special postfix virtuser
	local @virts = &list_virtusers();
	local ($lv) = grep { $_->{'from'} eq $_[0]->{'dom'} } @virts;
	if ($lv) {
		&delete_virtuser($lv);
		}
	local @md = split(/[, ]+/,&postfix::get_current_value("mydestination"));
	local $idx = &indexof($_[0]->{'dom'}, @md);
	if ($idx >= 0) {
		# Delete old-style entry too
		splice(@md, $idx, 1);
		&postfix::set_current_value("mydestination", join(", ", @md));
		&shutdown_mail_server();
		&startup_mail_server();
		}
	}
elsif ($config{'mail_system'} == 2) {
	# Delete domain from qmail locals file, rcpthosts file and virtuals
	local $dlist = &qmailadmin::list_control_file("locals");
	$dlist = [ grep { $_ ne $_[0]->{'dom'} } @$dlist ];
	&qmailadmin::save_control_file("locals", $dlist);

	local $rlist = &qmailadmin::list_control_file("rcpthosts");
	$rlist = [ grep { $_ ne $_[0]->{'dom'} } @$rlist ];
	&qmailadmin::save_control_file("rcpthosts", $rlist);

	local ($virtmap) = grep { $_->{'domain'} eq $_[0]->{'dom'} &&
				  !$_->{'user'} } &qmailadmin::list_virts();
	&qmailadmin::delete_virt($virtmap) if ($virtmap);
	&qmailadmin::restart_qmail();
	}
&$second_print($text{'setup_done'});
}

# modify_mail(&domain, &olddomain)
# Deal with a change in domain name
sub modify_mail
{
if ($_[0]->{'dom'} ne $_[1]->{'dom'}) {
	&delete_mail($_[1]);
	&setup_mail($_[0]);
	}
}

# disable_mail(&domain)
# Same as deleting ..
sub disable_mail
{
&delete_mail($_[0]);
}

# enable_mail(&domain)
# Same as setting up ..
sub enable_mail
{
&setup_mail($_[0]);
}

# is_local_domain(domain)
# Returns 1 if some domain is used for mail on this system, 0 if not
sub is_local_domain
{
local $found = 0;
if ($config{'mail_system'} == 1) {
	# Check Sendmail local domains file
	local $cwfile = &sendmail_locals_file();
	open(CW, $cwfile);
	while(<CW>) {
		s/\r|\n//;
		$found++ if ($_ eq $_[0]);
		}
	close(CW);
	}
elsif ($config{'mail_system'} == 0) {
	# Check Postfix virtusers and mydestination
	local @virts = &list_virtusers();
	local ($lv) = grep { $_->{'from'} eq $_[0] } @virts;
	$found++ if ($lv);
	local @md = split(/[, ]+/,&postfix::get_current_value("mydestination"));
	$found++ if (&indexof($_[0], @md) >= 0);
	}
elsif ($config{'mail_system'} == 2) {
	# Check qmail local domains file
	local $dlist = &qmailadmin::list_control_file("locals");
	$found++ if (&indexof($_[0], @$dlist) >= 0);
	}
return $found;
}

sub sendmail_locals_file
{
local $conf = &sendmail::get_sendmailcf();
local ($f, $cwfile);
foreach $f (&sendmail::find_type("F", $conf)) {
	if ($f->{'value'} =~ /^w[^\/]*(\/\S+)/ ||
	    $f->{'value'} =~ /^\{w\}[^\/]*(\/\S+)/) { $cwfile = $1; }
	}
return $cwfile;
}

# list_virtusers()
# Returns a list of a virtual mail address mappings. Each may actually have
# an alias as its destination, and is automatically expanded to the destinations
# for that alias.
sub list_virtusers
{
# Build list of unix users, to exclude aliases with same name as users
# (which are picked up by list_domain_users instead).
&require_mail();
if (!defined(%unix_users)) {
	local $u;
	setpwent();
	while($u = getpwent()) {
		$unix_user{$u}++;
		}
	endpwent();
	}

if ($config{'mail_system'} == 1) {
	# Get from sendmail
	local @svirts = &sendmail::list_virtusers($sendmail_vfile);
	local %aliases = map { $_->{'name'}, $_ }
			 grep { $_->{'enabled'} && !$unix_user{$_->{'name'}} }
				&sendmail::list_aliases($sendmail_afiles);
	local ($v, $a, @virts);
	foreach $v (@svirts) {
		local %rv = ( 'virt' => $v,
			      'from' => $v->{'from'} );
		if ($v->{'to'} !~ /\@/ && ($a = $aliases{$v->{'to'}})) {
			# Points to an alias - use its values
			$rv{'to'} = $a->{'values'};
			$rv{'alias'} = $a;
			}
		else { 
			# Just the original value
			$rv{'to'} = [ $v->{'to'} ];
			}
		push(@virts, \%rv);
		}
	return @virts;
	}
elsif ($config{'mail_system'} == 0) {
	# Get from postfix
	local $svirts = &postfix::get_maps($virtual_type);
	local %aliases = map { $_->{'name'}, $_ }
			 grep { $_->{'enabled'} && !$unix_user{$_->{'name'}} }
			     &postfix::list_aliases($postfix_afiles);
	local ($v, $a, @virts);
	foreach $v (@$svirts) {
		local %rv = ( 'from' => $v->{'name'},
			      'virt' => $v );
		if ($v->{'value'} !~ /\@/ && ($a = $aliases{$v->{'value'}})) {
			$rv{'to'} = $a->{'values'};
			$rv{'alias'} = $a;
			}
		else {
			$rv{'to'} = [ $v->{'value'} ];
			}
		push(@virts, \%rv);
		}
	return @virts;
	}
elsif ($config{'mail_system'} == 2) {
	# Find all qmail aliases like .qmail-group-user
	local @virtmaps = grep { !$_->{'user'} } &qmailadmin::list_virts();
	local @aliases = &qmailadmin::list_aliases();
	local ($an, $v, @virts);
	foreach $an (@aliases) {
		# Find domain in virtual maps
		local $a = &qmailadmin::get_alias($an);
		local $name = $a->{'name'};
		foreach $v (@virtmaps) {
			if ($a->{'name'} =~ /^\Q$v->{'prepend'}\E\-(.*)$/) {
				$name = $1."\@".$v->{'domain'};
				}
			}
		# XXX need to change alias types?
		push(@virts, { 'from' => $name,
			       'alias' => $a,
			       'to' => [ map { s/^\&//; $_ }
					       @{$a->{'values'}} ] });
		}
	return @virts;
	}
}

# delete_virtuser(&virtuser)
# Deletes a virtual mail user mapping
sub delete_virtuser
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Delete from sendmail
	if ($_[0]->{'alias'}) {
		# Delete alias too
		&sendmail::delete_alias($_[0]->{'alias'});
		}
	&sendmail::delete_virtuser($_[0]->{'virt'}, $sendmail_vfile,
				   $sendmail_vdbm, $sendmail_vdbmtype);
	}
elsif ($config{'mail_system'} == 0) {
	# Delete from postfix file
	if ($_[0]->{'alias'}) {
		# Delete alias too
		&postfix::delete_alias($_[0]->{'alias'});
		&postfix::regenerate_aliases();
		}
	&postfix::delete_mapping($virtual_type, $_[0]->{'virt'});
	&postfix::regenerate_virtual_table();
	}
elsif ($config{'mail_system'} == 2) {
	# Just delete the qmail alias
	&qmailadmin::delete_alias($_[0]->{'alias'});
	}
}

# modify_virtuser(&old, &new)
sub modify_virtuser
{
&require_mail();
local @to = @{$_[1]->{'to'}};
if ($config{'mail_system'} == 1) {
	# Modify in sendmail
	local $alias = $_[0]->{'alias'};
	if (&needs_alias(@to) && !$alias) {
		# Alias needs to be created and virtuser updated
		$_[1]->{'from'} =~ /^(\S*)\@(\S+)$/;
		local $an = ($1 || "default")."-".$2;
		local $alias = { "name" => $an,
				 "enabled" => 1,
				 "values" => \@to };
		&sendmail::create_alias($alias, $sendmail_afiles);
		local $virt = { "from" => $_[1]->{'from'},
				"to" => $an };
		&sendmail::modify_virtuser($_[0]->{'virt'}, $virt,
					   $sendmail_vfile, $sendmail_vdbm,
					   $sendmail_vdbmtype);
		$_[0]->{'virt'} = $virt;
		}
	elsif ($alias) {
		# Just update alias and maybe virtuser
		$alias->{'values'} = \@to;
		&sendmail::modify_alias($alias, $alias);
		if ($_[1]->{'from'} ne $_[0]->{'from'}) {
			# Re-named .. need to change too
			local $virt = { "from" => $_[1]->{'from'},
					"to" => $_[0]->{'virt'}->{'to'} };
			&sendmail::modify_virtuser($_[0]->{'virt'}, $virt,
						   $sendmail_vfile,
						   $sendmail_vdbm,
						   $sendmail_vdbmtype);
			$_[0]->{'virt'} = $virt;
			}
		}
	else {
		# Just update virtuser
		local $virt = { "from" => $_[1]->{'from'},
				"to" => $_[1]->{'to'}->[0] };
		&sendmail::modify_virtuser($_[0]->{'virt'}, $virt,
					   $sendmail_vfile, $sendmail_vdbm,
					   $sendmail_vdbmtype);
		$_[0]->{'virt'} = $virt;
		}
	}
elsif ($config{'mail_system'} == 0) {
	# Modify in postfix file
	local $alias = $_[0]->{'alias'};
	if (&needs_alias(@to) && !$alias) {
		# Alias needs to be created and virtuser updated
		$_[0]->{'from'} =~ /^(\S*)\@(\S+)$/;
		local $an = ($1 || "default")."-".$2;
		local $alias = { "name" => $an,
				 "enabled" => 1,
				 "values" => \@to };
		&postfix::create_alias($alias, $postfix_afiles);
		&postfix::regenerate_aliases();
		local $virt = { "name" => $_[1]->{'from'},
				"value" => $an };
		&postfix::modify_mapping($virtual_type, $_[0]->{'virt'}, $virt);
		$_[0]->{'virt'} = $virt;
		&postfix::regenerate_virtual_table();
		}
	elsif ($alias) {
		# Just update alias
		$alias->{'values'} = \@to;
		&postfix::modify_alias($alias, $alias);
		&postfix::regenerate_aliases();
		if ($_[1]->{'from'} ne $_[0]->{'from'}) {
			# Re-named .. need to change virtuser too
			local $virt = { "name" => $_[1]->{'from'},
					"value" => $_[1]->{'virt'}->{'value'} };
			&postfix::modify_mapping($virtual_type, $_[0]->{'virt'},
						 $virt);
			$_[0]->{'virt'} = $virt;
			&postfix::regenerate_virtual_table();
			}
		}
	else {
		# Just update virtuser
		local $virt = { "name" => $_[1]->{'from'},
				"value" => $_[1]->{'to'}->[0] };
		&postfix::modify_mapping($virtual_type, $_[0]->{'virt'}, $virt);
		$_[0]->{'virt'} = $virt;
		&postfix::regenerate_virtual_table();
		}
	}
elsif ($config{'mail_system'} == 2) {
	# Just update the qmail alias
	$_[1]->{'from'} =~ /^(\S*)\@(\S+)$/;
	local ($box, $dom) = ($1, $2);
	local ($virtmap) = grep { $_->{'domain'} eq $dom && !$_->{'user'} }
			        &qmailadmin::list_virts();
	local $alias = { 'name' => "$virtmap->{'prepend'}-$box",
			 'values' => \@to };
	&qmailadmin::modify_alias($_[0]->{'alias'}, $alias);
	$_[1]->{'alias'} = $alias;
	}
}

# create_virtuser(&virtuser)
# Creates a new virtual mail mapping
sub create_virtuser
{
&require_mail();
local @to = @{$_[0]->{'to'}};
if ($config{'mail_system'} == 1) {
	# Create in sendmail
	local $virt;
	if (&needs_alias(@to)) {
		# Need to create an alias, named address-domain
		$_[0]->{'from'} =~ /^(\S*)\@(\S+)$/;
		local $an = ($1 || "default")."-".$2;
		local $alias = { "name" => $an,
				 "enabled" => 1,
				 "values" => \@to };
		&sendmail::create_alias($alias, $sendmail_afiles);
		$virt = { "from" => $_[0]->{'from'},
			  "to" => $an };
		}
	else {
		# A single virtuser will do
		$virt = { "from" => $_[0]->{'from'},
			  "to" => $_[0]->{'to'}->[0] };
		}
	&sendmail::create_virtuser($virt, $sendmail_vfile,
				   $sendmail_vdbm,
				   $sendmail_vdbmtype);
	$_[0]->{'virt'} = $virt;
	}
elsif ($config{'mail_system'} == 0) {
	# Create in postfix file
	if (&needs_alias(@to)) {
		# Need to create an alias, named address-domain
		$_[0]->{'from'} =~ /^(\S*)\@(\S+)$/;
		local $an = ($1 || "default")."-".$2;
		local $alias = { "name" => $an,
				 "enabled" => 1,
				 "values" => \@to };
		&postfix::create_alias($alias, $postfix_afiles);
		&postfix::regenerate_aliases();
		$virt = { 'name' => $_[0]->{'from'},
			  'value' => $an };
		}
	else {
		# A single virtuser will do
		$virt = { 'name' => $_[0]->{'from'},
			  'value' => $_[0]->{'to'}->[0] };
		}
	&postfix::create_mapping($virtual_type, $virt);
	&postfix::regenerate_virtual_table();
	$_[0]->{'virt'} = $virt;
	}
elsif ($config{'mail_system'} == 2) {
	# Create a single Qmail alias
	$_[0]->{'from'} =~ /^(\S*)\@(\S+)$/;
	local ($box, $dom) = ($1, $2);
	local ($virtmap) = grep { $_->{'domain'} eq $dom && !$_->{'user'} }
			        &qmailadmin::list_virts();
	local $alias = { 'name' => "$virtmap->{'prepend'}-$box",
			 'values' => \@to };
	&qmailadmin::create_alias($alias);
	$_[0]->{'alias'} = $alias;
	}
}

# needs_alias(list..)
sub needs_alias
{
return 1 if (@_ != 1);
local $t;
foreach $t (@_) {
	return 1 if (&alias_type($t) != 1);
	}
return 0;
}

# join_alias(list..)
sub join_alias
{
return join(',', map { /\s/ ? "\"$_\"" : $_ } @_);
}

# domain_title(&domain)
sub domain_title
{
print "<center><font size=+1>",&text('indom', "<tt>$_[0]->{'dom'}</tt>"),
      "</font></center>\n";
}

# check_clash(name, dom)
# Returns the clash if a virtuser or user with the name already exists
sub check_clash
{
local @virts = &list_virtusers();
local ($clash) = grep { $_->{'from'} eq $_[0]."\@".$_[1] } @virts;
return $clash;
}

# delete_mail_file(&user)
sub delete_mail_file
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Just remove the Sendmail mail file
	unlink(&sendmail::user_mail_file($_[0]->{'user'}));
	}
elsif ($config{'mail_system'} == 0) {
	# Find out from Postfix which file to delete
	local $s = &postfix::postfix_mail_system();
	unlink(&postfix::postfix_mail_file($_[0]->{'user'}));
	}
elsif ($config{'mail_system'} == 2) {
	# Find out from Qmail which file to delete
	unlink(&qmailadmin::user_mail_dir($_[0]->{'user'}));
	}
}

# rename_mail_file(&user, oldname)
sub rename_mail_file
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Just rename the Sendmail mail file (if necessary)
	if ($sconfig{'mail_dir'}) {
		local $of = &sendmail::user_mail_file($_[1]);
		local $nf = &sendmail::user_mail_file($_[0]->{'user'});
		rename($of, $nf);
		}
	}
elsif ($config{'mail_system'} == 0) {
	# Find out from Postfix which file to rename (if necessary)
	local $s = &postfix::postfix_mail_system();
	if ($s == 0) {
		local $newumf = &postfix::postfix_mail_file($_[0]->{'user'});
		local $oldumf = &postfix::postfix_mail_file($_[1]);
		rename($oldumf, $newumf);
		}
	}
elsif ($config{'mail_system'} == 2) {
	# Just rename the Qmail mail file (if necessary)
	if ($qmconfig{'mail_system'} == 0 && $qmconfig{'mail_dir'}) {
		local $of = &qmailadmin::user_mail_file($_[1]);
		local $nf = &qmailadmin::user_mail_file($_[0]->{'user'});
		rename($of, $nf);
		}
	}
}

# mail_file_size(&user)
sub mail_file_size
{
&require_mail();
local $umf;
if ($config{'mail_system'} == 1) {
	# Just look at the Sendmail mail file
	$umf = &sendmail::user_mail_file($_[0]->{'user'});
	}
elsif ($config{'mail_system'} == 0) {
	# Find out from Postfix which file to check
	$umf = &postfix::postfix_mail_file($_[0]->{'user'});
	}
elsif ($config{'mail_system'} == 2) {
	# Find out from Qmail which file or dir to check
	$umf = &qmailadmin::user_mail_dir($_[0]->{'user'});
	}
if (-d $umf) {
	# Need to sum up a maildir-format directory
	local $sz = 0;
	foreach $d ("$umf/cur", "$umf/new", "$umf/tmp") {
		opendir(DIR, $d) || last;
		foreach $f (readdir(DIR)) {
			local @st = stat("$d/$f");
			$sz += $st[7];
			}
		closedir(DIR);
		}
	return ( $sz, $umf );
	}
else {
	# Just the size of a single mail file
	local @st = stat($umf);
	return ( $st[7], $umf );
	}
}

# mail_system_base()
# Returns the base directory under which user mail files can be found
sub mail_system_base
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Find out from sendmail module config
	if ($sconfig{'mail_dir'}) {
		return $sconfig{'mail_dir'};
		}
	}
elsif ($config{'mail_system'} == 0) {
	# Find out from postfix
	local @s = &postfix::postfix_mail_system();
	if ($s[0] == 0) {
		return $s[1];
		}
	}
elsif ($config{'mail_system'} == 2) {
	# Find out from qmail module config
	if ($qmconfig{'mail_system'} == 0 && $qmconfig{'mail_dir'}) {
		return $qmconfig{'mail_dir'};
		}
	}
# If we get here, assume that mail is under home dirs
local %uconfig = &foreign_config("useradmin");
return $home_base;
}

# read_mail_link(&user)
sub read_mail_link
{
local %acl;
&read_acl(\%acl);
if ($config{'mail_system'} == 1 && $acl{$base_remote_user,'sendmail'}) {
	return "/sendmail/list_mail.cgi?user=".$_[0]->{'user'};
	}
elsif ($config{'mail_system'} == 0 && $acl{$base_remote_user,'postfix'}) {
	return "/postfix/list_mail.cgi?user=".$_[0]->{'user'};
	}
elsif ($config{'mail_system'} == 2 && $acl{$base_remote_user,'qmailadmin'}) {
	return "/qmailadmin/list_mail.cgi?user=".$_[0]->{'user'};
	}
else {
	return undef;
	}
}

# postfix_installed()
# Returns 1 if postfix is installed
sub postfix_installed
{
return &foreign_installed("postfix", 1) == 2;
}

# sendmail_installed()
# Returns 1 if postfix is installed
sub sendmail_installed
{
return &foreign_installed("sendmail", 1) == 2;
}

# qmail_installed()
# Returns 1 if qmail is installed
sub qmail_installed
{
return &foreign_installed("qmailadmin", 1) == 2;
}

# get_apache_pid()
sub get_apache_pid
{
&require_apache();
local $conf = &apache::get_config();
local $pidfilestr = &apache::find_directive_struct(
			"PidFile", $conf);
local $pidfile = $pidfilestr ? $pidfilestr->{'words'}->[0]
			     : "logs/httpd.pid";
$pidfile = &apache::server_root($pidfile, $conf);
open(PID, $pidfile) || return undef;
chop($pid = <PID>);
close(PID);
return $pid;
}

# get_bind_pid()
sub get_bind_pid
{
&require_bind();
local ($pidfile, $opts, $pidopt);
local $conf = &bind8::get_config();
if (($opts = &bind8::find("options", $conf)) &&
    ($pidopt = &bind8::find("pid-file", $opts->{'members'}))) {
	# read from PID file
	$pidfile = $pidopt->{'value'};
	if ($pidfile !~ /^\//) {
		local $dir = &bind8::find(
				"directory", $opts->{'members'});
		$pidfile = $dir->{'value'}."/".$pidfile;
		}
	}
else {
	# use default file
	$pidfile = -r &bind8::make_chroot($bconfig{'pid_file'}) ?
			$bconfig{'pid_file'} : "/var/run/named.pid";
	}
open(PID, &bind8::make_chroot($pidfile)) || return undef;
chop($pid = <PID>);
close(PID);
return $pid;
}

# is_mail_running()
# Returns 1 if the configured mail server is running, 0 if not
sub is_mail_running
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Check the sendmail PID
	local $pid;
	open(PID, $sconfig{'sendmail_pid'}) || return 0;
	chop($pid = <PID>);
	close(PID);
	return kill(0, $pid);
	}
elsif ($config{'mail_system'} == 0) {
	# Call the postfix module 
	return &postfix::is_postfix_running();
	}
elsif ($config{'mail_system'} == 2) {
	# Just look for qmail-send
	local ($pid) = &find_byname("qmail-send");
	return $pid ? 1 : 0;
	}
}

# shutdown_mail_server()
# Shuts down the mail server, or calls &error
sub shutdown_mail_server
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Kill or stop sendmail
	if ($sconfig{'sendmail_stop_command'}) {
		$out = &backquote_logged("$sconfig{'sendmail_stop_command'} </dev/null 2>&1");
		if ($?) { &error("<pre>$out</pre>"); }
		}
	else {
		local $pid;
		open(PID, $sconfig{'sendmail_pid'}) ||
			&error($text{'mstop_edown'});
		chop($pid = <PID>);
		close(PID);
		&kill_logged('KILL', $pid) || &error($text{'mstop_edown'});
		unlink($sconfig{'sendmail_pid'});
		}
	}
else {
	# Run the postfix stop command
	$out = `$pconfig{'postfix_control_command'} -c $postfix::config_dir stop 2>&1`;
	if ($?) { &error("<tt>$out</tt>"); }
	}
}

# startup_mail_server()
# Starts up the mail server, or calls &error
sub startup_mail_server
{
&require_mail();
if ($config{'mail_system'} == 1) {
	# Run the sendmail start command
	$out = &backquote_logged("$sconfig{'sendmail_command'} </dev/null 2>&1");
	if ($?) { &error("<pre>$out</pre>"); }
	}
else {
	# Run the postfix start command
	$out = `$pconfig{'postfix_control_command'} -c $postfix::config_dir start 2>&1`;
	if ($?) { &error("<tt>$out</tt>"); }
	}
}

# setup_apache(&domain)
# Setup a virtual website for some domain
sub setup_apache
{
&$first_print($text{'setup_web'});
&require_apache();
local $conf = &apache::get_config();
if ($aconfig{'virt_file'}) {
	$f = -d $aconfig{'virt_file'} ?
		"$aconfig{'virt_file'}/www.$_[0]->{'dom'}.conf" :
		$aconfig{'virt_file'};
	}
else {
	$vconf = &apache::get_virtual_config();
	$f = $vconf->[0]->{'file'};
	}
&lock_file($f);

# add NameVirtualHost if needed
local $nvstar;
if ($_[0]->{'name'}) {
	local $found;
	local @nv = &apache::find_directive("NameVirtualHost", $conf);
	foreach $nv (@nv) {
		$found++ if ($nv eq $_[0]->{'ip'} ||
			     $nv =~ /^(\S+):(\S+)/ && $1 eq $_[0]->{'ip'} ||
			     $nv eq '*');
		$nvstar++ if ($nv eq "*");
		}
	if (!$found) {
		&apache::save_directive("NameVirtualHost",
					[ @nv, $_[0]->{'ip'} ],
					$conf, $conf);
		&flush_file_lines();
		}
	}

# Add the actual <VirtualHost>
local $dirs = $config{'apache_config'};
$dirs =~ s/\t/\n/g;
$dirs = &substitute_template($dirs, $_[0]);
local @dirs = split(/\n/, $dirs);
local ($sudir, $ppdir);
foreach (@dirs) {
	$sudir++ if (/^SuexecUserGroup\s/i || /^User\s/i);
	$ppdir++ if (/^ProxyPass\s/);
	}
if (!$sudir && $config{'suexec'}) {
	# Automatically add suexec directives if missing
	if ($apache::httpd_modules{'core'} >= 2.0) {
		if ($apache::httpd_modules{'mod_suexec'}) {
			unshift(@dirs, "SuexecUserGroup \"#$_[0]->{'uid'}\" ".
				       "\"#$_[0]->{'ugid'}\"");
			}
		}
	else {
		unshift(@dirs, "User \"#$_[0]->{'uid'}\"",
			       "Group \"#$_[0]->{'ugid'}\"");
		}
	}
if (!$ppdir && $_[0]->{'proxy_pass'}) {
	push(@dirs, "ProxyPass / $d->{'proxy_pass'}",
		    "ProxyPassReverse / $d->{'proxy_pass'}");
	}
local $vip = $_[0]->{'name'} && $apache::httpd_modules{'core'} >= 1.312 &&
	     $nvstar ? "*" : $_[0]->{'ip'};
open(FILE, ">>$f");
print FILE "<VirtualHost $vip>\n";
foreach (@dirs) {
	print FILE $_,"\n";
	}
print FILE "</VirtualHost>\n";
close(FILE);
&unlock_file($f);
undef(@apache::get_config_cache);
&$second_print($text{'setup_done'});
}

# delete_apache(&domain)
# Delete the domain from the Apache config
sub delete_apache
{
&require_apache();
local $conf = &apache::get_config();
&$first_print($text{'delete_apache'});
if ($config{'delete_indom'}) {
	local @virt = reverse(&apache::find_directive_struct("VirtualHost",
							     $conf));
	foreach $v (@virt) {
		local $sn = &apache::find_directive("ServerName",
						    $v->{'members'});
		if ($sn =~ /\Q$_[0]->{'dom'}\E$/) {
			&delete_virtual_server($v);
			}
		}
	&$second_print($text{'setup_done'});
	}
else {
	local ($virt, $vconf) = &get_apache_virtual($_[0]->{'dom'});
	if ($virt) {
		&delete_virtual_server($virt);
		&$second_print($text{'setup_done'});
		}
	else {
		&$second_print($text{'delete_noapache'});
		}
	}
}

# delete_virtual_server(&domain)
# Delete a single virtual server from the Apache config
sub delete_virtual_server
{
&require_apache();
&lock_file($_[0]->{'file'});
local $lref = &read_file_lines($_[0]->{'file'});
splice(@$lref, $_[0]->{'line'}, $_[0]->{'eline'} - $_[0]->{'line'} + 1);
&flush_file_lines();
&unlock_file($_[0]->{'file'});
}

# modify_apache(&domain, &olddomain)
sub modify_apache
{
return 0;	# Does nothing yet
}

$disabled_website = "$module_config_directory/disabled.html";

# disable_apache(&domain)
# Adds a directive to force all requests to show an error page
sub disable_apache
{
&$first_print($text{'disable_apache'});
&require_apache();
local ($virt, $vconf) = &get_apache_virtual($_[0]->{'dom'});
if ($virt) {
	&lock_file($virt->{'file'});
	local @am = &apache::find_directive("AliasMatch", $vconf);
	local $conf = &apache::get_config();
	&apache::save_directive("AliasMatch",
				[ @am, "^/.*\$ $disabled_website" ],
				$vconf, $conf);
	&flush_file_lines();
	if (!-r $disabled_website) {
		open(DISABLED, ">$disabled_website");
		print DISABLED "<h1>Website Disabled</h1>\n";
		close(DISABLED);
		chmod(0644, $disabled_website);
		}
	&unlock_file($virt->{'file'});
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'delete_noapache'});
	}
}

# enable_apache(&domain)
# Deletes the special error page directive
sub enable_apache
{
&$first_print($text{'enable_apache'});
&require_apache();
local ($virt, $vconf) = &get_apache_virtual($_[0]->{'dom'});
if ($virt) {
	&lock_file($virt->{'file'});
	local @am = &apache::find_directive("AliasMatch", $vconf);
	@am = grep { $_ ne "^/.*\$ $disabled_website" } @am;
	local $conf = &apache::get_config();
	&apache::save_directive("AliasMatch", \@am, $vconf, $conf);
	&flush_file_lines();
	&unlock_file($virt->{'file'});
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'delete_noapache'});
	}
}

# check_apache_clash(domain)
# Returns 1 if an Apache webserver already exists for some domain
sub check_apache_clash
{
local ($cvirt, $cconf) = &get_apache_virtual($_[0]);
return $cvirt ? 1 : 0;
}

# restart_apache()
# Tell Apache to re-read its config file
sub restart_apache
{
&$first_print($text{'setup_webpid'});
local $pid = &get_apache_pid();
if (!$pid || !kill(0, $pid)) {
	&$second_print($text{'setup_notrun'});
	return 0;
	}
if (-x $aconfig{'apachectl_path'}) {
	# Use apachectl
	&system_logged("$aconfig{'apachectl_path'} restart 2>&1");
	&$second_print($text{'setup_done'});
	return 1;
	}
else {
	# Just signal the process
	&kill_logged('HUP', $pid);
	&$second_print($text{'setup_done'});
	return 1;
	}
}

# setup_bind(&domain)
# Set up a zone for a domain
sub setup_bind
{
&$first_print($text{'setup_bind'});
local $rootcfile = &bind8::make_chroot($bconfig{'named_conf'});
&lock_file($rootcfile);
local $conf = &bind8::get_config();
local $base = $bconfig{'master_dir'} ? $bconfig{'master_dir'} :
				       &bind8::base_directory($conf);
local $format = $bconfig{'forwardzonefilename_format'};
$format =~ s/ZONE/$_[0]->{'dom'}/g;
local $file = $base."/".$format;
local $dir = {
	 'name' => 'zone',
	 'values' => [ $_[0]->{'dom'} ],
	 'type' => 1,
	 'members' => [ { 'name' => 'type',
			  'values' => [ 'master' ] },
			{ 'name' => 'file',
			  'values' => [ $file ] } ]
	};
local $pconf = &bind8::get_config_parent();
&bind8::save_directive($pconf, undef, [ $dir ], 0);
&flush_file_lines();
&unlock_file($rootcfile);

# Create the records file
local %zd;
&bind8::get_zone_defaults(\%zd);
local $rootfile = &bind8::make_chroot($file);
if (!-r $rootfile) {
	&lock_file($rootfile);
	local $serial = $bconfig{'soa_style'} ? &bind8::date_serial()
					      : time();
	if (!$config{'bind_replace'}) {
		# Create records that are appropriate for this domain
		open(RECS, ">$rootfile");
		print RECS "\$ttl $zd{'minimum'}$zd{'minunit'}\n"
			if ($bconfig{'master_ttl'});
		close(RECS);
		local $master = $bconfig{'default_prins'} ||
				&get_system_hostname();
		$master .= "." if ($master !~ /\.$/);
		local $email = $bconfig{'tmpl_email'} || "root\@$master";
		$email = &bind8::email_to_dotted($email);
		local $soa = "$master $email (\n".
			     "\t\t\t$serial\n".
			     "\t\t\t$zd{'refresh'}$zd{'refunit'}\n".
			     "\t\t\t$zd{'retry'}$zd{'retunit'}\n".
			     "\t\t\t$zd{'expiry'}$zd{'expunit'}\n".
			     "\t\t\t$zd{'minimum'}$zd{'minunit'} )";
		&bind8::create_record($file, "@", undef, "IN", "SOA", $soa);
		&bind8::create_record($file, "@", undef, "IN", "NS", $master);
		if ($bconfig{'default_slave'}) {
			my $slave = $bconfig{'default_slave'};
			$slave .= "." if ($slave !~ /\.$/);
			&bind8::create_record($file, "@", undef,
					      "IN", "NS", $slave);
			}
		&bind8::create_record($file, "@", undef,
				      "IN", "A", $_[0]->{'ip'});
		&bind8::create_record($file, "www", undef,
				      "IN", "A", $_[0]->{'ip'});
		&bind8::create_record($file, "ftp", undef,
				      "IN", "A", $_[0]->{'ip'});
		if ($_[0]->{'mail'}) {
			&bind8::create_record($file, "mail", undef,
					      "IN", "A", $_[0]->{'ip'});
			&bind8::create_record($file, "@", undef,
					      "IN", "MX", "5 mail");
			}
		}
	if ($config{'bind_config'}) {
		# Add or use the user-defined template
		open(RECS, ">>$rootfile");
		local %subs = %{$_[0]};
		$subs{'serial'} = $serial;
		local $recs = &substitute_template(
			join("\n", split(/\t+/, $config{'bind_config'}))."\n",
			\%subs);
		print RECS $recs;
		close(RECS);
		}
	&bind8::set_ownership($rootfile);
	&unlock_file($rootfile);
	}
&$second_print($text{'setup_done'});

# Create on slave server
local $slave = $bconfig{'default_slave'};
if ($slave) {
	&$first_print(&text('setup_bindslave', $slave));
	&remote_error_setup(\&slave_error_handler);
	&remote_foreign_require($slave, "bind8", "bind8-lib.pl");
	if ($slave_error) {
		# Failed to connect! Just tell user and continue
		&$second_print(&text('setup_eslave', $slave_error));
		return;
		}

	local $sparent = &remote_foreign_call($slave, "bind8",
					"get_config_parent");
	local $sconfig = &remote_foreign_config($slave, "bind8");
	local $sconf = $sparent->{'members'};
	local $opts = &bind8::find("options", $sconf);
	if (!$opts) {
		&$second_print(&text('setup_eslave',
			       &bind8::text('master_eslave', $slave)));
		return;
		}
	foreach $z (&bind8::find("zone", $sconf)) {
		if ($z->{'value'} eq $_[0]->{'dom'}) {
			&$second_print(&text('setup_eslave',
				       &bind8::text('master_etaken')));
			return;
			}
		}
	local $masters = { 'name' => 'masters',
		     	   'type' => 1,
		     	   'members' => [ { 'name' =>
				&to_ipaddress(&get_system_hostname()) } ] };
	local $dir = { 'name' => 'zone',
		       'values' => [ $_[0]->{'dom'} ],
		       'type' => 1,
		       'members' => [ { 'name' => 'type',
					'values' => [ 'slave' ] },
					$masters
				    ]
			};
	local $sbase = $sconfig{'slave_dir'} ? $sconfig{'slave_dir'} :
				&remote_foreign_call($slave, "bind8",
						     "base_directory", $sconf);
	local $file = $sbase."/".$_[0]->{'dom'}.".hosts";
	push(@{$dir->{'members'}}, { 'name' => 'file',
				     'values' => [ $file ] } );
	&remote_foreign_call($slave, "bind8", "save_directive", $sparent,
			     undef, [ $dir ], 0);
	&remote_foreign_call($slave, "bind8", "flush_file_lines");
	$_[0]->{'dns_slave'} = $slave;
	&$second_print($text{'setup_done'});
	}
}

sub slave_error_handler
{
$slave_error = $_[0];
}

# delete_bind(&domain)
# Delete a domain from the BIND config
sub delete_bind
{
&$first_print($text{'delete_bind'});
&require_bind();
local $z = &get_bind_zone($_[0]->{'dom'});
if ($z) {
	# Delete the records file
	local $file = &bind8::find("file", $z->{'members'});
	if ($file) {
		unlink(&bind8::make_chroot($file->{'values'}->[0]));
		}

	# Delete from named.conf
	local $rootfile = &bind8::make_chroot($z->{'file'});
	&lock_file($rootfile);
	local $lref = &read_file_lines($rootfile);
	splice(@$lref, $z->{'line'}, $z->{'eline'} - $z->{'line'} + 1);
	&flush_file_lines();
	&unlock_file($rootfile);
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'save_nobind'});
	}

local $slave = $_[0]->{'dns_slave'};
if ($slave) {
	# Delete from slave server too
	&$first_print(&text('delete_bindslave', $slave));
	&remote_error_setup(\&slave_error_handler);
	&remote_foreign_require($slave, "bind8", "bind8-lib.pl");
	if ($slave_error) {
		&$second_print(&text('setup_eslave', $slave_error));
		return;
		}

	local $sparent = &remote_foreign_call($slave, "bind8",
					      "get_config_parent");
	local $sconf = $sparent->{'members'};
	local ($z, $szconf);
	foreach $z (&bind8::find("zone", $sconf)) {
		$szconf = $z if ($z->{'value'} eq $_[0]->{'dom'});
		}
	if (!$szconf) {
		&$second_print(&text('setup_eslave',
				     &bind8::text('delete_ezone')));
		return;
		}
	&remote_foreign_call($slave, "bind8", "save_directive", $sparent,
			     [ $szconf ], [ ]);
	&remote_foreign_call($slave, "bind8", "flush_file_lines");
	delete($_[0]->{'dns_slave'});
	&$second_print($text{'setup_done'});
	}
}

# modify_bind(&domain, &olddomain)
# Does nothing yet
sub modify_bind
{
return 0;
}

# disable_bind(&domain)
# Re-names this domain in named.conf with the .disabled suffix
sub disable_bind
{
&$first_print($text{'disable_bind'});
&require_bind();
local $z = &get_bind_zone($_[0]->{'dom'});
if ($z) {
	$z->{'values'}->[0] = $_[0]->{'dom'}.".disabled";
	&bind8::save_directive(&bind8::get_config_parent(), [ $z ], [ $z ], 0);
	&flush_file_lines();
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'save_nobind'});
	}
}

# enable_bind(&domain)
# Re-names this domain in named.conf to remove the .disabled suffix
sub enable_bind
{
&$first_print($text{'enable_bind'});
&require_bind();
local $z = &get_bind_zone($_[0]->{'dom'});
if ($z) {
	$z->{'values'}->[0] = $_[0]->{'dom'};
	&bind8::save_directive(&bind8::get_config_parent(), [ $z ], [ $z ], 0);
	&flush_file_lines();
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'save_nobind'});
	}
}

# get_bind_zone(name)
# Returns the zone structure for the named domain, possibly with .disabled
sub get_bind_zone
{
&require_bind();
local $conf = &bind8::get_config();
local @zones = &bind8::find("zone", $conf);
local ($v, $z);
foreach $v (&bind8::find("view", $conf)) {
	push(@zones, &bind8::find("zone", $v->{'members'}));
	}
local ($z) = grep { $_->{'value'} eq $_[0] ||
		    $_->{'value'} eq "$_[0].disabled" } @zones;
return $z;
}

# restart_bind(&domain)
# Signal BIND to re-load its configuration
sub restart_bind
{
&$first_print($text{'setup_bindpid'});
local $pid = &get_bind_pid();
if ($pid) {
	if ($bconfig{'restart_cmd'}) {
		&system_logged("$bconfig{'restart_cmd'} >/dev/null 2>&1 </dev/null");
		}
	else {
		&kill_logged('HUP', $pid);
		}
	&$second_print($text{'setup_done'});
	$rv = 1;
	}
else {
	&$second_print($text{'setup_notrun'});
	$rv = 0;
	}
local $slave = $_[0]->{'dns_slave'} || $bconfig{'default_slave'};
if ($slave) {
	# Re-start on slave too
	&$first_print(&text('setup_bindslavepid', $slave));
	&remote_error_setup(\&slave_error_handler);
	&remote_foreign_require($slave, "bind8", "bind8-lib.pl");
	if ($slave_error) {
		# Failed to connect! Just tell user and continue
		&$second_print(&text('setup_eslave', $slave_error));
		return $rv;
		}

	# Find remote PID file
	local $sconfig = &remote_foreign_config($slave, "bind8");
	local $sconf = &remote_foreign_call($slave, "bind8", "get_config");
	local $pidfile;
	if (($opts = &bind8::find("options", $sconf)) &&
	    ($pidopt = &bind8::find("pid-file", $opts->{'members'}))) {
		# read from PID file
		$pidfile = $pidopt->{'value'};
		if ($pidfile !~ /^\//) {
			local $dir = &bind8::find("directory",
						  $opts->{'members'});
			$pidfile = $dir->{'value'}."/".$pidfile;
			}
		}
	else {
		# use default file
		$pidfile = $sconfig->{'pid_file'} ? $sconfig->{'pid_file'}
						  : "/var/run/named.pid";
		}

	# Read the PID and restart
	$pid = &remote_eval($slave, "bind8", <<EOF
open(PID, '$pidfile');
chop(\$pid = <PID>);
close(PID);
return \$pid;
EOF
	);
	if (!$pid) {
		&$second_print($text{'setup_notrun'});
		return $rv;
		}
	&remote_eval($slave, "bind8", "kill('HUP', $pid) ? \$! : 0");
	&$second_print($text{'setup_done'});
	}
return $rv;
}

# check_bind_clash(domain)
# Returns 1 if a domain already exists in BIND
sub check_bind_clash
{
local ($czone) = &get_bind_zone($_[0]);
return $czone ? 1 : 0;
}

# setup_mysql(&domain)
# Create a new MySQL database, user and permissions
sub setup_mysql
{
&$first_print($text{'setup_mysql'});
&require_mysql();
&mysql::execute_sql($mysql::master_db, "create database $_[0]->{'db'}");
local @hosts = split(/\s+/, $config{'mysql_hosts'});
@hosts = ( 'localhost' ) if (!@hosts);
local $h;
foreach $h (@hosts) {
	&mysql::execute_sql($mysql::master_db, "insert into user (host, user, password) values ('$h', '$_[0]->{'user'}', password('$_[0]->{'pass'}'))");
	&mysql::execute_sql($mysql::master_db, "insert into db (host, db, user, select_priv, insert_priv, update_priv, delete_priv, create_priv, drop_priv, grant_priv, references_priv, index_priv, alter_priv) values ('$h', '$_[0]->{'db'}', '$_[0]->{'user'}', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y')");
	}
&mysql::execute_sql($master_db, 'flush privileges');
&$second_print($text{'setup_done'});
}

# delete_mysql(&domain)
# Delete a mysql database, the domain's mysql user and all permissions for both
sub delete_mysql
{
&$first_print($text{'delete_mysql'});
&require_mysql();
&mysql::execute_sql($mysql::master_db, "drop database $_[0]->{'db'}");
&mysql::execute_sql($mysql::master_db, "delete from user where user = '$_[0]->{'user'}'");
&mysql::execute_sql($mysql::master_db, "delete from db where user = '$_[0]->{'user'}' or db = '$_[0]->{'db'}'");
&mysql::execute_sql($master_db, 'flush privileges');
&$second_print($text{'setup_done'});
}

# modify_mysql(&domain, &olddomain)
# Changes the mysql user's password if needed
sub modify_mysql
{
&require_mysql();
if ($_[0]->{'pass'} ne $_[1]->{'pass'}) {
	&$first_print($text{'save_mysqlpass'});
	if (&mysql_user_exists($_[0])) {
		&mysql::execute_sql($mysql::master_db, "update user set password = password('$_[0]->{'pass'}') where user = '$_[0]->{'user'}'");
		&mysql::execute_sql($master_db, 'flush privileges');
		&$second_print($text{'setup_done'});
		return 1;
		}
	else {
		&$first_print($text{'save_nomysql'});
		}
	}
return 0;
}

# disable_mysql(&domain)
# Modifies the mysql user for this domain so that he cannot login
sub disable_mysql
{
&$first_print($text{'disable_mysqluser'});
&require_mysql();
if ($oldpass = &mysql_user_exists($_[0])) {
	&mysql::execute_sql($mysql::master_db, "update user set password = '*LK*' where user = '$_[0]->{'user'}'");
	&mysql::execute_sql($master_db, 'flush privileges');
	$_[0]->{'disabled_oldmysql'} = $oldpass;
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'save_nomysql'});
	}
}

# enable_mysql(&domain)
# Puts back the original password for the mysql user so that he can login again
sub enable_mysql
{
&$first_print($text{'enable_mysql'});
&require_mysql();
if (&mysql_user_exists($_[0])) {
	if ($_[0]->{'disabled_oldmysql'}) {
		&mysql::execute_sql($mysql::master_db, "update user set password = '$_[0]->{'disabled_oldmysql'}' where user = '$_[0]->{'user'}'");
		delete($_[0]->{'disabled_oldmysql'});
		}
	else {
		&mysql::execute_sql($mysql::master_db, "update user set password = password('$_[0]->{'pass'}') where user = '$_[0]->{'user'}'");
		}
	&mysql::execute_sql($master_db, 'flush privileges');
	&$second_print($text{'setup_done'});
	}
else {
	&$second_print($text{'save_nomysql'});
	}

}

# mysql_user_exists(&domain)
# Returns his password if a mysql user exists for the domain's user, or undef
sub mysql_user_exists
{
&require_mysql();
local $u = &mysql::execute_sql($mysql::master_db, "select password from user where user = '$_[0]->{'user'}'");
return @{$u->{'data'}} ? $u->{'data'}->[0]->[0] : undef;
}

# check_mysql_clash(db)
# Returns 1 if some MySQL database already exists
sub check_mysql_clash
{
&require_mysql();
local @dblist = &mysql::list_databases();
return &indexof($_[0], @dblist) >= 0;
}

# setup_webmin(&domain)
# Creates a new webmin user to manage this domain, with access to the appropriate
# modules with the right permissions
sub setup_webmin
{
&$first_print($text{'setup_webmin'});
&require_acl();
local @modules;
local %wuser = ( 'name' => $_[0]->{'user'},
		 'pass' => 'x',
		 'notabs' => 1,
		 'modules' => [ ],
		 'theme' => $config{'webmin_theme'} eq '*' ? undef :
			    $config{'webmin_theme'} eq '' ? '' :
			     $config{'webmin_theme'}
		 );
&acl::create_user(\%wuser);
&set_user_modules($_[0], \%wuser);
&$second_print($text{'setup_done'});
}

# delete_webmin(&domain)
# Delete the webmin user for the domain, and all his permissions
sub delete_webmin
{
&$first_print($text{'delete_webmin'});
&require_acl();
&acl::delete_user($_[0]->{'user'});
local $m;
foreach $m (&get_all_module_infos()) {
	unlink("$config_directory/$m/$_[0]->{'user'}.acl");
	}
&$second_print($text{'setup_done'});
}

# modify_webmin(&domain, &olddomain)
sub modify_webmin
{
&$first_print($text{'save_webmin'});
&require_acl();
local ($wuser) = grep { $_->{'name'} eq $_[0]->{'user'} } &acl::list_users();
&set_user_modules($_[0], $wuser) if ($wuser);
&$second_print($text{'setup_done'});
return 1;
}

# disable_webmin(&domain)
# Lock the password of the domains's Webmin user
sub disable_webmin
{
&$first_print($text{'disable_webmin'});
&require_acl();
local ($wuser) = grep { $_->{'name'} eq $_[0]->{'user'} } &acl::list_users();
if ($wuser) {
	$wuser->{'pass'} = "*LK*";
	&acl::modify_user($wuser->{'name'}, $wuser);
	}
&$second_print($text{'setup_done'});
}

# enable_webmin(&domain)
# Changes the password of the domain's Webmin user back to unix auth
sub enable_webmin
{
&$first_print($text{'enable_webmin'});
&require_acl();
local ($wuser) = grep { $_->{'name'} eq $_[0]->{'user'} } &acl::list_users();
if ($wuser) {
	$wuser->{'pass'} = "x";
	&acl::modify_user($wuser->{'name'}, $wuser);
	}
&$second_print($text{'setup_done'});
}

# restart_webmin()
sub restart_webmin
{
&$first_print($text{'setup_webminpid'});
&restart_miniserv();
&$second_print($text{'setup_done'});
}

# set_user_modules(&domain, &webminuser)
sub set_user_modules
{
local @mods;
local %hasmods = map { $_, 1 } @{$_[1]->{'modules'}};
%hasmods = ( ) if (!$config{'leave_acl'});

# Grant access to BIND module if needed
if ($_[0]->{'dns'}) {
	# Allow user to manage just this domain
	push(@mods, "bind8");
	local %acl = ( 'noconfig' => 1,
		       'zones' => $_[0]->{'dom'},
		       'dir' => $_[0]->{'home'},
		       'master' => 0,
		       'slave' => 0,
		       'forward' => 0,
		       'defaults' => 0,
		       'reverse' => 0,
		       'multiple' => 1,
		       'ro' => 0,
		       'apply' => 2,
		       'file' => 0,
		       'params' => 1,
		       'opts' => 0,
		       'delete' => 0,
		       'gen' => 1,
		       'whois' => 1,
		       'findfree' => 1,
		       'remote' => 0,
		       'views' => 0,
		       'vlist' => '' );
	&save_module_acl(\%acl, $_[1]->{'name'}, "bind8")
		if (!$hasmods{'bind8'});
	}
else {
	@mods = grep { $_ ne "bind8" } @mods;
	}

# Grant access to MySQL module if needed
if ($_[0]->{'mysql'}) {
	# Allow user to manage just the domain's DB
	push(@mods, "mysql");
	local %acl = ( 'noconfig' => 1,
		       'dbs' => $_[0]->{'db'},
		       'create' => 0,
		       'delete' => 0,
		       'stop' => 0,
		       'perms' => 0,
		       'edonly' => 0,
		       'user' => $_[0]->{'user'},
		       'pass' => $_[0]->{'pass'},
		       'buser' => $_[0]->{'user'},
		       'bpath' => "/" );
	&save_module_acl(\%acl, $_[1]->{'name'}, "mysql")
		if (!$hasmods{'mysql'});
	}
else {
	@mods = grep { $_ ne "mysql" } @mods;
	}

# Grant access to PostgreSQL module if needed
if ($_[0]->{'postgres'}) {
	# Allow user to manage just the domain's DB
	push(@mods, "postgresql");
	local %acl = ( 'noconfig' => 1,
		       'dbs' => $_[0]->{'db'},
		       'create' => 0,
		       'delete' => 0,
		       'stop' => 0,
		       'users' => 0,
		       'user' => $_[0]->{'user'},
		       'pass' => $_[0]->{'pass'},
		       'sameunix' => 1,
		       'backup' => 1,
		       'restore' => 1 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "postgresql")
		if (!$hasmods{'postgresql'});
	}
else {
	@mods = grep { $_ ne "postgresql" } @mods;
	}

# Grant access to Apache module if needed
if ($_[0]->{'web'}) {
	# Allow user to manage just this website
	push(@mods, "apache");
	local %acl = ( 'noconfig' => 1,
		       'virts' => $_[0]->{'dom'},
		       'global' => 0,
		       'create' => 0,
		       'vuser' => 0,
		       'vaddr' => 0,
		       'pipe' => 0,
		       'stop' => 0,
		       'dir' => $_[0]->{'home'},
		       'test_always' => 1,
		       'types' => join(" ",
				(0 .. 7, 9 .. 16,
				 18 .. $apache::directive_type_count)) );
	&save_module_acl(\%acl, $_[1]->{'name'}, "apache")
		if (!$hasmods{'apache'});
	}
else {
	@mods = grep { $_ ne "apache" } @mods;
	}

# Grant access to Webalizer module if needed
if ($_[0]->{'webalizer'}) {
	push(@mods, "webalizer");
	local %acl = ( 'noconfig' => 1,
		       'view' => 0,
		       'global' => 0,
		       'add' => 0,
		       'user' => $_[0]->{'user'},
		       'dir' => &get_apache_log($_[0]->{'dom'}) );
	&save_module_acl(\%acl, $_[1]->{'name'}, "webalizer")
		if (!$hasmods{'webalizer'});
	}
else {
	@mods = grep { $_ ne "webalizer" } @mods;
	}

# Grant access to this module for managing its users and aliaes
if ($_[0]->{'mail'}) {
	push(@mods, $module_name);
	local %acl = ( 'noconfig' => 1,
		       'edit' => 0,
		       'create' => 0,
		       'import' => 0,
		       'stop' => 0,
		       'local' => 0,
		       'domains' => $_[0]->{'id'} );
	&save_module_acl(\%acl, $_[1]->{'name'})
		if (!$hasmods{'virtual-server'});
	}
else {
	@mods = grep { $_ ne "virtual-server" } @mods;
	}

# Set global ACL options
local %acl = ( 'feedback' => 0,
	       'desc_'.$module_name => $text{'index_title2'},
	       'root' => $_[0]->{'home'},
	       'rpc' => 0 );
&save_module_acl(\%acl, $_[1]->{'name'}, ".");

local @extramods = map { /^avail_(\S+)/; $1 }
		  	grep { $config{$_} }
			    grep { /^avail_/ } (keys %config);
local %extramods = map { $_, 1 } @extramods;

if ($extramods{'file'}) {
	# Limit file manager to user's directory
	local %acl = ( 'noconfig' => 1,
		       'uid' => -1,
		       'follow' => 0,
		       'root' => '',
		       'home' => 1,
		       'goto' => 1 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "file")
		if (!$hasmods{'file'});
	push(@mods, "file");
	}

if ($extramods{'passwd'}) {
	# Can only change his password
	local %acl = ( 'noconfig' => 1,
		       'mode' => 3,
		       'repeat' => 1,
		       'old' => 1,
		       'expire' => 0,
		       'others' => 1 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "passwd")
		if (!$hasmods{'passwd'});
	push(@mods, "passwd");
	}

if ($extramods{'proc'}) {
	# Can only manage his own processes
	local %acl = ( 'noconfig' => 1,
		       'uid' => -1,
		       'edit' => 1,
		       'run' => 1 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "proc")
		if (!$hasmods{'proc'});
	push(@mods, "proc");
	}

if ($extramods{'cron'}) {
	# Can only manage his cron jobs
	local %acl = ( 'noconfig' => 1,
		       'mode' => 3,
		       'allow' => 0 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "cron")
		if (!$hasmods{'cron'});
	push(@mods, "cron");
	}

if ($extramods{'at'}) {
	# Can only manage his at jobs
	local %acl = ( 'noconfig' => 1,
		       'mode' => 3 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "at")
		if (!$hasmods{'at'});
	push(@mods, "at");
	}

if ($extramods{'telnet'}) {
	# Cannot configure module
	local %acl = ( 'noconfig' => 1 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "telnet")
		if (!$hasmods{'telnet'});
	push(@mods, "telnet");
	}

if ($extramods{'custom'}) {
	# Cannot edit and create commands
	local %acl = ( 'noconfig' => 1,
		       'cmd' => '*',
		       'edit' => 0 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "custom")
		if (!$hasmods{'custom'});
	push(@mods, "custom");
	}

if ($extramods{'updown'}) {
	# Can upload and download to home dir only
	local %acl = ( 'noconfig' => 1,
		       'dirs' => '',
		       'home' => 1,
		       'mode' => 3 );
	&save_module_acl(\%acl, $_[1]->{'name'}, "updown")
		if (!$hasmods{'updown'});
	push(@mods, "updown");

	# Set defaults for upload and download directories for this user
	local %udconfig;
	local $udfile = "$config_directory/updown/config";
	&lock_file($udfile);
	&read_file($udfile, \%udconfig);
	$udfile{'dir_'.$_[1]->{'name'}} ||= $_[0]->{'home'};
	$udfile{'ddir_'.$_[1]->{'name'}} ||= $_[0]->{'home'};
	&write_file($udfile, \%udconfig);
	&unlock_file($udfile);
	}

if ($extramods{'change-user'}) {
	# This module is always safe, so no ACL needs to be set
	push(@mods, "change-user");
	}

if ($extramods{'htaccess-htpasswd'}) {
	# Can create .htaccess files in home dir, as user
	local %acl = ( 'noconfig' => 1,
		       'dirs' => $_[0]->{'home'},
		       'user' => '*' );
	&save_module_acl(\%acl, $_[1]->{'name'}, "htaccess-htpasswd")
		if (!$hasmods{'htaccess-htpasswd'});
	push(@mods, "htaccess-htpasswd");
	}

$_[1]->{'modules'} = [ &unique(@mods) ];
&acl::modify_user($_[1]->{'name'}, $_[1]);
}

# check_webmin_clash(username)
# Returns 1 if a user or group with this name already exists
sub check_webmin_clash
{
&require_acl();
return 1 if ($_[0] eq 'webmin');
local $u;
foreach $u (&acl::list_users(), &acl::list_groups()) {
	return 1 if ($u->{'name'} eq $_[0]);
	}
return 0;
}

# setup_webalizer(&domain)
# Setup the Webalizer module for this domain, and create a Cron job to run it
# XXX locking!
sub setup_webalizer
{
&$first_print($text{'setup_webalizer'});
&require_webalizer();

local $alog = &get_apache_log($_[0]->{'dom'});
if (!$alog) {
	&$second_print($text{'setup_nolog'});
	return;
	}

# Create directory for stats
local $hdir = $config{'html_dir'} || 'public_html';
local $stats = "$_[0]->{'home'}/$hdir/stats";
if (!-d $stats) {
	&system_logged("mkdir '$stats' 2>/dev/null");
	&system_logged("chmod 755 '$stats'");
	&system_logged("chown $_[0]->{'uid'}:$_[0]->{'ugid'} '$stats'");
	}

# Set up config for log in Webalizer module
if (!-r &webalizer::log_config_name($alog)) {
	$lconf = { 'dir' => $stats,
		   'sched' => 1,
		   'type' => 0,
		   'over' => 0,
		   'clear' => 1,
		   'user' => $_[0]->{'user'},
		   'mins' => int(rand()*60),
		   'hours' => 0,
		   'days' => '*',
		   'months' => '*',
		   'weekdays' => '*' };
	&webalizer::save_log_config($alog, $lconf);

	# Create a custom webalizer.conf for the site
	# Copy webalizer.conf into place for site, and update
	local $cfile = &webalizer::config_file_name($alog);
	system("cp $wconfig{'webalizer_conf'} $cfile");
	system("chown $_[0]->{'user'}:$_[0]->{'group'} $cfile");
	local $wconf = &webalizer::get_config($alog);
	&webalizer::save_directive($wconf, "HistoryName", "webalizer.hist");
	&webalizer::save_directive($wconf, "IncrementalName", "webalizer.current");
	&webalizer::save_directive($wconf, "Incremental", "yes");
	&webalizer::save_directive($wconf, "LogFile", $alog);
	&webalizer::save_directive($wconf, "HostName", $_[0]->{'dom'});
	&flush_file_lines();

	# Create a Cron job to process the log
	&foreign_require("cron", "cron-lib.pl");
	local $job = { 'user' => 'root',
		       'active' => 1,
		       'mins' => $lconf->{'mins'},
		       'hours' => $lconf->{'hours'},
		       'days' => $lconf->{'days'},
		       'months' => $lconf->{'months'},
		       'weekdays' => $lconf->{'weekdays'},
		       'command' => "$webalizer::cron_cmd $alog" };
	if (!-r $webalizer::cron_cmd) {
		&lock_file($webalizer::cron_cmd);
		&cron::create_wrapper($webalizer::cron_cmd,
				      "webalizer", "webalizer.pl");
		&unlock_file($webalizer::cron_cmd);
		}
	&cron::create_cron_job($job);
	}
&$second_print($text{'setup_done'});
}

# modify_webalizer(&domain, &olddomain)
# Nothing to do here
sub modify_webalizer
{
}

# delete_webalizer(&domain)
# Delete the Webalizer config files and Cron job
sub delete_webalizer
{
&$first_print($text{'delete_webalizer'});
&require_webalizer();
local $alog = &get_apache_log($_[0]->{'dom'});
return if (!$alog);

# Delete config files
#local $lfile = &webalizer::log_config_name($alog);
#unlink($lfile);
#local $cfile = &webalizer::config_file_name($alog);
#unlink($cfile);
 
# Turn off cron job for webalizer config
&foreign_require("cron", "cron-lib.pl");
foreach $j (&cron::list_cron_jobs()) {
        if ($j->{'command'} eq "$webalizer::cron_cmd $alog") {
                &cron::delete_cron_job($j);
                last;
                }
        }
&$second_print($text{'setup_done'});
}

# check_postgres_clash()
# Returns 1 if some PostgreSQL database already exists
sub check_postgres_clash
{
&require_postgres();
local @dblist = &postgresql::list_databases();
return &indexof($_[0], @dblist) >= 0;
}

# setup_postgres(&domain)
# Create a new PostgreSQL database and user
sub setup_postgres
{
&$first_print($text{'setup_postgres'});
&require_postgres();
&postgresql::execute_sql($qconfig{'basedb'}, "create database $_[0]->{'db'}");
local $pass = &postgresql::get_postgresql_version() >= 7 ? "'$_[0]->{'pass'}'"
							 : $_[0]->{'pass'};
&postgresql::execute_sql($qconfig{'basedb'}, "create user \"$_[0]->{'user'}\" with password $pass nocreatedb nocreateuser");
&$second_print($text{'setup_done'});
}

# modify_postgres(&domain, &olddomain)
# Change the PostgreSQL user's password if needed
sub modify_postgres
{
&require_postgres();
if ($_[0]->{'pass'} ne $_[1]->{'pass'}) {
	&$first_print($text{'save_postgrespass'});
	local $pass = &postgresql::get_postgresql_version() >= 7 ?
			"'$_[0]->{'pass'}'" : $_[0]->{'pass'};
	&postgresql::execute_sql($qconfig{'basedb'}, "alter user \"$_[0]->{'user'}\" with password $pass");
	&$second_print($text{'setup_done'});
	}
}

# delete_postgres(&domain)
# Delete the PostgreSQL database and user
sub delete_postgres
{
&$first_print($text{'delete_postgres'});
&require_postgres();
&postgresql::execute_sql($qconfig{'basedb'}, "drop database $_[0]->{'db'}");
&postgresql::execute_sql($qconfig{'basedb'}, "drop user \"$_[0]->{'user'}\"");
&$second_print($text{'setup_done'});
}

# disable_postgres(&domain)
# Invalidate the domain's PostgreSQL user
sub disable_postgres
{
&$first_print($text{'disable_postgres'});
&require_postgres();
local $date = localtime(0);
&postgresql::execute_sql($qconfig{'basedb'}, "alter user \"$_[0]->{'user'}\" valid until '$date'");
&$second_print($text{'setup_done'});
}

# enable_postgres(&domain)
# Validate the domain's PostgreSQL user
sub enable_postgres
{
&$first_print($text{'enable_postgres'});
&require_postgres();
&postgresql::execute_sql($qconfig{'basedb'}, "alter user \"$_[0]->{'user'}\" valid until 'Jan 1 2038'");
&$second_print($text{'setup_done'});
}

# copy_skel_files(basedir, &user, [group])
# Copy files to the home directory of some new user
sub copy_skel_files
{
local $uf = $_[0];
return if (!$uf);
&require_useradmin();
local $shell = $_[1]->{'shell'};
$shell =~ s/^(.*)\///g;
local $group = $_[2];
$group = getgrgid($_[1]->{'gid'}) if (!$group);
$uf =~ s/\$group/$group/g;
$uf =~ s/\$gid/$_[1]->{'gid'}/g;
$uf =~ s/\$shell/$shell/g;
&useradmin::copy_skel_files($uf, $_[1]->{'home'},
			    $_[1]->{'uid'}, $_[1]->{'gid'});
}

# can_edit_domain(&domain)
# Returns 1 if the current user can edit some domain
sub can_edit_domain
{
return 1 if ($access{'domains'} eq "*");
local $d;
foreach $d (split(/\s+/, $access{'domains'})) {
	return 1 if ($d eq $_[0]->{'id'});
	}
return 0;
}

# domains_table(&domains)
# Display a list of domains in a table, with links for editing
sub domains_table
{
local @table_features = grep { $_ ne 'webmin' && $_ ne 'mail' } @features;
print "<table border width=100%>\n";
print "<tr $tb> <td><b>$text{'index_domain'}</b></td> ",
      "<td><b>$text{'index_user'}</b></td> ",
      "<td><b>$text{'index_owner'}</b></td> ";
local $f;
foreach $f (@table_features) {
	print "<td><b>",$text{'index_'.$f},"</b></td> " if ($config{$f});
	}
if ($config{'mail'}) {
	print "<td><b>$text{'index_mail'}</b></td> ";
	print "<td><b>$text{'index_alias'}</b></td> ";
	}
if ($config{'home_quotas'}) {
	print "<td><b>$text{'index_quota'}</b></td> ".
	      "<td><b>$text{'index_uquota'}</b></td> ";
	}
print "</tr>\n";
local $d;
foreach $d (sort { $a->{'dom'} cmp $b->{'dom'} } @{$_[0]}) {
	print "<tr $cb>\n";
	local $dn = $d->{'disabled'} ? "<i>$d->{'dom'}</i>" : $d->{'dom'};
	if ($access{'edit'}) {
		print "<td><a href='edit_domain.cgi?dom=$d->{'id'}'>",
		      "$dn</a></td>\n";
		}
	else {
		print "<td>$dn</td>\n";
		}
	print "<td>$d->{'user'}</td>\n";
	print "<td>$d->{'owner'}</td>\n";
	foreach $f (@table_features) {
		print "<td>",$d->{$f} ? $text{'yes'} : $text{'no'},"</td>\n"
			if ($config{$f});
		}
	local @users = &list_domain_users($d);
	local ($duser) = grep { $_->{'user'} eq $d->{'user'} } @users;
	if ($config{'mail'}) {
		if ($d->{'mail'}) {
			local @aliases = &list_domain_aliases($d);
			printf "<td>%d%s&nbsp;(<a href='list_users.cgi?dom=$d->{'id'}'>$text{'index_list'}</a>)</td>\n", scalar(@users), $d->{'mailboxlimit'} ? " of $d->{'mailboxlimit'}" : "";
			printf "<td>%d&nbsp;(<a href='list_aliases.cgi?dom=$d->{'id'}'>$text{'index_list'}</a>)</td>\n", scalar(@aliases);
			}
		else {
			print "<td colspan=2>$text{'index_nomail'}</td>\n";
			}
		}
	if ($config{'home_quotas'}) {
		print "<td>",$d->{'quota'} ? "$d->{'quota'} $text{'form_b'}"
					   : $text{'form_unlimit'},"</td>\n";
		local $ut = $duser->{'uquota'} + $duser->{'umquota'};
		foreach $u (@users) {
			$ut += $u->{'uquota'} + $u->{'umquota'}
				if ($u->{'user'} ne $d->{'user'});
			}
		print "<td>$ut $text{'form_b'}</td>\n";
		}
	print "</tr>\n";
	}
print "</table>\n";
}

# userdom_name(name, &domain)
# Returns a username with the domain group appended somehow
sub userdom_name
{
if ($config{'append_style'} == 0) {
	return $_[0].".".$_[1]->{'group'};
	}
elsif ($config{'append_style'} == 1) {
	return $_[0]."-".$_[1]->{'group'};
	}
elsif ($config{'append_style'} == 2) {
	return $_[1]->{'group'}.".".$_[0];
	}
elsif ($config{'append_style'} == 3) {
	return $_[1]->{'group'}."-".$_[0];
	}
elsif ($config{'append_style'} == 4) {
	return $_[0]."_".$_[1]->{'group'};
	}
elsif ($config{'append_style'} == 5) {
	return $_[1]->{'group'}."_".$_[0];
	}
else {
	&error("Unknown append_style $config{'append_style'}!");
	}
}

# remove_userdom(name, &domain)
# Returns a username with the domain group stripped off
sub remove_userdom
{
local $g = $_[1]->{'group'};
local $rv = $_[0];
($rv =~ s/(\.|\-|_)\Q$g\E$//) || ($rv =~ s/^\Q$g\E(\.|\-|_)//);
return $rv;
}

# too_long(name)
# Returns an error message if a username is too long for this Unix variant
sub too_long
{
&require_useradmin();
if ($uconfig{'max_length'} && length($_[0]) > $uconfig{'max_length'}) {
	return &text('user_elong', "<tt>$_[0]</tt>", $uconfig{'max_length'});
	}
else {
	return undef;
	}
}

# get_default_ip()
# Returns this system's primary IP address
sub get_default_ip
{
if ($config{'defip'}) {
	return $config{'defip'};
	}
else {
	&foreign_require("net", "net-lib.pl");
	local ($iface) = grep { $_->{'fullname'} eq $config{'iface'} }
			      &net::active_interfaces();
	return $iface->{'address'};
	}
}

# get_apache_log(domain)
# Given a domain name, returns the path to its log file
sub get_apache_log
{
&require_apache();
local ($virt, $vconf) = &get_apache_virtual($_[0]);
if ($virt) {
	local $log = &apache::find_directive("TransferLog", $vconf, 1) ||
	       	     &apache::find_directive("CustomLog", $vconf, 1);
	return $log;
	}
else {
	return undef;
	}
}

# get_apache_virtual(domain)
# Returns the list of configuration directives and the directive for the
# virtual domain itself for some domain
sub get_apache_virtual
{
&require_apache();
local $conf = &apache::get_config();
foreach $v (&apache::find_directive_struct("VirtualHost", $conf)) {
        local $sn = &apache::find_directive("ServerName", $v->{'members'});
	return ($v, $v->{'members'}) if ($sn eq $_[0] ||
					 $sn eq "www.$_[0]");
	local $n;
	foreach $n (&apache::find_directive_struct(
			"ServerAlias", $v->{'members'})) {
		return ($v, $v->{'members'})
			if (&indexof($_[0], @{$n->{'words'}}) >= 0 ||
			    &indexof("www.$_[0]", @{$n->{'words'}}) >= 0);
		}
        }
return ();
}

# check_apache_directives()
# Returns an error string if the default Apache directives don't look valid
sub check_apache_directives
{
local ($d, $gotname, $gotdom, $gotdoc);
local @dirs = split(/\t+/, $config{'apache_config'});
foreach $d (@dirs) {
	$d =~ s/#.*$//;
	if ($d =~ /^ServerName\s+(\S+)$/i) {
		$gotname++;
		$gotdom++ if ($1 eq '$DOM' || $1 eq '${DOM}');
		}
	if ($d =~ /^ServerAlias\s+(.*)$/) {
		$gotdom++ if (&indexof('$DOM', split(/\s+/, $1)) >= 0 ||
			      &indexof('${DOM}', split(/\s+/, $1)) >= 0);
		}
	$gotdoc++ if ($d =~ /^DocumentRoot\s+(.*)$/);
	}
$gotname || return $text{'acheck_ename'};
$gotdom || return $text{'acheck_edom'};
$gotdoc || return $text{'acheck_edoc'};
return undef;
}

sub first_html_print
{
print @_,"<br>\n";
}

sub second_html_print
{
print @_,"<p>\n";
}

# send_domain_email(&domain)
# Sends email to a new domain owner. Returns a pair containing a number
# (0=failed, 1=success) and an optional message. Also outputs status messages.
sub send_domain_email
{
&ensure_template("domain-template");
return (1, undef) if ($config{'domain_template'} eq 'none');
&$first_print($text{'setup_email'});
local $tmpl = $config{'domain_template'} eq 'default' ?
	"$module_config_directory/domain-template" : $config{'domain_template'};
local @erv = &send_template_email($tmpl,
				  $_[0]->{'email'} ||
				    $_[0]->{'user'}.'@'.&get_system_hostname(),
			    	  $_[0], $text{'mail_dsubject'});
if ($erv[0]) {
	&$second_print(&text('setup_emailok', $erv[1]));
	}
else {
	&$second_print(&text('setup_emailfailed', $erv[1]));
	}
}

# send_user_email(&domain, &user)
# Sends email to a new mailbox user. Returns a pair containing a number
# (0=failed, 1=success) and an optional message
sub send_user_email
{
&ensure_template("user-template");
return (1, undef) if ($config{'user_template'} eq 'none');
local $tmpl = $config{'user_template'} eq 'default' ?
	"$module_config_directory/user-template" : $config{'user_template'};
local %hash = ( %{$_[0]}, %{$_[1]} );
$hash{'mailbox'} = &remove_userdom($_[1]->{'user'}, $_[0]);
$hash{'ftp'} = $_[1]->{'shell'} eq $config{'ftp_shell'} ? 1 : 0;
return &send_template_email($tmpl, $hash{'mailbox'}.'@'.$hash{'dom'},
		     	    \%hash, $text{'mail_usubject'});
}

# ensure_template(file)
sub ensure_template
{
&system_logged("cp $module_root_directory/$_[0] $module_config_directory/$_[0]")
	if (!-r "$module_config_directory/$_[0]");
}

# send_template_email(file, address, &substitions, subject)
# Sends the given file to the specified address, with the substitions from
# a hash reference. The actual subs in the file must be like $XXX for entries
# in the hash like xxx - ie. $DOM is replaced by the domain name, and $HOME
# by the home directory
sub send_template_email
{
# Read the file
local $tmpl;
open(FILE, $_[0]) || return (0, &text('mail_file', "<tt>$_[0]</tt>", $!));
while(<FILE>) {
	$tmpl .= $_;
	}
close(FILE);
$tmpl = &substitute_template($tmpl, $_[2]);

# Actually send using the configured mail module
return (0, $text{'mail_system'})
	if (!$config{'mail'} || $config{'mail_system'} == 3);
&require_mail();
local $mail = { 'headers' => [ [ 'From', $config{'from_addr'} ||
					 "root\@".&get_system_hostname() ],
			       [ 'To', $_[1] ],
			       [ 'Subject', $_[3] ],
			       [ 'Content-type', 'text/plain' ] ],
		'body' => $tmpl };
&foreign_call($config{'mail_system'} == 1 ? "sendmail" : "postfix" ,
	      "send_mail", $mail);
return (1, &text('mail_ok', $_[1]));
}

# substitute_template(text, &hash)
# Given some text and a hash reference, for each ocurrance of $FOO or ${FOO} in
# the text replaces it with the value of the hash key foo
sub substitute_template
{
# Add some extra fixed parameters to the hash
local %hash = %{$_[1]};
$hash{'hostname'} = &get_system_hostname();

# Actually do the substition
local $rv = $_[0];
local $s;
foreach $s (keys %hash) {
	local $us = uc($s);
	local $sv = $hash{$s};
	$rv =~ s/\$\{\Q$us\E\}/$sv/g;
	$rv =~ s/\$\Q$us\E/$sv/g;
	if ($sv) {
		$rv =~ s/\$\{IF-\Q$us\E\}(\n?)([\000-\377]*)\$\{ELSE-\Q$us\E\}(\n?)([\000-\377]*)\$\{ENDIF-\Q$us\E\}(\n?)/\2/g;
		$rv =~ s/\$\{IF-\Q$us\E\}(\n?)([\000-\377]*)\$\{ENDIF-\Q$us\E\}(\n?)/\2/g;

		$rv =~ s/\$IF-\Q$us\E(\n?)([\000-\377]*)\$ELSE-\Q$us\E(\n?)([\000-\377]*)\$ENDIF-\Q$us\E(\n?)/\2/g;
		$rv =~ s/\$IF-\Q$us\E(\n?)([\000-\377]*)\$ENDIF-\Q$us\E(\n?)/\2/g;
		}
	else {
		$rv =~ s/\$\{IF-\Q$us\E\}(\n?)([\000-\377]*)\$\{ELSE-\Q$us\E\}(\n?)([\000-\377]*)\$\{ENDIF-\Q$us\E\}(\n?)/\4/g;
		$rv =~ s/\$\{IF-\Q$us\E\}(\n?)([\000-\377]*)\$\{ENDIF-\Q$us\E\}(\n?)//g;

		$rv =~ s/\$IF-\Q$us\E(\n?)([\000-\377]*)\$ELSE-\Q$us\E(\n?)([\000-\377]*)\$ENDIF-\Q$us\E(\n?)/\4/g;
		$rv =~ s/\$IF-\Q$us\E(\n?)([\000-\377]*)\$ENDIF-\Q$us\E(\n?)//g;
		}
	}
return $rv;
}

# alias_type(string)
# Return the type and destination of some alias string
sub alias_type
{
local @rv;
if ($_[0] =~ /^\|$module_config_directory\/autoreply.pl\s+(\S+)/) {
        @rv = (5, $1);
        }
elsif ($_[0] =~ /^\|$module_config_directory\/filter.pl\s+(\S+)/) {
        @rv = (6, $1);
        }
elsif ($_[0] =~ /^\|(.*)$/) {
        @rv = (4, $1);
        }
elsif ($_[0] =~ /^(\/.*)$/) {
        @rv = (3, $1);
        }
elsif ($_[0] =~ /^:include:(.*)$/) {
        @rv = (2, $1);
        }
elsif ($_[0] =~ /^\\(\S+)$/) {
        @rv = (7, $1);
        }
else {
        @rv = (1, $_[0]);
        }
return wantarray ? @rv : $rv[0];
}

# set_domain_envs(&domain, action)
# Sets up VIRTUALSERVER_ environment variables for a domain update or some kind,
# prior to calling making_changes or made_changes. action must be one of
# CREATE_DOMAIN, MODIFY_DOMAIN or DELETE_DOMAIN
sub set_domain_envs
{
local $e;
foreach $e (keys %ENVS) {
	delete($ENV{$e}) if ($e =~ /^VIRTUALSERVER_/);
	}
$ENV{'VIRTUALSERVER_ACTION'} = $_[1];
foreach $e (keys %{$_[0]}) {
	$ENV{'VIRTUALSERVER_'.uc($e)} = $_[0]->{$e};
	}
}

# making_changes()
# Called before a domain is created, modified or deleted to run the
# pre-change command
sub making_changes
{
if ($config{'pre_command'} =~ /\S/) {
	local $out = &backquote_logged("($config{'pre_command'}) 2>&1 </dev/null");
	return $? ? $out : undef;
	}
return undef;
}

# made_changes()
# Called after a domain has been created, modified or deleted to run the
# post-change command
sub made_changes
{
if ($config{'post_command'} =~ /\S/) {
	local $out = &backquote_logged("($config{'post_command'}) 2>&1 </dev/null");
	return $? ? $out : undef;
	}
return undef;
}

# switch_to_domain_user(&domain)
# Changes the current UID and GID to that of the domain's unix user
sub switch_to_domain_user
{
($(, $)) = ( $_[0]->{'ugid'},
	     "$_[0]->{'ugid'} ".join(" ", $_[0]->{'ugid'},
					 &other_groups($_[0]->{'user'})) );
($<, $>) = ( $_[0]->{'uid'}, $_[0]->{'uid'} );
$ENV{'USER'} = $ENV{'LOGNAME'} = $_[0]->{'user'};
$ENV{'HOME'} = $_[0]->{'home'};
}

sub print_subs_table
{
print "<table>\n";
foreach $k (sort { $a cmp $b } keys %text) {
	if ($k =~ /^sub_([A-Z]+)$/) {
		print "<tr> <td><tt><b>\${$1}</b></td>\n";
		print "<td>",$text{$k},"</td> </tr>\n";
		}
	}
print "</table>\n";
print "$text{'sub_if'}<p>\n";
}

# alias_form(&to, left, &domain, "user"|"alias", user|alias)
sub alias_form
{
local @typenames = map { $text{"alias_type$_"} } (0 .. 7);
$typenames[0] = "&lt;$typenames[0]&gt;";

local $left = $_[1];
local @values = @{$_[0]};
local $i;
for($i=0; $i<=@values+2; $i++) {
	print "<tr> <td>$left</td> <td>\n";
	$left = "";
	local ($type, $val) = $values[$i] ? &alias_type($values[$i]) : (0, "");
	print "<select name=type_$i>\n";
	local $j;
	for($j=0; $j<@typenames; $j++) {
		if (!$j || $can_alias_types{$j} ||
		    $type == $j) {
			printf "<option value=$j %s>$typenames[$j]\n",
				$type == $j ? "selected" : "";
			}
		}
	print "</select>\n";
	print "<input name=val_$i size=30 value=\"$val\">\n";
	if ($config{'edit_afiles'} || !$access{'noconfig'}) {
		local $prog = $type == 2 ? "edit_afile.cgi" :
			      $type == 5 ? "edit_rfile.cgi" :
			      $type == 6 ? "edit_ffile.cgi" : undef;
		if ($prog) {
			print "<a href='$prog?dom=$_[2]->{'id'}&file=$val&$_[3]=$_[4]'>$text{'alias_afile'}</a>\n";
			}
		}
	print "</td> </tr>\n";
	}
}

# parse_alias()
# Returns a list of values for an alias, taken from the form generated by
# &alias_form
sub parse_alias
{
local (@values, $i, $t);
for($i=0; defined($t = $in{"type_$i"}); $i++) {
	!$t || $can_alias_types{$t} ||
		&error($text{'alias_etype'});
	local $v = $in{"val_$i"};
	$v =~ s/^\s+//;
	$v =~ s/\s+$//;
	if ($t == 1 && $v !~ /^(\S+)$/) {
		&error(&text('alias_etype1', $v));
		}
	elsif ($t == 3 && $v !~ /^\/(\S+)$/) {
		&error(&text('alias_etype3', $v));
		}
	elsif ($t == 4) {
		$v =~ /^(\S+)/ || &error($text{'alias_etype4none'});
		(-x $1) && &check_aliasfile($1, 0) ||
			&error(&text('asave_etype4', $1));
		}
	elsif ($t == 7 && !defined(getpwnam($v))) {
		&error(&text('asave_etype7', $v));
		}
	if ($t == 1 || $t == 3) { push(@values, $v); }
	elsif ($t == 2) {
		$v = "$d->{'home'}/$v" if ($v !~ /^\//);
		push(@values, ":include:$v");
		}
	elsif ($t == 4) {
		$v = "$d->{'home'}/$v" if ($v !~ /^\//);
		push(@values, "|$v");
		}
	elsif ($t == 5) {
		# Setup autoreply script
		$v = "$d->{'home'}/$v" if ($v !~ /^\//);
		push(@values, "|$module_config_directory/autoreply.pl ".
			      "$v $name");
		&system_logged("cp autoreply.pl $module_config_directory");
		&system_logged("chmod 755 $module_config_directory/config");
		if (-d $sendmail::config{'smrsh_dir'}) {
			&system_logged("ln -s $module_config_directory/autoreply.pl $sendmail::config{'smrsh_dir'}/autoreply.pl");
			}
		}
	elsif ($t == 6) {
		# Setup filter script
		$v = "$d->{'home'}/$v" if ($v !~ /^\//);
		push(@values, "|$module_config_directory/filter.pl ".
			      "$v $name");
		&system_logged("cp filter.pl $module_config_directory");
		&system_logged("chmod 755 $module_config_directory/config");
		if (-d $sendmail::config{'smrsh_dir'}) {
			&system_logged("ln -s $module_config_directory/filter.pl $sendmail::config{'smrsh_dir'}/filter.pl");
			}
		}
	elsif ($t == 7) {
		push(@values, "\\$v");
		}
	}
return @values;
}

# set_pass_change(&user)
sub set_pass_change
{
&require_useradmin();
local $pft = &useradmin::passfiles_type();
if ($pft == 2 || $pft == 5) {
	$_[0]->{'change'} = int(time() / (60*60*24));
	}
elsif ($pft == 4) {
	$_[0]->{'change'} = time();
	}
}

# build_taken(&uid-taken, &username-taken, [&users])
# Fills in the the given hashes with used usernames and UIDs
sub build_taken
{
&require_useradmin();
local @users = $_[2] ? @{$_[2]} : &useradmin::list_users();
%{$_[0]} = map { $_->{'uid'}, 1 } @users;
%{$_[1]} = map { $_->{'user'}, 1 } @users;
}

# build_group_taken(&gid-taken, &groupname-taken, [&groups])
# Fills in the the given hashes with used group names and GIDs
sub build_group_taken
{
&require_useradmin();
local @groups = $_[2] ? @{$_[2]} : &useradmin::list_groups();
%{$_[0]} = map { $_->{'gid'}, 1 } @groups;
%{$_[1]} = map { $_->{'group'}, 1 } @groups;
}

# allocate_uid(&uid-taken)
sub allocate_uid
{
local $uid = $uconfig{'base_uid'};
while($_[0]->{$uid}) {
	$uid++;
	}
return $uid;
}

# allocate_gid(&gid-taken)
sub allocate_gid
{
local $gid = $uconfig{'base_gid'};
while($_[0]->{$gid}) {
	$gid++;
	}
return $gid;
}

# server_home_directory(&domain)
# Returns the home directory for a new virtual server user
sub server_home_directory
{
if ($config{'home_format'}) {
	# Use the template from the module config
	local $home = "$home_base/$config{'home_format'}";
	return &substitute_template($home, $_[0]);
	}
else {
	# Just use the Users and Groups module settings
	return &useradmin::auto_home_dir($home_base, $_[0]->{'user'},
						     $_[0]->{'ugroup'});
	}
}

# set_quota(user, filesystem, quota)
sub set_quota
{
&require_useradmin();
if ($config{'hard_quotas'}) {
	&quota::edit_user_quota($_[0], $_[1],
				int($_[2]), int($_[2]), 0, 0);
	}
else {
	&quota::edit_user_quota($_[0], $_[1],
				int($_[2]), 0, 0, 0);
	}
}

# set_server_quotas(&domain)
# Set the user and possibly group quotas for a domain
sub set_server_quotas
{
if ($config{'home_quotas'}) {
	&set_quota($_[0]->{'user'}, $config{'home_quotas'}, $_[0]->{'uquota'});
	}
if ($config{'mail_quotas'} &&
    $config{'mail_quotas'} ne $config{'home_quotas'}) {
	&set_quota($_[0]->{'user'}, $config{'mail_quotas'}, $_[0]->{'uquota'});
	}
if ($config{'group_quotas'}) {
	&require_useradmin();
	if ($config{'hard_quotas'}) {
		&quota::edit_group_quota(
			$_[0]->{'group'}, $config{'home_quotas'},
			int($_[0]->{'quota'}), int($_[0]->{'quota'}), 0, 0);
		}
	else {
		&quota::edit_group_quota(
			$_[0]->{'group'}, $config{'home_quotas'},
			int($_[0]->{'quota'}), 0, 0, 0);
		}
	}
}

1;

