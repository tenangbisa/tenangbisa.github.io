line1=Opcje konfigurowalne,11
auto=Automatycznie dołącz pliki dziennika z,2,apache-Apache,squid-Squid,proftpd-ProFTPd,wuftpd-WUFTPd
naked=Dodać nagłówek i stopkę webmina do raportu Webalizera?,1,0-Tak,1-Nie
skip_old=Uwzględnić stare (rotated) pliki dziennika (logów)?,1,0-Tak,1-Nie
line2=Konfiguracja systemu,11
webalizer=Ścieżka do komendy webalizer,0
webalizer_conf=Ścieżka do pliku konfiguracyjnego webalizera,0
alt_conf=Przykładowy plik konfiguracyjny webalizera,3,Brak
