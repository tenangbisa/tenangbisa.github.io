desc_pl=Webalizer - Analiza logów
longdesc_pl=Generuje raporty z serwera www, proxy i FTP
