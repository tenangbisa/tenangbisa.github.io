desc_pl=Logi systemowe
