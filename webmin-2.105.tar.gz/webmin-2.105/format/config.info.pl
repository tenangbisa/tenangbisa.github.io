metastat_path=Pełna ścieżka do <tt>metastat</tt>,0
metadb_path=Pełna ścieżka do <tt>metadb</tt>,0
