exports_file=Plik 'exports',0
restart_command=Polecenie restartujące mountd i&nbsp;nfsd,0
