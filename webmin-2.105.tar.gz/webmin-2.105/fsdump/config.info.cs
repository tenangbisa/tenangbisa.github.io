date_subs=Vytvořit <tt>strftime</tt> substituce cílů pro zálohování?,1,1-ano,0-ne
smtp_server=Odesílat mail přes SMTP server,3,Lokální spouštěč Sendmailu
run_mode=Spouštět zálohování v,1,0-Popředí,1-Pozadí
always_tar=Při zálohování vždy používat formát TAR?,1,1-Ano,0-Ne
error_email=Poslat zálohovací mail,1,0-Vždy,1-Jen v případě chyby
simple_sched=Formát pro plánovač,1,1-Jednoduchý,0-Komplexní
