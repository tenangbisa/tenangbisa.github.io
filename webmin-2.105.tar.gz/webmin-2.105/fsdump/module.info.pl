desc_pl=Kopia zapasowa systemu plików
longdesc_pl=Twórz i przywracaj kopie zapasowe systemu plików
