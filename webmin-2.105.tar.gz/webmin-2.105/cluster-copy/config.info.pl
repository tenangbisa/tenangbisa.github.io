sort_mode=Sortuj kopie komend według,1,0-Utworzenia,1-Nazwy pliku,2-Serwerów docelowych
