# newmods.pl
# Updates an acl file to include new modules. Called with the parameters
# <config directory> <module>+

for($i=1; $i<@ARGV; $i++) {
	if (!(-d "$ARGV[0]/$ARGV[$i]")) {
		push(@new, $ARGV[$i]);
		}
	}

if (@new) {
	open(ACL, "$ARGV[0]/webmin.acl");
	@acl = <ACL>;
	close(ACL);
	open(ACL, "> $ARGV[0]/webmin.acl");
	$a = shift(@acl);
	$a =~ /^(\S+):\s*(.*)$/;
	$name = $1; @list = split(/\s+/, $2);
	foreach $o (@list) { $old{$o}++; }
	foreach $n (@new) {
		push(@list, $n) if (!$old{$n});
		}
	print ACL "$name: ",join(" ",@list),"\n";
	print ACL @acl;
	close(ACL);
	}

