# maketemp.pl
# Create the /tmp/.webmin directory if needed

$tmp_dir = "/tmp/.webmin";

if (!-d $tmp_dir) {
	mkdir($tmp_dir, 0755) || exit 1;
	chown($<, $(, $tmp_dir);
	chmod(0755, $tmp_dir);
	}
@st = stat($tmp_dir);
if (@st && $st[4] == $< && $st[5] == $( && $st[2] & 0x4000 &&
    ($st[2] & 0777) == 0755) {
	exit 0;
	}
else {
	exit 1;
	}

