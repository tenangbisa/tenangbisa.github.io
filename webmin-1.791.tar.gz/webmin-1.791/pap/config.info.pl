pap_file=Plik hase� PAP,0
encrypt_pass=Szyfrowa� has�a w&nbsp; pliku,1,1-Tak,0-Nie

