desc_pl=Stan systemu i&nbsp;serwer�w
longdesc_pl=Wy�wietl stan us�ug na twoim i zdalnym systemie.
