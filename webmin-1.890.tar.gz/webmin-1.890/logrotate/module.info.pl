desc_pl=Rotacja log�w
longdesc_pl=Ustaw automatyczn� rotacj� dla Apache, Squid, Syslog i innych plik�w log�w.
