desc_pl=WU-FTP - serwer
longdesc_pl=Konfiguracja dost�pu, anonimowego FTP i innych opcji dla WU-FTPd.
