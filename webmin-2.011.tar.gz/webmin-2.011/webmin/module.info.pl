desc_pl=Konfiguracja Webmina
longdesc_pl=Skonfiguruj Webmina dla siebie przez np. ustawienie dozwolonych hostów, SSL instalowanie modułów i szablonów.
