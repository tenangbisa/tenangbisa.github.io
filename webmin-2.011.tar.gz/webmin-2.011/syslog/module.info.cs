desc_cs=Systémové logy
