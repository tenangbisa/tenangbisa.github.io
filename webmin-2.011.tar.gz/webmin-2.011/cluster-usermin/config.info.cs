sort_mode=Třídit hosty podle,1,1-Názvu hosta,0-Pořadí přidání,2-Popisu
