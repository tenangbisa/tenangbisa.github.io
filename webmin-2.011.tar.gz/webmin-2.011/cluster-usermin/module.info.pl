desc_pl=Klaster - Serwery Usermin
longdesc_pl=Instaluj i zarządzaj modułami oraz motywami na wszystkich serwerach Usermin.
