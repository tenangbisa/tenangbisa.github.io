desc_cs=Kerberos5
