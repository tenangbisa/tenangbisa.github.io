dfstab_file=Lokalizacja pliku 'exports' NFS-u,0
fstypes_file=Rodzaj współdzielonego systemu plików,3,Brak
share_all_command=Polecenie włączające współdzielenie,0
unshare_all_command=Polecenie wyłączające współdzielenie,0
