// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Maximize/Minimize Editor": "Agrandir/Réduire l'éditeur"
};