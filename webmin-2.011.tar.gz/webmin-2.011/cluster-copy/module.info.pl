desc_pl=Klaster - Kopia plików
longdesc_pl=Zaplanowany transfer plików z tego serwera do innych serwerów w klastrze.
