desc_pl=Partycje na dyskach lokalnych
