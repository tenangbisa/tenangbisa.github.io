browse_server=Serwer&#44; z&nbsp;którego pobierana jest <tt>browse list</tt>,3,localhost
long_fstypes=Używaj długich nazw typów systemów plików,1,1-Tak,0-Nie
fstab_file=Plik zawirający listę systemów plików montowanych przy starcie,0
auto_file=Plik automatycznych montowań po NFS,3
autofs_file=Plik automatycznych montowań kernela,3
smbclient_path=Pełna ścieżka do programu <tt>smbclient</tt>,3
nmblookup_path=Pełna ścieżka do programu <tt>nmblookup</tt>,3
