line1=Opcje konfiguracyjne,11
default_mode=Domyślny sposób wyświetlania procesów,4,last-Ostatnio wybrany,tree-Drzewo procesów,user-Porządek wg użytkownika,size-Porządek wg rozmiaru,cpu-Porządek wg CPU,search-Formularz szukania,run-Formularz uruchomienia
cut_length=Ilość znaków polecenia,3,Nielimitowane
trace_java=Wyświetlaj śledzenie procesów używając,1,1-Aplet Java,0-Tekst
line2=Opcje systemowe,11
ps_style=Styl wyjścia polecenia PS,1,sysv-SYSV,linux-Linux,hpux-HPUX,freebsd-FreeBSD,macos-MacOS
