desc_cs=Změna detailů uživatele
