desc_cs=Prihlaseni Telnetem
