sizemode=Rozmiar apletu,1,0-80x24 znaków (w domyślnej czcionce),1-Maksymalny,2-Niestandardowy
size=Niestandardowy rozmiar &#45; szerokość x wysokość,0
fontsize=Rozmiar czcionki w punktach,3,Domyślnie
detach=Wyświetlaj w osobnym oknie,1,1-Tak,0-Nie
