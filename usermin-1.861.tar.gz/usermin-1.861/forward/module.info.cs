desc_cs=Přeposílání a odpovědi
