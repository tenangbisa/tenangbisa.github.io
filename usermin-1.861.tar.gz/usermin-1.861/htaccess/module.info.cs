desc_cs=Soubory pro volby Apache
