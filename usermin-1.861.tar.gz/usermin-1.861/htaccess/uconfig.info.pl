www_root=Katalog domowy (root) dla web,0
show_names=Wyświetlaj nazwy dyrektyw Apache,1,1-Tak,0-Nie
