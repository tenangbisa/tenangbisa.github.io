desc_pl=Użytkownicy Webmina
longdesc_pl=Twórz użytkowników Webmina i kontroluj, które moduły i funkcje są dla nich dostępne.
