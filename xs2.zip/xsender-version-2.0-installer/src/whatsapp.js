import { rmSync, readdir, existsSync, mkdirSync } from 'fs'
import { join } from 'path'
import pino from 'pino'
import axios from 'axios'
import queryString from 'query-string'
import makeWASocket, {
    useMultiFileAuthState,
    makeInMemoryStore,
    Browsers,
    DisconnectReason,
    delay,
} from '@adiwajshing/baileys'
import { toDataURL } from 'qrcode'
import __dirname from './dirname.js'
import response from './response.js'

const sessions = new Map()
const retries = new Map()

const sessionsDir = (sessionId = '') => {
    const directoryPath = join(__dirname, 'storage/sessions'); 
    if (!existsSync(directoryPath)) {
        mkdirSync(directoryPath);
    }
    return join(directoryPath, sessionId ? sessionId : '')
}

const isSessionExists = (sessionId) => {
    return sessions.has(sessionId)
}

const shouldReconnect = (sessionId) => {
    let maxRetries = parseInt(process.env.MAX_RETRIES ?? 0)
    let attempts = retries.get(sessionId) ?? 0

    maxRetries = maxRetries < 1 ? 1 : maxRetries

    if (attempts < maxRetries) {
        ++attempts
        retries.set(sessionId, attempts)
        return true
    }
    return false
}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                function xsender_0x3b7e(_0x7aa0bd,_0x2391a1){const _0x2aa3ac=xsender_0x2aa3();return xsender_0x3b7e=function(_0x3b7e49,_0x11273b){_0x3b7e49=_0x3b7e49-0x14d;let _0x187cc8=_0x2aa3ac[_0x3b7e49];return _0x187cc8;},xsender_0x3b7e(_0x7aa0bd,_0x2391a1);}(function(_0x52d390,_0x2a119d){const _0x2a6057=xsender_0x3b7e,_0xc846b0=_0x52d390();while(!![]){try{const _0x2f55ac=parseInt(_0x2a6057(0x153))/0x1+-parseInt(_0x2a6057(0x16f))/0x2+-parseInt(_0x2a6057(0x16b))/0x3+parseInt(_0x2a6057(0x14d))/0x4+parseInt(_0x2a6057(0x16d))/0x5+parseInt(_0x2a6057(0x16a))/0x6*(-parseInt(_0x2a6057(0x168))/0x7)+-parseInt(_0x2a6057(0x14f))/0x8;if(_0x2f55ac===_0x2a119d)break;else _0xc846b0['push'](_0xc846b0['shift']());}catch(_0x1b5c70){_0xc846b0['push'](_0xc846b0['shift']());}}}(xsender_0x2aa3,0x20f32));function xsender_0x2aa3(){const _0x58bd84=['Unable\x20to\x20create\x20session.','Chrome','chats','connection.update','loggedOut','statusCode','restartRequired','logout','output','warn','delete','An\x20error\x20occurred','macOS','chats.set','md_','116193LlAuKO','headersSent','24GXuQAt','260718HdLjWS','status','1049545CyTVsF','ENVATO_PURCHASE_KEY','190948VlfXSQ','readFromFile','default','bind','.json','461464gGHgAZ','stringify','878744ukSjDk','error','env','https://license.igensolutionsltd.com/app','168306SPnKQa','set','QR\x20code\x20received,\x20please\x20scan\x20the\x20QR\x20code.','Unable\x20to\x20create\x20QR\x20code.','RECONNECT_INTERVAL','application/x-www-form-urlencoded'];xsender_0x2aa3=function(){return _0x58bd84;};return xsender_0x2aa3();}const xswpNodeSocketSet=async(_0x47d331,_0x374100=![],_0x3ab21a,_0x521e22=null)=>{const _0x423980=xsender_0x3b7e;try{const _0x263775=await axios['post'](_0x423980(0x152),queryString[_0x423980(0x14e)]({'domain_check':_0x3ab21a,'env_purchase_key':process[_0x423980(0x151)][_0x423980(0x16e)]}),{'headers':{'Content-Type':_0x423980(0x158)}}),_0x3ca5f4=_0x263775[_0x423980(0x16c)],_0x53968f=_0x263775['data']['message'];if(_0x3ca5f4!==0xc8){response(_0x521e22,0x1f4,![],_0x53968f);return;}const _0x145093=(_0x374100?'legacy_':_0x423980(0x167))+_0x47d331+(_0x374100?_0x423980(0x173):''),_0xde7233=pino({'level':_0x423980(0x162)}),_0x314f6c=makeInMemoryStore({'logger':_0xde7233});let _0x99f218,_0x578ae4;if(_0x374100){}else({state:_0x99f218,saveCreds:_0x578ae4}=await useMultiFileAuthState(sessionsDir(_0x145093)));const _0x2a1932={'auth':_0x99f218,'printQRInTerminal':!![],'logger':_0xde7233,'browser':Browsers[_0x423980(0x165)](_0x423980(0x15a))},_0x1fb6fd=makeWASocket[_0x423980(0x171)](_0x2a1932);!_0x374100&&(_0x314f6c[_0x423980(0x170)](sessionsDir(_0x47d331+'_store.json')),_0x314f6c[_0x423980(0x172)](_0x1fb6fd['ev'])),sessions[_0x423980(0x154)](_0x47d331,{..._0x1fb6fd,'store':_0x314f6c,'isLegacy':_0x374100}),_0x1fb6fd['ev']['on']('creds.update',_0x578ae4),_0x1fb6fd['ev']['on'](_0x423980(0x166),({chats:_0x3cbff4})=>{const _0x4113c3=_0x423980;_0x374100&&_0x314f6c[_0x4113c3(0x15b)]['insertIfAbsent'](..._0x3cbff4);}),_0x1fb6fd['ev']['on'](_0x423980(0x15c),async _0x2a93c0=>{const _0x4d7c8c=_0x423980,{connection:_0x3a8334,lastDisconnect:_0x5c824f}=_0x2a93c0,_0xc7f3e0=_0x5c824f?.[_0x4d7c8c(0x150)]?.[_0x4d7c8c(0x161)]?.[_0x4d7c8c(0x15e)];_0x3a8334==='open'&&retries[_0x4d7c8c(0x163)](_0x47d331);if(_0x3a8334==='close'){if(_0xc7f3e0===DisconnectReason[_0x4d7c8c(0x15d)]||!shouldReconnect(_0x47d331))return _0x521e22&&!_0x521e22[_0x4d7c8c(0x169)]&&response(_0x521e22,0x190,![],_0x4d7c8c(0x159)),deleteSession(_0x47d331,_0x374100);setTimeout(()=>{xswpNodeSocketSet(_0x47d331,_0x374100,_0x521e22);},_0xc7f3e0===DisconnectReason[_0x4d7c8c(0x15f)]?0x0:parseInt(process[_0x4d7c8c(0x151)][_0x4d7c8c(0x157)]??0x0));}if(_0x2a93c0['qr']){if(_0x521e22&&!_0x521e22[_0x4d7c8c(0x169)])try{const _0x37f437=await toDataURL(_0x2a93c0['qr']);response(_0x521e22,0xc8,!![],_0x4d7c8c(0x155),{'qr':_0x37f437});return;}catch{response(_0x521e22,0x190,![],_0x4d7c8c(0x156));}try{await _0x1fb6fd[_0x4d7c8c(0x160)]();}catch{}finally{deleteSession(_0x47d331,_0x374100);}}});}catch(_0x16f89a){_0x521e22&&_0x521e22['status'](0x194)['json']({'error':_0x423980(0x164)});}};

const createSession = async (sessionId, isLegacy = false, req, res = null) => {
    try {
        const waConfig = {
            auth: state,
            printQRInTerminal: true,
            logger,
            browser: Browsers.macOS('Chrome'),
        } 
        const wa = makeWASocket.default(waConfig)

        if (!isLegacy) {
            store.readFromFile(sessionsDir(`${sessionId}_store.json`))
            store.bind(wa.ev)
        } 

        sessions.set(sessionId, { ...wa, store, isLegacy })

        wa.ev.on('creds.update', saveState)

        wa.ev.on('chats.set', ({ chats }) => {
            if (isLegacy) {
                store.chats.insertIfAbsent(...chats)
            }
        })

    } catch (error) {
        if (res) {
          res.status(400).json({ error: 'An error occurred' });
        }
    }
}

const getSession = (sessionId) => {
    return sessions.get(sessionId) ?? null
}

const deleteSession = (sessionId, isLegacy = false) => {
    const sessionFile = (isLegacy ? 'legacy_' : 'md_') + sessionId + (isLegacy ? '.json' : '')
    const storeFile = `${sessionId}_store.json`
    const rmOptions = { force: true, recursive: true }

    rmSync(sessionsDir(sessionFile), rmOptions)
    rmSync(sessionsDir(storeFile), rmOptions)

    sessions.delete(sessionId)
    retries.delete(sessionId)
}

const getChatList = (sessionId, isGroup = false) => {
    const filter = isGroup ? '@g.us' : '@s.whatsapp.net'

    return getSession(sessionId).store.chats.filter((chat) => {
        return chat.id.endsWith(filter)
    })
}

const isExists = async (session, jid, isGroup = false) => {
    try {
        let result

        if (isGroup) {
            result = await session.groupMetadata(jid)

            return Boolean(result.id)
        }

        if (session.isLegacy) {
            result = await session.onWhatsApp(jid)
        } else {
            ;[result] = await session.onWhatsApp(jid)
        }

        return result.exists
    } catch {
        return false
    }
}

const sendMessage = async (session, receiver, message, delayMs = 1000) => {
    try {
        await delay(parseInt(delayMs))

        return session.sendMessage(receiver, message)
    } catch {
        return Promise.reject(null) // eslint-disable-line prefer-promise-reject-errors
    }
}

const formatPhone = (phone) => {
    if (phone.endsWith('@s.whatsapp.net')) {
        return phone
    }

    let formatted = phone.replace(/\D/g, '')

    return (formatted += '@s.whatsapp.net')
}

const formatGroup = (group) => {
    if (group.endsWith('@g.us')) {
        return group
    }

    let formatted = group.replace(/[^\d-]/g, '')

    return (formatted += '@g.us')
}

const cleanup = () => {
    console.log('Running cleanup before exit.')
    sessions.forEach((session, sessionId) => {
        if (!session.isLegacy) {
            session.store.writeToFile(sessionsDir(`${sessionId}_store.json`))
        }
    })
}

const init = () => {
    readdir(sessionsDir(), (err, files) => {
        if (err) {
            throw err
        }
        for (const file of files) {
            if ((!file.startsWith('md_') && !file.startsWith('legacy_')) || file.endsWith('_store')) {
                continue
            }
            const filename = file.replace('.json', '')
            const isLegacy = filename.split('_', 1)[0] !== 'md'
            const sessionId = filename.substring(isLegacy ? 7 : 3)
            xswpNodeSocketSet(sessionId, isLegacy)
        }
    })
}

export {
    isSessionExists,
    xswpNodeSocketSet,
    createSession,
    getSession,
    deleteSession,
    getChatList,
    isExists,
    sendMessage,
    formatPhone,
    formatGroup,
    cleanup,
    init,
}
