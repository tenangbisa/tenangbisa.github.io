

Update Steps:

    Step-1: Import Update SQL file [if have in this version] to existing database 
    Step-2: Unzip Files.zip to server root 

 Enjoy update version 

 [N:B-If you do not update last one please update first previus one version, iGen will not take any responsibility to if lose your existing data from database or if you customize your script before as your own risk iGen will not take any responsibility]