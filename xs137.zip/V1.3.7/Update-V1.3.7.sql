ALTER TABLE `s_m_slogs` ADD `sms_type` TINYINT(10) NOT NULL DEFAULT '1' AFTER `message`; 
ALTER TABLE `general_settings` ADD `whatsapp_word_count` INT(10) NOT NULL DEFAULT '320' AFTER `schedule_at`, ADD `sms_word_text_count` INT(10) NOT NULL DEFAULT '160' AFTER `whatsapp_word_count`, ADD `sms_word_unicode_count` INT(10) NOT NULL DEFAULT '70' AFTER `sms_word_text_count`; 
