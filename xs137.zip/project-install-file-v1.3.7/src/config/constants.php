<?php

use Illuminate\Support\Str;
return [
      'options' => [
            'modelNamespace' => '\\App\\Models\\',
            'langFilePath' => 'lang//',
        ]
];

