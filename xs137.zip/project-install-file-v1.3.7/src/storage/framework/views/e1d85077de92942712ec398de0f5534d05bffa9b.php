<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	 		<div class="col-lg-12">
	            <div class="card mb-4">
	                <div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
		                            <th><?php echo app('translator')->get('Name'); ?></th>
									<?php if($view == 'user_view'): ?>
		                            	<th><?php echo app('translator')->get('User Name'); ?></th>
									<?php endif; ?>
		                            <th><?php echo app('translator')->get('Message'); ?></th>
									<?php if($view == 'user_view'): ?>
		                            	<th><?php echo app('translator')->get('Status'); ?></th>
									<?php endif; ?>
		                            <th><?php echo app('translator')->get('Action'); ?></th>
		                        </tr>
		                    </thead>
		                    <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			                    <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
				                    <td data-label="<?php echo app('translator')->get('Name'); ?>">
				                    	<?php echo e(__($template->name)); ?>

				                    </td>
									<?php if($view == 'user_view'): ?>
										<td data-label="<?php echo app('translator')->get('User Name'); ?>">
											<?php echo e(__($template->user->name ?? ' ')); ?>

										</td>
									<?php endif; ?>
									<td data-label="<?php echo app('translator')->get('Message'); ?>">
				                    	<?php echo e(__($template->message)); ?>

				                    </td>

									<?php if($template->user_id): ?>
										<td data-label="<?php echo app('translator')->get('Status'); ?>">
											<?php if($template->status ==1): ?>
												<div class="badge bg-primary"><?php echo app('translator')->get('Pendding'); ?></div>
											<?php elseif($template->status ==2): ?>
												<div class="badge bg-success"><?php echo app('translator')->get('Approved'); ?></div>
											<?php elseif($template->status ==3): ?>
												<div class="badge bg-danger"><?php echo app('translator')->get('Rejected'); ?></div>
											<?php endif; ?>
										</td>
									<?php endif; ?>

				                    <td data-label=<?php echo app('translator')->get('Action'); ?>>
										<?php if($view == 'admin_view'): ?>
											<a class="btn--primary text--light template" data-bs-toggle="modal" 		data-bs-target="#updatebrand" href="javascript:void(0)"
											data-id="<?php echo e($template->id); ?>"
											data-name="<?php echo e($template->name); ?>"
											data-message="<?php echo e($template->message); ?>">
												<i class="las la-pen"></i>
											</a>
										<?php elseif($view == 'user_view'): ?>
											<a class="btn--primary text--light statusUpdate" data-bs-toggle="modal" 		data-bs-target="#updateStatus" href="javascript:void(0)"
											data-id="<?php echo e($template->id); ?>" data-status="<?php echo e($template->status); ?>">
											<i class="las la-pen"></i>
										</a>
										<?php endif; ?>
			                    		<a class="btn--danger text--light delete" data-bs-toggle="modal" data-bs-target="#deletetemplate" href="javascript:void(0)"data-id="<?php echo e($template->id); ?>"><i class="las la-trash"></i></a>
				                    </td>
			                    </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			                	<tr>
			                		<td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
			                	</tr>
			                <?php endif; ?>
		                </table>
		            </div>
	                <div class="m-3">
	                	<?php echo e($templates->appends(request()->all())->links()); ?>

					</div>
	            </div>
	        </div>
	    </div>
	</div>
	<?php if($view == 'admin_view'): ?>
		<a href="javascript:void(0);" class="support-ticket-float-btn" data-bs-toggle="modal" data-bs-target="#createTemplate" title="<?php echo app('translator')->get('Create New Message Template'); ?>">
			<i class="fa fa-plus ticket-float"></i>
		</a>
	<?php endif; ?>
</section>


<div class="modal fade" id="createTemplate" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
			<form action="<?php echo e(route('admin.template.store')); ?>" method="POST">
				<?php echo csrf_field(); ?>
	            <div class="modal-body">
	            	<div class="card">
	            		<div class="card-header bg--lite--violet">
	            			<div class="card-title text-center text--light"><?php echo app('translator')->get('Add New Template'); ?></div>
	            		</div>
		                <div class="card-body">
							<div class="mb-3">
								<label for="name" class="form-label"><?php echo app('translator')->get('Name'); ?> <sup class="text--danger">*</sup></label>
								<input type="text" class="form-control" id="name" name="name" placeholder="<?php echo app('translator')->get('Enter Name'); ?>" required>
							</div>

							<div class="mb-3">
								<label for="message" class="form-label"><?php echo app('translator')->get('Message'); ?> <sup class="text--danger">*</sup></label>
								<textarea rows="5"  class="form-control" id="message" name="message" placeholder="<?php echo app('translator')->get('Enter Message'); ?>" required=""></textarea>
							</div>
						</div>
	            	</div>
	            </div>

	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"><?php echo app('translator')->get('Cancel'); ?></button>
	                <button type="submit" class="bg--success"><?php echo app('translator')->get('Submit'); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>


<div class="modal fade" id="updatetemplate" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
			<form action="<?php echo e(route('admin.template.update')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="id">
	            <div class="modal-body">
	            	<div class="card">
	            		<div class="card-header bg--lite--violet">
	            			<div class="card-title text-center text--light"><?php echo app('translator')->get('Update Group'); ?></div>
	            		</div>
		                <div class="card-body">
							<div class="mb-3">
								<label for="name" class="form-label"><?php echo app('translator')->get('Name'); ?> <sup class="text--danger">*</sup></label>
								<input type="text" class="form-control" id="name" name="name" placeholder="<?php echo app('translator')->get('Enter Name'); ?>" required>
							</div>

							<div class="mb-3">
								<label for="message" class="form-label"><?php echo app('translator')->get('Message'); ?> <sup class="text--danger">*</sup></label>
								<textarea rows="5"  class="form-control" id="message" name="message" placeholder="<?php echo app('translator')->get('Enter Message'); ?>" required=""></textarea>
							</div>
						</div>
	            	</div>
	            </div>

	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"><?php echo app('translator')->get('Cancel'); ?></button>
	                <button type="submit" class="bg--success"><?php echo app('translator')->get('Submit'); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>
<div class="modal fade" id="updateStatus" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
			<form action="<?php echo e(route('admin.template.userStatus.update')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="id">
	            <div class="modal-body">
	            	<div class="card">
	            		<div class="card-header bg--lite--violet">
	            			<div class="card-title text-center text--light"><?php echo app('translator')->get('Status Update'); ?></div>
	            		</div>
		                <div class="card-body">
							<div class="mb-3" id="statusAppend">

							</div>
						</div>
	            	</div>
	            </div>

	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"><?php echo app('translator')->get('Cancel'); ?></button>
	                <button type="submit" class="bg--success"><?php echo app('translator')->get('Update'); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>



<div class="modal fade" id="deletetemplate" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="<?php echo e(route('admin.template.delete')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="id">
				<div class="modal_body2">
					<div class="modal_icon2">
						<i class="las la-trash-alt"></i>
					</div>
					<div class="modal_text2 mt-3">
						<h6><?php echo app('translator')->get('Are you sure to want delete this group?'); ?></h6>
					</div>
				</div>
				<div class="modal_button2">
					<button type="button" class="" data-bs-dismiss="modal"><?php echo app('translator')->get('Cancel'); ?></button>
					<button type="submit" class="bg--danger"><?php echo app('translator')->get('Delete'); ?></button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scriptpush'); ?>
<script>
	(function($){
		"use strict";
		$('.template').on('click', function(){
			var modal = $('#updatetemplate');
			modal.find('input[name=id]').val($(this).data('id'));
			modal.find('input[name=name]').val($(this).data('name'));
			modal.find('textarea[name=message]').val($(this).data('message'));
			modal.modal('show');
		});
		$('.statusUpdate').on('click', function(){
			var modal = $('#updateStatus');
			modal.find('input[name=id]').val($(this).data('id'));
			var value = $(this).data('status');
			$('#statusAppend').html('')
			$('#statusAppend').html(`
				<label for="status" class="form-label"><?php echo app('translator')->get('Status'); ?> <sup class="text--danger">*</sup></label>
				<select name="status" id="status" class="form-control" >
					<option  ${value == 1 ? 'selected' : ''} value="1"><?php echo app('translator')->get('Pendding'); ?></option>
					<option  ${value == 2 ? 'selected' : ''} value="2"><?php echo app('translator')->get('Approve'); ?></option>
					<option  ${value == 3 ? 'selected' : ''} value="3"><?php echo app('translator')->get('Reject'); ?></option>
				</select>
			`)
			modal.modal('show');
		});

		$('.delete').on('click', function(){
			var modal = $('#deletetemplate');
			modal.find('input[name=id]').val($(this).data('id'));
			modal.modal('show');
		});
	})(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/template/index.blade.php ENDPATH**/ ?>