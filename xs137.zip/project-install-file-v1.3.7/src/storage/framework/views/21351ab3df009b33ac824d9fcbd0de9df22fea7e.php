<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	 		<div class="col-lg-12 p-1">
	            <div class="rounded_box">
                	<div class="row align--center px-3">
                		<div class="col-12 col-md-4 col-lg-4 col-xl-5">
                    		<h6 class="my-3"> <?php echo e(translate('Set Mail Default Options')); ?></h6>
                    	</div>
	                    <div class="col-12 col-md-8 col-lg-8 col-xl-7">
	                		<div class="row justify-content-end">
			                    <div class="col-12 col-lg-6 col-xl-6 px-2 py-1 ">
				                    <form action="<?php echo e(route('admin.mail.send.method')); ?>" method="POST" class="form-inline float-sm-right text-end">
				                    	<?php echo csrf_field(); ?>
				                     	<div class="input-group mb-3 w-100">
										  	<select class="form-control" name="id" required="">
										  		<?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    	<option value="<?php echo e($mail->id); ?>" <?php if($general->email_gateway_id == $mail->id): ?> selected <?php endif; ?>><?php echo e(strtoupper($mail->name)); ?></option>
							                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										  	</select>
										  	<button class="btn--primary input-group-text input-group-text" id="basic-addon2" type="submit"> <?php echo e(translate('Email Send Method')); ?></button>
										</div>
							        </form>
							    </div>
							</div>
	                	</div>
	                </div>
	                <div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
		                            <th> <?php echo e(translate('Name')); ?></th>
		                            <th> <?php echo e(translate('Status')); ?></th>
		                            <th> <?php echo e(translate('Action')); ?></th>
		                        </tr>
		                    </thead>
		                    <?php $__empty_1 = true; $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			                    <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
				                    <td data-label=" <?php echo e(translate('Name')); ?>">
				                    	<?php echo e(__($mail->name)); ?>

				                    	<?php if($general->email_gateway_id == $mail->id): ?>
					                    	<span class="text--success fs-5">
					                    		<i class="las la-check-double"></i>
					                    	</span>
					                    <?php endif; ?>
				                    </td>
				                    <td data-label=" <?php echo e(translate('Status')); ?>">
				                    	<?php if($mail->status == 1): ?>
				                    		<span class="badge badge--success"> <?php echo e(translate('Active')); ?></span>
				                    	<?php else: ?>
				                    		<span class="badge badge--danger"> <?php echo e(translate('Inactive')); ?></span>
				                    	<?php endif; ?>
				                    </td>
				                    <td data-label= <?php echo e(translate('Action')); ?>>
				                    	<?php if($mail->driver_information): ?>
			                    			<a class="btn--primary text--light" href="<?php echo e(route('admin.mail.edit', $mail->id)); ?>"><i class="las la-pen"></i></a>
			                    		<?php else: ?>
			                    			<span> <?php echo e(translate('N/A')); ?></span>
			                    		<?php endif; ?>
				                    </td>
			                    </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			                	<tr>
			                		<td class="text-muted text-center" colspan="100%"> <?php echo e(translate('No Data Found')); ?></td>
			                	</tr>
			                <?php endif; ?>
		                </table>
		            </div>
	            </div>
	        </div>
	    </div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/mail/index.blade.php ENDPATH**/ ?>