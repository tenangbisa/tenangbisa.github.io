
<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	    	<div class="col-lg-12">
	            <div class="card mb-4">
	                <div class="card-body">
	                    <form action="<?php echo e(route('admin.whatsapp.search',$scope ?? str_replace('admin.whatsapp.', '', request()->route()->getName()))); ?>" method="GET">
	                        <div class="row align-items-center">
	                            <div class="col-lg-5">
	                                <label><?php echo e(translate('By User/Email/To Recipient Number')); ?></label>
	                                <input type="text" autocomplete="off" name="search" value="" placeholder="<?php echo e(translate('Search with User, Email or To Recipient number')); ?>" class="form-control" id="search" value="<?php echo e(@$search); ?>">
	                            </div>
	                            <div class="col-lg-5">
	                                <label><?php echo e(translate('By Date')); ?></label>
	                                <input type="text" class="form-control datepicker-here" name="date" value="<?php echo e(@$searchDate); ?>" data-range="true" data-multiple-dates-separator=" - " data-language="en" data-position="bottom right" autocomplete="off" placeholder="<?php echo e(translate('From Date-To Date')); ?>" id="date">
	                            </div>
	                            <div class="col-lg-2">
	                                <button class="btn btn--primary w-100 h-45 mt-4" type="submit">
	                                    <i class="fas fa-search"></i> <?php echo e(translate('Search')); ?>

	                                </button>
	                            </div>
	                        </div>
	                    </form>
	                </div>
	            </div>
	        </div>

            <div class="py-3">
                <button class="btn btn-primary d-none d-md-flex statusupdate"
                    data-bs-toggle="tooltip"
                    data-bs-placement="top" title="Status Update"
                    data-bs-toggle="modal"
                    data-bs-target="#smsstatusupdate"><?php echo e(translate('Status Update')); ?></button>
            </div>

	 		<div class="col-lg-12">
	            <div class="card mb-4">
	                <div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
                                    <th class="d-flex align-items-center">
                                        <input class="form-check-input mt-0 me-2 checkAll"
                                               type="checkbox"
                                               value=""
                                               aria-label="Checkbox for following text input"> <?php echo e(translate('#')); ?>

                                    </th>
		                            <th><?php echo e(translate('User')); ?></th>
		                            <th><?php echo e(translate('Sender')); ?></th>
		                            <th><?php echo e(translate('To')); ?></th>
		                            <th><?php echo e(translate('Credit ')); ?></th>
		                            <th><?php echo e(translate('Initiated')); ?></th>
		                            <th><?php echo e(translate('Status')); ?></th>
		                            <th><?php echo e(translate('Action')); ?></th>
		                        </tr>
		                    </thead>
		                    <?php $__empty_1 = true; $__currentLoopData = $smslogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smsLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

			                    <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
                                    <td class="d-none d-md-flex align-items-center">
                                        <input class="form-check-input mt-0 me-2" type="checkbox" name="whatsappid" value="<?php echo e($smsLog->id); ?>" aria-label="Checkbox for following text input">
                                        <?php echo e($loop->iteration); ?>

                                    </td>

				                     <td data-label="<?php echo e(translate('User')); ?>">
				                     	<?php if($smsLog->user_id): ?>
				                    		<a href="<?php echo e(route('admin.user.details', $smsLog->user_id)); ?>" class="fw-bold text-dark"><?php echo e(__($smsLog->user->email)); ?></a>
				                    	<?php else: ?>
				                    		<span><?php echo e(translate('Admin')); ?></span>
				                    	<?php endif; ?>
				                    </td>


				                    <td data-label="<?php echo e(translate('Sender')); ?>">

				                     	<?php if($smsLog->whatsappGateway): ?>
                                         <?php echo e(translate('WhatsApp Gateway')); ?> <i class="las la-arrow-right"></i> <span class="text--success fw-bold"><?php echo e(ucfirst($smsLog->whatsappGateway->name)); ?></span>
				                    	<?php endif; ?>
				                    </td>

				                    <td data-label="<?php echo e(translate('To')); ?>">
				                    	<?php echo e($smsLog->to); ?>

				                    </td>

				                     <td data-label="<?php echo e(translate('Credit')); ?>">
				                    	<?php
									        $messages = str_split($smsLog->message,160);
									        $totalMessage = count($messages);
									    ?>
									    <?php echo e($totalMessage); ?> <?php echo e(translate('Credit')); ?>

				                    </td>

				                    <td data-label="<?php echo e(translate('Initiated')); ?>">
				                    	<?php echo e(getDateTime($smsLog->initiated_time)); ?>

				                    </td>

				                    <td data-label="<?php echo e(translate('Status')); ?>">
				                    	<?php if($smsLog->status == 1): ?>
				                    		<span class="badge badge--primary"><?php echo e(translate('Pending ')); ?></span>
				                    	<?php elseif($smsLog->status == 2): ?>
				                    		<span class="badge badge--info"><?php echo e(translate('Schedule')); ?></span>
				                    	<?php elseif($smsLog->status == 3): ?>
				                    		<span class="badge badge--danger"><?php echo e(translate('Fail')); ?></span>
				                    	<?php elseif($smsLog->status == 4): ?>
				                    		<span class="badge badge--success"><?php echo e(translate('Delivered')); ?></span>
				                    	<?php elseif($smsLog->status == 5): ?>
				                    		<span class="badge badge--primary"><?php echo e(translate('Processing')); ?></span>
				                    	<?php endif; ?>
				                    	<a class="s_btn--coral text--light statusupdate"
				                    		data-id="<?php echo e($smsLog->id); ?>"
				                    		data-bs-toggle="tooltip"
				                    		data-bs-placement="top" title="Status Update"
				                    		data-bs-toggle="modal"
				                    		data-bs-target="#smsstatusupdate"
			                    			><i class="las la-info-circle"></i></a>
				                    </td>

				                    <td data-label=<?php echo e(translate('Action')); ?>>
			                    		<a class="btn--primary text--light details"
			                    		data-message="<?php echo e($smsLog->message); ?>"
			                    		data-response_gateway="<?php echo e($smsLog->response_gateway); ?>"
			                    		data-bs-toggle="tooltip"
			                    		data-bs-placement="top" title="Details"
			                    		data-bs-toggle="modal"
			                    		data-bs-target="#smsdetails"
				                    		><i class="las la-desktop"></i></a>

				                    	<a href="javascript:void(0)" class="btn--danger text--light smsdelete"
				                    		data-bs-toggle="modal"
				                    		data-bs-target="#delete"
				                    		data-delete_id="<?php echo e($smsLog->id); ?>"
				                    		><i class="las la-trash"></i>
				                    </td>
			                    </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			                	<tr>
			                		<td class="text-muted text-center" colspan="100%"><?php echo e(translate('No Data Found')); ?></td>
			                	</tr>
			                <?php endif; ?>
		                </table>
	            	</div>
	                <div class="m-3">
	                	<?php echo e($smslogs->appends(request()->all())->links()); ?>

					</div>
	            </div>
	        </div>
	    </div>
	</div>
</section>


<div class="modal fade" id="smsstatusupdate" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
			<form action="<?php echo e(route('admin.whatsapp.status.update')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="id">
				<input type="hidden" name="smslogid">
	            <div class="modal-body">
	            	<div class="card">
	            		<div class="card-header bg--lite--violet">
	            			<div class="card-title text-center text--light"><?php echo e(translate('WhatsApp Status Update')); ?></div>
	            		</div>
		                <div class="card-body">
							<div class="mb-3">
								<label for="status" class="form-label"><?php echo e(translate('Status')); ?> <sup class="text--danger">*</sup></label>
								<select class="form-control" name="status" id="status" required>
									<option value="" selected="" disabled=""><?php echo e(translate('Select Status')); ?></option>
									<option value="1"><?php echo e(translate('Pending')); ?></option>
									<option value="4"><?php echo e(translate('Success')); ?></option>
									<option value="3"><?php echo e(translate('Fail')); ?></option>
								</select>
							</div>
						</div>
	            	</div>
	            </div>

	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--success"><?php echo e(translate('Submit')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>


<div class="modal fade" id="smsdetails" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
            	<div class="card">
            		<div class="card-header bg--lite--violet">
            			<div class="card-title text-center text--light"><?php echo e(translate('Message')); ?></div>
            		</div>
        			<div class="card-body mb-3">
        				<p id="message--text"></p>
        			</div>
        		</div>
        	</div>

            <div class="modal_button2">
                <button type="button" class="w-100" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        	<form action="<?php echo e(route('admin.whatsapp.delete')); ?>" method="POST">
        		<?php echo csrf_field(); ?>
        		<input type="hidden" name="id" value="">
	            <div class="modal_body2">
	                <div class="modal_icon2">
	                    <i class="las la-trash-alt"></i>
	                </div>
	                <div class="modal_text2 mt-3">
	                    <h6><?php echo e(translate('Are you sure to delete this message from log')); ?></h6>
	                </div>
	            </div>
	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--danger"><?php echo e(translate('Delete')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scriptpush'); ?>
<script>
	(function($){
		"use strict";
		$('.statusupdate').on('click', function(){
			var modal = $('#smsstatusupdate');
			modal.find('input[name=id]').val($(this).data('id'));
			modal.modal('show');
		});

		$('.details').on('click', function(){
			var modal = $('#smsdetails');
			var message = $(this).data('message');
			var response_gateway = $(this).data('response_gateway');
			$("#message--text").text(message+" :: "+response_gateway);
			modal.modal('show');
		});

		$('.smsdelete').on('click', function(){
			var modal = $('#delete');
			modal.find('input[name=id]').val($(this).data('delete_id'));
			modal.modal('show');
		});

        $('.checkAll').click(function(){
            $('input:checkbox').not(this).prop('checked', this.checked);
        });

        $('.statusupdate').on('click', function(){
            var modal = $('#smsstatusupdate');
            var newArray = [];
            $("input:checkbox[name=whatsappid]:checked").each(function(){
                newArray.push($(this).val());
            });
            modal.find('input[name=smslogid]').val(newArray.join(','));
            modal.modal('show');
        });
	})(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/whatsapp_messaging/index.blade.php ENDPATH**/ ?>