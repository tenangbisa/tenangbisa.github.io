<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.authenticate')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="logo">
        <img src="<?php echo e(showImage(filePath()['site_logo']['path'].'/site_logo.png')); ?>" alt="logo">
        <h3><?php echo e(translate('Admin login')); ?></h3>
    </div>
    <div class="input-field email">
          <i class="fas fa-envelope"></i>
        <input type="text" id="login-email" name="username" placeholder="<?php echo e(translate('Enter Username')); ?>">
    </div>
    <div class="input-field password">
         <i class="fas fa-lock"></i>
        <input type="password"  name="password" id="login-email" placeholder="<?php echo e(translate('Enter Password')); ?>">
    </div>
    <div class="forgot-pass">
        <a href="<?php echo e(route('admin.password.request')); ?>"><?php echo e(translate('forgot password')); ?>?</a>
    </div>
    <button type="submit" class="btn-login"><?php echo e(translate('Sign In')); ?></button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>