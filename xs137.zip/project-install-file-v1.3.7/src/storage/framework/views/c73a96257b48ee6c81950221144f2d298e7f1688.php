<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="rounded_box">
        <div class="row ">
            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las la-comment facebook p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total SMS')); ?></h6>
                            <h4 class="fw-bold text-danger"><?php echo e($smslog['all']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las la-comment-alt facebook p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Success SMS')); ?></h6>
                            <h4 class="fw-bold text-success"><?php echo e($smslog['success']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las la-inbox facebook p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total SMS Contact')); ?></h6>
                            <h4 class="fw-bold text-danger"><?php echo e($phonebook['contact']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las la-envelope linkedin p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Email')); ?></h6>
                            <h4 class="fw-bold text-success"><?php echo e($emailLog['all']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las la-envelope-open linkedin p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Success Email')); ?></h6>
                            <h4 class="fw-bold text-success"><?php echo e($emailLog['success']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las la-envelope-open-text linkedin p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Email Contact')); ?></h6>
                            <h4 class="fw-bold text-success"><?php echo e($phonebook['email_contact']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las fab fa-whatsapp facebook p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Sent WhatsApp Message')); ?></h6>
                            <h4 class="fw-bold text-danger"><?php echo e($whatsappLog['all']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las fab fa-whatsapp facebook p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Success WhatsApp Message')); ?></h6>
                            <h4 class="fw-bold text-success"><?php echo e($whatsappLog['success']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 col-xl-4 my-1 px-1">
                <div class="shadow p-3">
                    <div class="row">
                        <div class="col-2">
                            <i class="fs-2 las fab fa-whatsapp facebook p-2 rounded"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="text-secondary"><?php echo e(translate('Total Pending WhatsApp Message')); ?></h6>
                            <h4 class="fw-bold text-danger"><?php echo e($whatsappLog['pending']); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<section class="mt-3">
    <div class="rounded_box">
        <div class="parent_pinned_project">
            <a href="<?php echo e(route('admin.user.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                    <i class="las la-user"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Total User')); ?></h6>
                        <p><?php echo e($phonebook['user']); ?><?php echo e(translate('User')); ?></p>
                    </div>
                </div>
            </a>
            <a href="<?php echo e(route('admin.plan.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                    <i class="lab la-telegram-plane"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Total Pricing Plan')); ?></h6>
                        <p><?php echo e($phonebook['plan']); ?> <?php echo e(translate('Plan')); ?></p>
                    </div>
                </div>
            </a>

            <a href="<?php echo e(route('admin.report.subscription.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                    <i class="las la-credit-card"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Total Subscription User')); ?></h6>
                        <p><?php echo e($phonebook['subscription']); ?></p>
                    </div>
                </div>
            </a>

            <a href="<?php echo e(route('admin.gateway.sms.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                    <i class="las la-angle-double-right"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Total SMS Api Gateway')); ?></h6>
                        <p><?php echo e($phonebook['sms_gateway']); ?></p>
                    </div>
                </div>
            </a>

            <a href="<?php echo e(route('admin.gateway.sms.android.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                   <i class="lab la-android"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Total Android Gateway')); ?></h6>
                        <p><?php echo e($phonebook['android_api']); ?> <?php echo e(translate('Android Gateway')); ?></p>
                    </div>
                </div>
            </a>
            <a href="<?php echo e(route('admin.report.credit.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                    <i class="las la-money-bill-wave-alt"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Total Credit Log')); ?></h6>
                        <p><?php echo e($phonebook['credit_log']); ?> <?php echo e(translate('Logs')); ?></p>
                    </div>
                </div>
            </a>
            <a href="<?php echo e(route('admin.report.payment.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                   <i class="las la-credit-card"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Payment History')); ?></h6>
                        <p><?php echo e(shortAmount($phonebook['payment_log'])); ?> <?php echo e(translate('Logs')); ?></p>
                    </div>
                </div>
            </a>
            <a href="<?php echo e(route('admin.report.transaction.index')); ?>" class="single_pinned_project shadow">
                <div class="pinned_icon">
                    <i class="las la-wallet"></i>
                </div>
                <div class="pinned_text">
                    <div>
                        <h6><?php echo e(translate('Transaction History')); ?></h6>
                        <p><?php echo e($phonebook['transaction']); ?> <?php echo e(translate('Log')); ?></p>
                    </div>
                </div>
            </a>
        </div>
    </div>
</section>


 <section class="mt-2">
    <div class="rounded_box">
        <div class="row">
            <div class="col-md-6">
                <div class="header-title">
                    <h6 class="text--dark"><?php echo e(translate('SMS Details Report')); ?></h6>
                    <div id="chart30"></div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="new-card-container">
                    <div class="new-card">
                        <div class="new-card-icon-container icon-container-bg d--flex align--center justify--between p-2">
                            <i class="fs-4 las la-credit-card"></i>
                            <i class="fs-4 las la-ellipsis-h"></i>
                        </div>
                        <h4 class="my-3"><?php echo e(__($general->currency_symbol)); ?><?php echo e(shortAmount($phonebook['payment_amount'])); ?></h4>
                        <span class="mb-3 text-secondary"><?php echo e(translate('Total Payment')); ?></span>
                    </div>

                    <div class="new-card">
                        <div class="new-card-icon-container icon-container-bg3 d--flex align--center justify--between p-2">
                            <i class="fs-4 las la-wallet"></i>
                            <i class="fs-4 las la-ellipsis-h"></i>
                        </div>
                        <h4 class="my-3"><?php echo e(__($general->currency_symbol)); ?><?php echo e(shortAmount($phonebook['payment_amount_charge'])); ?></h4>
                        <span class="mb-3 text-secondary"><?php echo e(translate('Payment Charge')); ?></span>
                    </div>

                    <div class="new-card">
                        <div class="new-card-icon-container icon-container-bg2 d--flex align--center justify--between p-2">
                            <i class="fs-4 las la-coins"></i>
                            <i class="fs-4 las la-ellipsis-h"></i>
                        </div>
                        <h4 class="my-3"><?php echo e(__($general->currency_symbol)); ?><?php echo e(shortAmount($phonebook['subscription_amount'])); ?></h4>
                        <span class="mb-3 text-secondary"><?php echo e(translate('Subscription Amount')); ?></span>
                    </div>

                    <div class="new-card">
                        <div class="new-card-icon-container icon-container-bg4 d--flex align--center justify--between p-2">
                            <i class="fs-4 las la-user"></i>
                            <i class="fs-4 las la-ellipsis-h"></i>
                        </div>
                        <h4 class="my-3"><?php echo e($phonebook['subscription']); ?></h4>
                        <span class="mb-3 text-secondary"><?php echo e(translate('Subscription User')); ?></span>
                    </div>

                    <div class="new-card">
                        <div class="new-card-icon-container icon-container-bg5 d--flex align--center justify--between p-2">
                            <i class="fs-4 las la-sms"></i>
                            <i class="fs-4 las la-ellipsis-h"></i>
                        </div>
                        <h4 class="my-3"><?php echo e($smslog['pending']); ?></h4>
                        <span class="mb-3 text-secondary"><?php echo e(translate('Pending SMS')); ?></span>
                    </div>

                    <div class="new-card">
                        <div class="new-card-icon-container icon-container-bg6 d--flex align--center justify--between p-2">
                            <i class="fs-4 las la-envelope"></i>
                            <i class="fs-4 las la-ellipsis-h"></i>
                        </div>
                        <h4 class="my-3"><?php echo e($emailLog['pending']); ?></h4>
                        <span class="mb-3 text-secondary"><?php echo e(translate('Pending Email')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="mt-3">
    <div class="rounded_box">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12 col-xl-6 p-1">
                <h6 class="header-title"><?php echo e(translate('New User')); ?></h6>
                <div class="responsive-table">
                    <table class="m-0 text-center table--light">
                        <thead>
                            <tr>
                                <th><?php echo e(translate('Customer')); ?></th>
                                <th><?php echo e(translate('Email - Phone')); ?></th>
                                <th><?php echo e(translate('Status')); ?></th>
                                <th><?php echo e(translate('Joined At')); ?></th>
                            </tr>
                        </thead>
                        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
                                <td data-label="<?php echo e(translate('Customer')); ?>">
                                    <a href="<?php echo e(route('admin.user.details', $customer->id)); ?>" class="brand" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(translate('Click For Details')); ?>">
                                        <?php echo e(__($customer->name)); ?><br>
                                    </a>
                                </td>
                                <td data-label="<?php echo e(translate('Email')); ?>">
                                    <?php echo e(__($customer->email)); ?><br>
                                    <?php echo e(__($customer->phone)); ?>

                                </td>

                                <td data-label="<?php echo e(translate('Status')); ?>">
                                    <?php if($customer->status == 1): ?>
                                        <span class="badge badge--success"><?php echo e(translate('Active')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge--danger"><?php echo e(translate('Banned')); ?></span>
                                    <?php endif; ?>
                                </td>

                                <td data-label="<?php echo e(translate('Joined At')); ?>">
                                    <?php echo e(diffForHumans($customer->created_at)); ?><br>
                                    <?php echo e(getDateTime($customer->created_at)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(translate('No Data Found')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>

            <div class="col-12 col-md-12 col-lg-12 col-xl-6 p-1">
                <h6 class="header-title"><?php echo e(translate('Latest Payment Log')); ?></h6>
                <div class="responsive-table">
                    <table class="m-0 text-center table--light">
                        <thead>
                            <tr>
                                <th><?php echo e(translate('Time')); ?></th>
                                <th><?php echo e(translate('User')); ?></th>
                                <th><?php echo e(translate('Amount')); ?></th>
                                <th><?php echo e(translate('Final Amount')); ?></th>
                                <th><?php echo e(translate('TrxID')); ?></th>
                            </tr>
                        </thead>
                        <?php $__empty_1 = true; $__currentLoopData = $paymentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
                                <td data-label="<?php echo e(translate('Time')); ?>">
                                    <span><?php echo e(diffForHumans($paymentLog->created_at)); ?></span><br>
                                    <?php echo e(getDateTime($paymentLog->created_at)); ?>

                                </td>

                                <td data-label="<?php echo e(translate('User')); ?>">
                                    <a href="<?php echo e(route('admin.user.details', $paymentLog->user_id)); ?>" class="fw-bold text-dark"><?php echo e(__(@$paymentLog->user->name)); ?></a>
                                </td>

                                <td data-label="<?php echo e(translate('Amount')); ?>">
                                    <?php echo e(shortAmount($paymentLog->amount)); ?> <?php echo e(__($general->currency_name)); ?>

                                    <br>
                                    <?php echo e(__($paymentLog->paymentGateway->name)); ?>

                                </td>

                                <td data-label="<?php echo e(translate('Final Amount')); ?>">
                                    <span class="text--success fw-bold"><?php echo e(shortAmount($paymentLog->final_amount)); ?> <?php echo e(__($paymentLog->paymentGateway->currency->name)); ?></span>
                                </td>

                                 <td data-label="<?php echo e(translate('TrxID')); ?>">
                                    <?php echo e($paymentLog->trx_number); ?> <br>
                                    <?php if($paymentLog->status == 1): ?>
                                        <span class="badge badge--primary"><?php echo e(translate('Pending')); ?></span>
                                    <?php elseif($paymentLog->status == 2): ?>
                                        <span class="badge badge--success"><?php echo e(translate('Received')); ?></span>
                                    <?php elseif($paymentLog->status == 3): ?>
                                        <span class="badge badge--danger"><?php echo e(translate('Rejected')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(translate('No Data Found')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scriptpush'); ?>
<script>
     var options = {
        series: [{
            name: 'Total SMS',
            type: 'column',
            data: [<?php echo e(implode(",",$smsReport['month_sms']->toArray())); ?>]
        }],
        chart: {
            height: 400,
            type: 'line',
            stacked: false,
        },
        stroke:{
            width: [0, 2, 5],
            colors: ['#ffb800', '#cecece'],
            curve: 'smooth'
        },
        plotOptions:{
            bar:{
                columnWidth: '50%'
            }
        },
        fill:{
            opacity: [0.85, 0.25, 1],
            colors: ['#8b0dfd', '#c9b6ff'],
            gradient:{
                inverseColors: false,
                shade: 'light',
                type: "vertical",
                opacityFrom: 0.85,
                opacityTo: 1,
                stops: [0, 100, 100, 100]
            }
        },
        labels: <?php echo json_encode($smsReport['month']->toArray(), 15, 512) ?>,
        markers: {
            size: 0
        },
        xaxis: {
            type: 'month'
        },
        yaxis: {
            title: {
                text: 'SMS',
            },
            min: 0
        },
        tooltip: {
            shared: true,
            intersect: false,
            y: {
                formatter: function (y) {
                    if(typeof y !== "undefined") {
                        return y.toFixed(0) + " sms";
                    }
                    return y;

                }
            }
        }
    };
    var chart = new ApexCharts(document.querySelector("#chart30"), options);
    chart.render();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>