
<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="mainContent" class="main_content added">
		<?php echo $__env->make('admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard_container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 col-sm-6">
                    <h6 class="my-3"><?php echo e(__($title)); ?></h6>
                </div> 
            </div>
        	<?php echo $__env->yieldContent('panel'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>