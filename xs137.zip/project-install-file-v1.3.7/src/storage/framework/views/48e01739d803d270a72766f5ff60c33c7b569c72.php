<?php $__env->startSection('content'); ?>
 <div class="col-12 col-md-12 col-lg-6 col-xl-6 px-0">
        <div class="login-left-section d-flex align-items-center justify-content-center">
            <div class="form-container">
                <div>
                    <div class="mb-3">
                        <h4><?php echo e(translate('Sign In With')); ?> <span class="site--title"><?php echo e(ucfirst($general->site_name)); ?></span></h4>
                    </div>
                    <div class="my-3">
                        <a class="shadow-sm d-flex text-decoration-none text-dark p-2 rounded align-items-center justify-content-center google--login"
                        href="<?php echo e(url('auth/google')); ?>">
                            <div class="d-flex align-items-center justify-content-center google--login--text">
                                <div class="google-img me-2">
                                    <img src="<?php echo e(showImage('assets/frontend/img/google.png')); ?>" alt="" class="w-100">
                                </div><?php echo e(translate('Continue with google')); ?>

                            </div>
                        </a>
                    </div>
                    <div class="or text-center"><p class="m-0"><?php echo e(translate('Or')); ?></p></div>
                </div>

                <form action="<?php echo e(route('login.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="my-3">
                        <label for="user" class="form-label d-block"><?php echo e(translate('Email address')); ?></label>
                        <div class="d-flex align-items-center border-bottom">
                            <i class="las la-envelope fs-3 text-primary"></i>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(translate('Give your login mail')); ?>" class="border-0 w-100 p-2" id="user"aria-describedby="emailHelp"/>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label d-block"><?php echo e(translate('Password')); ?></label>
                        <div class="d-flex align-items-center">
                            <i class="las la-lock fs-3 text-primary"></i>
                            <input type="password" name="password" placeholder="<?php echo e(translate('Give Valid password')); ?>" class="border-0 border-bottom w-100 p-2" id="password"/>
                        </div>
                    </div>
                    <div class="mb-3 form-check d-flex align-items-center justify-content-between">
                        <a href="<?php echo e(route('password.request')); ?>"><?php echo e(translate('Forget password')); ?>?</a>
                    </div>
                    <button type="submit" class="shadow btn btn--info w-100 mt-2 text-light"><?php echo e(translate('Submit')); ?></button>
                </form>
                <p class="text-center mt-3">
                    <?php echo e(translate('New To')); ?> <?php echo e(ucfirst($general->site_name)); ?>? <a href="<?php echo e(route('register')); ?>"><?php echo e(translate('Sign Up!')); ?></a>
                </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/user/auth/login.blade.php ENDPATH**/ ?>