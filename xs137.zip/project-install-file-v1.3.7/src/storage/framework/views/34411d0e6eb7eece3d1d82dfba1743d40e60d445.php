<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	 		<div class="col-lg-12">
	            <div class="card mb-4">
	                <div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
		                            <th><?php echo e(translate('Name')); ?></th>
                                        <th><?php echo e(translate('Value')); ?></th>
                                        <th><?php echo e(translate('Action')); ?></th>
                                    </tr>
		                    </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $offensiveData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($key); ?></td>
                                        <td width="30%">
                                        <form action="<?php echo e(route('admin.global.world.update')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="key" value="<?php echo e($key); ?>" class="form-control">
                                            <input type="text" name="value" value="<?php echo e($data); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <button type="submit" class="btn btn-primary btn-sm text--light">
                                                    <i class="las la-edit"></i>
                                            </button>
                                        </form>
                                            <button class="btn btn-danger btn-sm  text--light worddelete" data-bs-toggle="modal" data-bs-target="#worddelete" data-id="<?php echo e($key); ?>"><i class="las la-trash"></i></button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                            </tbody>
		                </table>
		            </div>
	            </div>


	        </div>
	    </div>
	</div>

        <a href="javascript:void(0);" class="support-ticket-float-btn" data-bs-toggle="modal" data-bs-target="#createWord" title="<?php echo e(translate('Add New Word')); ?>">
        <i class="fa fa-plus ticket-float"></i>
    </a>

    
    <div class="modal fade" id="createWord" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.global.world.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="card">
                            <div class="card-header bg--lite--violet">
                                    <div class="card-title text-center text--light"><?php echo e(translate('Add New Word')); ?></div>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                        <label for="key" class="form-label"><?php echo e(translate('Name')); ?> <sup class="text--danger">*</sup></label>
                                        <input type="text" class="form-control" id="key" name="key" placeholder="<?php echo e(translate('Enter Name')); ?>" required>
                                </div>
                                <div class="mb-3">
                                        <label for="value" class="form-label"><?php echo e(translate('Value')); ?> <sup class="text--danger">*</sup></label>
                                        <input type="text" class="form-control" id="value" name="value" placeholder="<?php echo e(translate('Enter value')); ?>" required>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal_button2">
                            <button type="button" class="" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
                            <button type="submit" class="bg--success"><?php echo e(translate('Submit')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <div class="modal fade" id="worddelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.global.world.delete')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id">
                    <div class="modal_body2">
                        <div class="modal_icon2">
                            <i class="las la-trash-alt"></i>
                        </div>
                        <div class="modal_text2 mt-3">
                                <h6><?php echo e(translate('Are you sure to want delete this?')); ?></h6>
                        </div>
                    </div>
                    <div class="modal_button2">
                            <button type="button" class="" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
                            <button type="submit" class="bg--danger"><?php echo e(translate('Delete')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</section>




<?php $__env->stopSection(); ?>


<?php $__env->startPush('scriptpush'); ?>
<script>
	(function($){
		"use strict";

		$('.worddelete').on('click', function(){
			var modal = $('#worddelete');
			modal.find('input[name=id]').val($(this).data('id'));
			modal.modal('show');
		});

	})(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/global_world/index.blade.php ENDPATH**/ ?>