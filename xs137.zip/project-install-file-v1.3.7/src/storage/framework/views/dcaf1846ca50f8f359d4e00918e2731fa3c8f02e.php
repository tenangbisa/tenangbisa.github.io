<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e(__($general->site_name)); ?> - <?php echo e(__(@$title)); ?></title>
    <link rel="shortcut icon" href="<?php echo e(showImage(filePath()['site_logo']['path'].'/site_favicon.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/line-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/toastr.css')); ?>">
</head>
<body>
    <div class="login-page-container">
        <div class="container-fluid p-0">
            <div class="row responsive-shadow overflow-hidden">
            <?php echo $__env->yieldContent('content'); ?>
            <div class="col-12 col-md-12 col-lg-6 col-xl-6 px-0">
                <div class="login-right-section responsive-padding bg-purple d-flex align-items-center justify-content-center">
                    <div> <h1><?php echo app('translator')->get('Welcome to'); ?> <?php echo e(__($general->site_name)); ?></h1>
                        <p><?php echo e(@$general->frontend_section->sub_heading); ?></p>
                        <?php if(count($users)>5): ?>
                        <div class="users">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="user">
                                        <img src="<?php echo e(showImage('assets/images/user/profile/'.$user->image)); ?>" alt="<?php echo e($user->name); ?>" class="w-100 h-100"/>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <i class="fas fa-arrow-right fs-1 ms-3 text-light"></i>
                        </div>
                        <span class="text-light"><?php echo e(@$general->frontend_section->heading); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('assets/global/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/global/js/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/global/js/toastr.js')); ?>"></script>
<script src="<?php echo e(asset('assets/global/js/bootstrap.bundle.min.js')); ?>"></script>
<?php echo $__env->make('partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\xsender\src\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>