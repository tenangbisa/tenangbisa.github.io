<?php $__env->startSection('panel'); ?>
<section class="mt-3 rounded_box">
	<div class="container-fluid p-0 mb-3 pb-2">
		<div class="row">
			<div class="col-xl-4">
                <form action="<?php echo e(route('admin.gateway.whatsapp.create')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card mb-2">
                        <div class="card-header">
                            <?php echo e(translate('Whatsapp Device Add')); ?>

                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label for="name"><?php echo e(translate('Name')); ?> <span  class="text-danger">*</span>  </label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(translate('Put Session Name (Any)')); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label for="number"><?php echo e(translate('Number')); ?> <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="number" id="number" value="<?php echo e(old('number')); ?>" placeholder="<?php echo e(translate('Put Your WhatsApp number here')); ?>">
                                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label for="description"><?php echo e(translate('Description')); ?></label>
                                    <textarea name="description" id="description" class="form-control" placeholder="<?php echo e(translate('Remark Your WhatsApp device(any)')); ?>"><?php echo e(old('description')); ?></textarea>
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label for="multidevice"><?php echo e(translate('Multi Device')); ?>

                                        <span class="text-danger" >*</span>
                                    </label>
                                    <select name="multidevice" id="multidevice" class="form-control <?php $__errorArgs = ['multidevice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                        <option value=""><?php echo e(translate('Select One')); ?></option>
                                        <option <?php echo e(old('multidevice') == 'yes' ? 'selected' : ' '); ?> value="yes"><?php echo e(translate('YES')); ?></option>
                                        <option <?php echo e(old('multidevice') == 'no' ? 'selected' : ' '); ?> value="no"><?php echo e(translate('No')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['multidevice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label for="delay_time"><?php echo e(translate('Message Delay Time')); ?>

                                        <span class="text-danger" >*</span>
                                    </label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['delay_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="delay_time" id="delay_time" value="<?php echo e(old('delay_time')); ?>" placeholder="<?php echo e(translate('Message delay time in second')); ?>">
                                    <?php $__errorArgs = ['delay_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary me-sm-3 me-1 float-end"><?php echo e(translate('Submit')); ?></button>
                        </div>
                    </div>
                </form>
			</div>
            <div class="col-xl-8">
                <div class="card mb-2">
                    <div class="card-header">
                        <?php echo e(translate('WhatsApp Device List')); ?>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <th><?php echo e(translate('Name')); ?></th>
                                    <th><?php echo e(translate('Number')); ?></th>
                                    <th><?php echo e(translate('Description')); ?></th>
                                    <th><?php echo e(translate('Status')); ?></th>
                                    <th><?php echo e(translate('Multi Device')); ?></th>
                                    <th><?php echo e(translate('Action')); ?></th>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $whatsapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->number); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($item->status == 'initiate' ? 'primary' : ($item->status == 'connected' ? 'success' : 'danger')); ?>">
                                            <?php echo e(ucwords($item->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($item->multidevice == 'YES' ? 'primary' : 'danger'); ?>">
                                            <?php echo e($item->multidevice); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($item->status == 'initiate'): ?>
                                            <a title="Scan" href="javascript:void(0)" id="textChange" class="badge bg-success p-2 qrQuote textChange<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>"><i class="fas fa-qrcode"></i>&nbsp <?php echo e(translate('Scan')); ?></a>
                                        <?php elseif($item->status == 'connected'): ?>
                                        <a title="Disconnect" href="javascript:void(0)" onclick="return deviceStatusUpdate('<?php echo e($item->id); ?>','disconnected','deviceDisconnection','Disconnecting','Connect')" class="badge bg-danger p-2 deviceDisconnection<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>"><i class="fas fa-plug"></i>&nbsp <?php echo e(translate('Disconnect')); ?></a>
                                        <?php else: ?>
                                        <a title="Scan" href="javascript:void(0)" id="textChange" class="badge bg-success p-2 qrQuote textChange<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>"><i class="fas fa-qrcode"></i>&nbsp <?php echo e(translate('Scan')); ?></a>
                                        <?php endif; ?>

                                        <a title="Edit" href="<?php echo e(route('admin.gateway.whatsapp.edit', $item->id)); ?>" class="badge bg-primary p-2"><i class="fas fa-pen"></i></a>

                                        <a title="Delete" href="" class="badge bg-danger p-2 whatsappDelete" value="<?php echo e($item->id); ?>"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="50"><span class="text-danger"><?php echo e(translate('No data Available')); ?></span></td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="m-3">
                            <?php echo e($whatsapps->appends(request()->all())->links()); ?>

                        </div>
                    </div>
                </div>
		    </div>
	   </div>
    </div>
</section>


<div class="modal fade" id="whatsappDelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        	<form action="<?php echo e(route('admin.gateway.whatsapp.delete')); ?>" method="POST">
        		<?php echo csrf_field(); ?>
        		<input type="hidden" name="id" value="">
	            <div class="modal_body2">
	                <div class="modal_icon2">
	                    <i class="las la-trash-alt"></i>
	                </div>
	                <div class="modal_text2 mt-3">
	                    <h6><?php echo e(translate('Are you sure to delete')); ?></h6>
	                </div>
	            </div>
	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--danger"><?php echo e(translate('Delete')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>


  <div class="modal fade" id="qrQuoteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(translate('Scan Device')); ?></h5>
          <button type="button" class="btn-close" aria-label="Close" onclick="return deviceStatusUpdate('','initiate','','','')"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="scan_id" id="scan_id" value="">
            <div>
                <h4 class="py-3"><?php echo e(translate('To use WhatsApp')); ?></h4>
                <ul>
                    <li><?php echo e(translate('1.Open WhatsApp on your phone')); ?></li>
                    <li><?php echo e(translate('2.Tap Menu  or Settings  and select Linked Devices')); ?></li>
                    <li><?php echo e(translate('3.Point your phone to this screen to capture the code')); ?></li>
                </ul>
            </div>
          <div class="text-center">
                <img id="qrcode" class="w-50" src="" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scriptpush'); ?>
<script>
	(function($){
		"use strict";
        $(document).on('click', '.whatsappDelete', function(e){
            e.preventDefault()
            var id = $(this).attr('value')
            var modal = $('#whatsappDelete');
			modal.find('input[name=id]').val(id);
			modal.modal('show');
        })

        // recursive function
        function middlePass(id , url, sessionId){
            whatsappSeesion(id, url, sessionId)
        }

        // qrQuote scan
        $(document).on('click', '.qrQuote', function(e){
            e.preventDefault()
            var id = $(this).attr('value')
            var url = "<?php echo e(route('admin.gateway.whatsapp.qrcode')); ?>"

            whatsappSeesion(id, url)

        })

        function whatsappSeesion(id, url)
        {
            $.ajax({
                headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
                url:url,
                data: {id:id},
                dataType: 'json',
                method: 'post',
                beforeSend: function(){
                    $('.textChange'+id).html(`<?php echo e(translate('Loading...')); ?>`);
                },
                success: function(res){
                    console.log(res)
                    $("#scan_id").val(res.response.id);

                    if (res.qr!='') {
                        $('#qrcode').attr('src',res.qr);
                    }

                    if(res.data != 'error' || res.data!='' || res.data!='connected'){
                        $('#qrQuoteModal').modal('show');
                        sleep(10000).then(() => {
                            wapSession(id, url);
                        });
                    }
                },
                complete: function(){
                    $('.textChange'+id).html(`<i class="fas fa-qrcode"></i>&nbsp <?php echo e(translate('Scan')); ?>`);
                }
            })
        }
	})(jQuery);

    function wapSession(id,url) {
        $.ajax({
            headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
            url:url,
            data: {id:id},
            dataType: 'json',
            method: 'post',
            success: function(res){
                $("#scan_id").val(res.response.id);
                if (res.qr!='')
                {
                    $('#qrcode').attr('src',res.qr);
                }
                if(res.data != 'error' || res.data!='' || res.data!='connected')
                {
                    sleep(10000).then(() => {
                        wapSession(id, url);
                    });
                }
                if (res.data=='connected')
                {
                    sleep(2500).then(() => {
                        $('#qrQuoteModal').modal('hide');
                        location.reload();
                    });
                }
            }
        })
    }


    function deviceStatusUpdate(id,status,className='',beforeSend='',afterSend='') {
        if (id=='') {
            id = $("#scan_id").val();
        }
        $('#qrQuoteModal').modal('hide');
           $.ajax({
            headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
            url:"<?php echo e(route('admin.gateway.whatsapp.status-update')); ?>",
            data: {id:id,status:status},
            dataType: 'json',
            method: 'post',
            beforeSend: function(){
                if (beforeSend!='') {
                    $('.'+className+id).html(beforeSend);
                }
            },
            success: function(res){
                sleep(1000).then(()=>{
                    location.reload();
                })
            },
            complete: function(){
                if (afterSend!='') {
                    $('.'+className+id).html(afterSend);
                }
            }
        })
    }

</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/whatsapp/create.blade.php ENDPATH**/ ?>