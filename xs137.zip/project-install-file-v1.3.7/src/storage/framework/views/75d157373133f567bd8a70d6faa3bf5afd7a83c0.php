<?php $__env->startSection('panel'); ?>
<section class="mt-3 rounded_box">
	<div class="container-fluid p-0 mb-3 pb-2">
		<div class="row d-flex align--center rounded">
			<div class="col-xl-12">
				<div class="table_heading d-flex align--center justify--between">
                    <nav  aria-label="breadcrumb">
					  	<ol class="breadcrumb">
					    	<li class="breadcrumb-item"><a href="<?php echo e(route('admin.mail.configuration')); ?>"> <?php echo e(translate('Mail Configuration')); ?></a></li>
					    	<li class="breadcrumb-item" aria-current="page"><?php echo e(__($mail->name)); ?></li>
					  	</ol>
					</nav>
                </div>

				<div class="card">
					<div class="card-header bg--lite--violet text-center">
						<h6 class="text-light"><?php echo e(__($mail->name)); ?>  <?php echo e(translate('Mail Configuration Update Form')); ?></h6>
					</div>
					<div class="card-body">
						<form action="<?php echo e(route('admin.mail.update', $mail->id)); ?>" method="POST">
							<?php echo csrf_field(); ?>

							<?php if($mail->name === "SMTP"): ?>
								<div class="row">
									<div class="mb-3 col-lg-6">
										<label for="driver" class="form-label"> <?php echo e(translate('Driver')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="driver" id="driver" class="form-control" value="<?php echo e(@$mail->driver_information->driver); ?>" placeholder="<?php echo e(translate('Enter Driver')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="host" class="form-label"> <?php echo e(translate('Host')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="host" id="host" class="form-control" value="<?php echo e(@$mail->driver_information->host); ?>" placeholder=" <?php echo e(translate('Enter Host')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="smtp_port" class="form-label"> <?php echo e(translate('SMTP Port')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="smtp_port" id="smtp_port" class="form-control" value="<?php echo e(@$mail->driver_information->smtp_port); ?>" placeholder=" <?php echo e(translate('Enter SMTP Port')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="encryption" class="form-label"> <?php echo e(translate('Encryption')); ?> <sup class="text--danger">*</sup></label>
										<select class="form-control" name="encryption" id="encryption">
										    <option value="">Select Encryption Types</options>
										    <option value="TLS" <?php if('TLS' == $mail->driver_information->encryption): ?> selected <?php endif; ?>>Standard encryption (TLS)</option>
										    <option value="SSL" <?php if('SSL' == $mail->driver_information->encryption): ?> selected <?php endif; ?>>Secure encryption (SSL)</option>
										    <option value="PWMTA" <?php if('PWMTA' == $mail->driver_information->encryption): ?> selected <?php endif; ?>>PowerMTA Server        </option>
										    <option value="STARTTLS" <?php if('STARTTLS' == $mail->driver_information->encryption): ?> selected <?php endif; ?>>STARTTLS       </option>
										    <option value="none" <?php if('none' == $mail->driver_information->encryption): ?> selected <?php endif; ?>>None or No SSL     </option>

										</select>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="username" class="form-label"> <?php echo e(translate('Username')); ?><sup class="text--danger">*</sup></label>
										<input type="text" name="username" id="username" class="form-control" value="<?php echo e(@$mail->driver_information->username); ?>" placeholder=" <?php echo e(translate('Enter Mail Username')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="password" class="form-label"> <?php echo e(translate('Password')); ?><sup class="text--danger">*</sup></label>
										<input type="password" name="password" id="password" class="form-control" value="<?php echo e(@$mail->driver_information->password); ?>" placeholder=" <?php echo e(translate('Enter Mail Password')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="from_address" class="form-label"> <?php echo e(translate('From Address')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="from_address" id="from_address" class="form-control" value="<?php echo e(@$mail->driver_information->from->address); ?>" placeholder=" <?php echo e(translate('Enter From Address')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="from_name" class="form-label"> <?php echo e(translate('From Name')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="from_name" id="from_name" class="form-control" value="<?php echo e(@$mail->driver_information->from->name); ?>" placeholder=" <?php echo e(translate('Enter From Name')); ?>" required>
									</div>
								</div>
							<?php elseif($mail->name === "SendGrid Api"): ?>
								<div class="row">
									<div class="mb-3 col-lg-12">
										<label for="app_key" class="form-label"> <?php echo e(translate('App Key')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="app_key" id="app_key" class="form-control" value="<?php echo e(@$mail->driver_information->app_key); ?>" placeholder=" <?php echo e(translate('Enter App key')); ?>" required>
									</div>
									<div class="mb-3 col-lg-6">
										<label for="from_address" class="form-label"> <?php echo e(translate('From Address')); ?> <sup class="text--danger">*</sup></label>
										<input type="text" name="from_address" id="from_address" class="form-control" value="<?php echo e(@$mail->driver_information->from->address); ?>" placeholder=" <?php echo e(translate('Enter From Address')); ?>" required>
									</div>

									<div class="mb-3 col-lg-6">
										<label for="from_name" class="form-label"> <?php echo e(translate('From Name')); ?><sup class="text--danger">*</sup></label>
										<input type="text" name="from_name" id="from_name" class="form-control" value="<?php echo e(@$mail->driver_information->from->name); ?>" placeholder=" <?php echo e(translate('Enter From Name')); ?>" required>
									</div>
								</div>
							<?php endif; ?>
							<button type="submit" class="btn btn--primary w-100 text-light"> <?php echo e(translate('Submit')); ?></button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="mt-3 rounded_box">
	<div class="container-fluid p-0 mb-3 pb-2">
		<div class="row d-flex align--center rounded">
			<div class="col-xl-12">
				<div class="card">
					<div class="card-header bg--lite--violet text-center">
						<h6 class="text-light"><?php echo e(__($mail->name)); ?>  <?php echo e(translate('Mail Configuration Test Form')); ?></h6>
					</div>
					<div class="card-body">
						<form action="<?php echo e(route('admin.mail.test', $mail->id)); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<div class="row"> 
								<label><?php echo e(translate('Test To')); ?></label>
								<div class="col-lg-8">
									<input type="email" value="<?php echo e(@old('email')); ?>" name="email" class="form-control" placeholder="<?php echo e(translate('Put Your Email where you will received a test mail from your mail configuration settings')); ?>">
								</div>
								<div class="col-lg-4">
									<button class="form-control btn btn--primary" type="submit"><?php echo e(translate('Submit')); ?></button>
								</div> 
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/mail/edit.blade.php ENDPATH**/ ?>