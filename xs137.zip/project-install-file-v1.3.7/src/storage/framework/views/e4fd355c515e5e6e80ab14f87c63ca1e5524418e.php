<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	 		<div class="col-lg-12 p-1">
	            <div class="rounded_box">
	                <div class="row align--center px-3">
                		<div class="col-12 col-md-4 col-lg-4 col-xl-5">
                    		<h6 class="my-3"><?php echo e(translate('Manage Language')); ?></h6>
                    	</div>

	                    <div class="col-12 col-md-8 col-lg-8 col-xl-7">
	                		<div class="row justify-content-end">
			                    <div class="col-12 col-lg-6 col-xl-6 px-2 py-1 ">
				                    <form action="<?php echo e(route('admin.language.default')); ?>" method="POST" class="form-inline float-sm-right text-end">
				                    	<?php echo csrf_field(); ?>
				                     	<div class="input-group mb-3 w-100">
										  	<select class="form-control" name="id" required="">
										  		<?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										  			<option value="<?php echo e($language->id); ?>" <?php if($language->is_default == 1): ?> selected <?php endif; ?>><?php echo e(strtoupper($language->name)); ?></option>
										  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										  	</select>
										  	<button class="btn--primary input-group-text input-group-text" id="basic-addon2" type="submit"><?php echo app('translator')->get('Set Default Language'); ?></button>
										</div>
							        </form>
							    </div>
							</div>
	                	</div>
	                </div>
 					<div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
		                            <th> <?php echo e(translate('Name')); ?></th>
		                            <th> <?php echo e(translate('Code')); ?></th>
		                            <th> <?php echo e(translate('Status')); ?></th>
		                            <th> <?php echo e(translate('Action')); ?></th>
		                        </tr>
		                    </thead>
		                    <?php $__empty_1 = true; $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			                    <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
				                    <td data-label=" <?php echo e(translate('Name')); ?>">
				                    	<i class="flag-icon flag-icon-<?php echo e($language->flag); ?> flag-icon-squared rounded-circle fs-4 me-1"></i><?php echo e(__($language->name)); ?>

				                    </td>
				                    <td data-label=" <?php echo e(translate('Code')); ?>">
				                    	<?php echo e(__($language->code)); ?>

				                    </td>

				                    <td data-label=" <?php echo e(translate('Status')); ?>">
				                    	<?php if($language->is_default == 1): ?>
				                    		<span class="badge badge--success"> <?php echo e(translate('Default')); ?></span>
				                    	<?php else: ?>
				                    		<span> <?php echo e(translate('N/A')); ?></span>
				                    	<?php endif; ?>
				                    </td>
				                    <td data-label= <?php echo e(translate('Action')); ?>>
			                    		<a class="btn--primary text--light language" data-bs-toggle="modal" data-bs-target="#updatebrand" href="javascript:void(0)" data-id="<?php echo e($language->id); ?>" data-name="<?php echo e($language->name); ?>" data-code="<?php echo e($language->code); ?>"><i class="las la-pen"></i></a>
			                    		<a class="btn--success text--light" href="<?php echo e(route('admin.language.translate', $language->code)); ?>"><i class="las la-language"></i></a>
			                    		<?php if($language->is_default != 1 && $language->id != 1): ?>
				                    		<a href="javascript:void(0)" class="btn--danger text--light languagedelete"
				                    		data-bs-toggle="modal"
				                    		data-bs-target="#delete"
				                    		data-delete_id="<?php echo e($language->id); ?>"
				                    		><i class="las la-trash"></i></a>
			                    		<?php endif; ?>
				                    </td>
			                    </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			                	<tr>
			                		<td class="text-muted text-center" colspan="100%"> <?php echo e(translate('No Data Found')); ?></td>
			                	</tr>
			                <?php endif; ?>
		                </table>
		            </div>
	            </div>
	        </div>
	    </div>
	</div>
	<a href="javascript:void(0);" class="support-ticket-float-btn" data-bs-toggle="modal" data-bs-target="#createlanguage" title=" <?php echo e(translate('Create New Language')); ?>">
		<i class="fa fa-plus ticket-float"></i>
	</a>
</section>


<div class="modal fade" id="createlanguage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
			<form action="<?php echo e(route('admin.language.store')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
	            <div class="modal-body">
	            	<div class="card">
	            		<div class="card-header bg--lite--violet">
	            			<div class="card-title text-center text--light"> <?php echo e(translate('Add New Language')); ?></div>
	            		</div>
		                <div class="card-body">
		                	<div class="mb-3">
								<label for="name" class="form-label"> <?php echo e(translate('Country Flag')); ?> <sup class="text--danger">*</sup></label>
								<span id="flag-icon"></span>
								<select name="flag" class="form-select flag" id="flag">
										<option value=""> <?php echo e(translate('Select Country Flag')); ?></option>
								    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$countryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($key); ?>" <?php if(session('flag') == $key): ?> selected="" <?php endif; ?>><?php echo e(__($countryData->country)); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>

							<div class="mb-3">
								<label for="name" class="form-label"> <?php echo e(translate('Language Name')); ?> <sup class="text--danger">*</sup></label>
								<input type="text" class="form-control" id="name" name="name" placeholder=" <?php echo e(translate('Language Name Here')); ?>" required>
							</div>

							<div class="mb-3">
								<label for="code" class="form-label"> <?php echo e(translate('Code')); ?> <sup class="text--danger">*</sup></label>
								<input type="text" class="form-control" id="code" name="code" placeholder=" <?php echo e(translate('Enter Language Code [i.g: en, bn, in]')); ?>" required>
							</div>
						</div>
	            	</div>
	            </div>

	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"> <?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--success"> <?php echo e(translate('Submit')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>


<div class="modal fade" id="updatelanguage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
			<form action="<?php echo e(route('admin.language.update')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="id">
	            <div class="modal-body">
	            	<div class="card">
	            		<div class="card-header bg--lite--violet">
	            			<div class="card-title text-center text--light"> <?php echo e(translate('Update Language')); ?></div>
	            		</div>
		                <div class="card-body">
		                	<div class="mb-3">
								<label for="name" class="form-label"> <?php echo e(translate('Name')); ?> <sup class="text--danger">*</sup></label>
								<input type="text" class="form-control" id="name" name="name" placeholder=" <?php echo e(translate('Enter Name')); ?>" required>
							</div>
						</div>
	            	</div>
	            </div>

	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"> <?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--success"> <?php echo e(translate('Submit')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>

<div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        	<form action="<?php echo e(route('admin.language.delete')); ?>" method="POST">
        		<?php echo csrf_field(); ?>
        		<input type="hidden" name="id" value="">
	            <div class="modal_body2">
	                <div class="modal_icon2">
	                    <i class="las la-trash-alt"></i>
	                </div>
	                <div class="modal_text2 mt-3">
	                    <h6> <?php echo e(translate('Are you sure to delete this language')); ?></h6>
	                </div>
	            </div>
	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"> <?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--danger"> <?php echo e(translate('Delete')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scriptpush'); ?>
<script>
	(function($){
       	"use strict";
		$('.language').on('click', function(){
			var modal = $('#updatelanguage');
			modal.find('input[name=id]').val($(this).data('id'));
			modal.find('input[name=name]').val($(this).data('name'));
			modal.modal('show');
		});

		$('.languagedelete').on('click', function(){
			var modal = $('#delete');
			modal.find('input[name=id]').val($(this).data('delete_id'));
			modal.modal('show');
		});

		$('#flag').on('change', function() {
			var countryCode = this.value.toLowerCase();
			$('#flag-icon').html('').html('<i class="flag-icon flag-icon-squared rounded-circle fs-4 me-1 flag-icon-'+countryCode+'"></i>');
		});
	})(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/language/index.blade.php ENDPATH**/ ?>