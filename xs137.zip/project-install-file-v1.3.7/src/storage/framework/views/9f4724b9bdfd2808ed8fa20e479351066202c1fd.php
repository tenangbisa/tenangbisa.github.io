<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__(@$general->site_name)); ?> - <?php echo e(__(@$title)); ?></title>
    <link rel="shortcut icon" href="<?php echo e(showImage(filePath()['site_logo']['path'].'/site_favicon.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/dashboard/auth/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/toastr.css')); ?>">
</head>
<body>
    <section class="admin-form">
        <div class="form-container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </section>
    <div class="squire-container">
        <ul class="squares"></ul>
    </div>
    <script src="<?php echo e(asset('assets/global/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/auth/js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/auth/js/fontAwesome.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/global/js/toastr.js')); ?>"></script>
    <?php echo $__env->make('partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/layouts/auth.blade.php ENDPATH**/ ?>