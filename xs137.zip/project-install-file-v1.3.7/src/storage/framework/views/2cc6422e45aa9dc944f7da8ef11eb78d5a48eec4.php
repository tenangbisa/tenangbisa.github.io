
<?php $__env->startSection('panel'); ?>
<section class="mt-3 rounded_box">
	<div class="container-fluid p-0 mb-3 pb-2">
		<div class="row d-flex align--center rounded">
			<div class="col-xl-12">
				<div class="table_heading d-flex align--center justify--between">
                    <nav  aria-label="breadcrumb">
					  	<ol class="breadcrumb">
					    	<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(translate('Dashboard')); ?></a></li>
					    	<li class="breadcrumb-item" aria-current="page"> <?php echo e(translate('General Setting')); ?></li>
					    	<li class="breadcrumb-item" aria-current="page"><?php echo e(translate('Last time cron job run')); ?><i class="las la-arrow-right"></i><span class="text--success"> <?php echo e(getDateTime($general->cron_job_run)); ?></span></li>
					  	</ol>
					</nav>
					<a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#cronjob" class="btn--dark text--light border-0 px-3 py-1 rounded ms-3"><i class="las la-key"></i> <?php echo e(translate('Setup Cron Jobs')); ?></a>
                </div>
				<div class="card">
					<div class="card-body">
						<form action="<?php echo e(route('admin.general.setting.store')); ?>" method="POST" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="mb-3 col-lg-12 col-md-12">
									<label for="site_name" class="form-label"><?php echo e(translate('Site Name')); ?> <sup class="text--danger">*</sup></label>
									<input type="text" name="site_name" id="site_name" class="form-control" value="<?php echo e($general->site_name); ?>" placeholder="<?php echo e(translate('Enter Site Name')); ?>" required>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="plan_id" class="form-label"><?php echo e(translate('Sign Up Bonus')); ?> <sup class="text--danger">*</sup></label>
									<select class="form-control" id="plan_id" name="plan_id" required="">
										<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($plan->id); ?>" <?php if($plan->id == $general->plan_id): ?> selected <?php endif; ?>><?php echo e(__($plan->name)); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="sign_up_bonus" class="form-label"><?php echo e(translate('Sign Up Bonus Status')); ?> <sup class="text--danger">*</sup></label>
									<select class="form-control" id="sign_up_bonus" name="sign_up_bonus" required="">
										<option value="1" <?php if($general->sign_up_bonus == 1): ?> selected <?php endif; ?>><?php echo e(translate('ON')); ?></option>
										<option value="2" <?php if($general->sign_up_bonus == 2): ?> selected <?php endif; ?>><?php echo e(translate('OFF')); ?></option>
									</select>
								</div>


								<div class="mb-3 col-lg-6 col-md-12">
									<label for="sms_gateway" class="form-label"><?php echo e(translate('SMS Gateway')); ?> <sup class="text--danger">*</sup></label>
									<select class="form-control" id="sms_gateway" name="sms_gateway" required="">
										<option value="1" <?php if($general->sms_gateway == 1): ?> selected <?php endif; ?>><?php echo e(translate('Api Gateway')); ?></option>
										<option value="2" <?php if($general->sms_gateway == 2): ?> selected <?php endif; ?>><?php echo e(translate('Android Gateway')); ?></option>
									</select>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="registration_status" class="form-label"><?php echo e(translate('User Registration')); ?> <sup class="text--danger">*</sup></label>
									<select class="form-control" id="registration_status" name="registration_status" required="">
										<option value="1" <?php if($general->registration_status == 1): ?> selected <?php endif; ?>><?php echo e(translate('ON')); ?></option>
										<option value="2" <?php if($general->registration_status == 2): ?> selected <?php endif; ?>><?php echo e(translate('OFF')); ?></option>
									</select>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="currency_name" class="form-label"><?php echo e(translate('Currency')); ?> <sup class="text--danger">*</sup></label>
									<input type="text" name="currency_name" id="currency_name" class="form-control" value="<?php echo e($general->currency_name); ?>" placeholder="<?php echo e(translate('Enter Currency Name')); ?>" required>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="currency_symbol" class="form-label"><?php echo e(translate('Currency Symbol')); ?> <sup class="text--danger">*</sup></label>
									<input type="text" name="currency_symbol" id="currency_symbol" class="form-control" value="<?php echo e($general->currency_symbol); ?>" placeholder="<?php echo e(translate('Enter Currency Symbol')); ?>" required>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="currency_symbol" class="form-label"><?php echo e(translate('Country Code For Contact')); ?> <sup class="text--danger">*</sup></label>
									<div class="input-group mb-3">
								  	<label class="input-group-text" for="country_code" id="country--dial--code"><?php echo e($general->country_code); ?></label>
								  	<select name="country_code" class="form-select" id="country_code">
									    <<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($countryData->dial_code); ?>" <?php if($general->country_code == $countryData->dial_code): ?> selected="" <?php endif; ?>><?php echo e($countryData->country); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									  </select>
									</div>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="timelocation" class="form-label"><?php echo e(translate('Time Zone')); ?> <sup class="text--danger">*</sup></label>
									<select class="form-control" id="timelocation" name="timelocation" required="">
										<?php $__currentLoopData = $timeLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeLocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="'<?php echo e(@$timeLocation); ?>'" <?php if(config('app.timezone') == $timeLocation): ?> selected <?php endif; ?>><?php echo e(__($timeLocation)); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="site_logo" class="form-label"><?php echo e(translate('Site Logo')); ?></label>
									<input type="file" name="site_logo" id="site_logo" class="form-control">
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
									<label for="site_favicon" class="form-label"><?php echo e(translate('Site Favicon')); ?></label>
									<input type="file" name="site_favicon" id="site_favicon" class="form-control">
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
								  	<div class="form-check form-switch">
										<input class="form-check-input" name="debug_mode" type="checkbox" role="switch" id="debug_mode" value="true" <?php echo e($general->debug_mode=="true" ? "checked" : ""); ?>>
										<label class="form-check-label" for="debug_mode"><?php echo e(translate('Debug Mode For Developing Purpose')); ?></label>
									</div>
								</div>

								<div class="mb-3 col-lg-6 col-md-12">
								  	<div class="form-check form-switch">
										<input class="form-check-input" name="maintenance_mode" type="checkbox" role="switch" id="maintenance_mode" value="true" <?php echo e($general->maintenance_mode=="true" ? "checked" : ""); ?>>
										<label class="form-check-label" for="maintenance_mode"><?php echo e(translate('Maintenance Mode For Site Maintenance')); ?></label>
									</div>
								</div>
								<?php if($general->maintenance_mode=="true"): ?>
								<div class="mb-3 col-lg-12 col-md-12" id="maintenance_mode_div">
									<label for="maintenance_mode_message" class="form-label"><?php echo e(translate('Maintenance Mode Message')); ?>

										<sup class="text--danger">*</sup></label>
									<input type="text" name="maintenance_mode_message" id="maintenance_mode_message" class="form-control" value="<?php echo e($general->maintenance_mode_message); ?>" placeholder="<?php echo e(translate('Write some message for maintenance mode page')); ?>">
								</div>
								<?php endif; ?>


                                <div class="mb-3 col-lg-6 col-md-12">
                                    <label for="whatsapp_credit_count" class="form-label"><?php echo e(translate('Per Credit For WhatsApp')); ?> <sup class="text--danger">*</sup></label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><?php echo e(translate('1 Credit')); ?> </span>
                                        <input type="text" id="rate" name="whatsapp_word_count" value="<?php echo e($general->whatsapp_word_count); ?>" class="form-control" placeholder="<?php echo e(translate('Enter number of words')); ?>" aria-label="Username" aria-describedby="basic-addon1">
                                    </div>
                                </div>


                                <div class="mb-3 col-lg-6 col-md-12">
                                    <label for="whatsapp_credit" class="form-label"><?php echo e(translate('Per Credit For SMS')); ?> <sup class="text--danger">*</sup></label>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" value="<?php echo e($general->sms_word_text_count); ?>" name="sms_word_text_count" placeholder="Number for Text" aria-label="Username">
                                        <span class="input-group-text"><?php echo e(translate('1 Credit')); ?></span>
                                        <input type="text" class="form-control" value="<?php echo e($general->sms_word_unicode_count); ?>" name="sms_word_unicode_count" placeholder="Number for Unicode" aria-label="Server">
                                    </div>
                                </div>
							</div>

							<button type="submit" class="btn btn--primary w-100 text-light"><?php echo e(translate('Submit')); ?></button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="modal fade" id="cronjob" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-md">
        <div class="modal-content">
            <div class="modal-body">
            	<div class="card">
        			<div class="card-header bg--lite--violet">
            			<div class="card-title text-center text--light">
            				<h6><?php echo e(translate('Cron Job Setting')); ?></h6>
            				<p><?php echo e(translate('Set the cron once every minute this is the ideal time')); ?></p>
            			</div>
            		</div>
	                <div class="card-body">
	            		<div class="mb-3">
	            			<label for="timelocation" class="form-label"><?php echo e(translate('Cron Job Run')); ?> <sup class="text--danger">* <?php echo e(translate('Set time for 2 minutes')); ?></sup></label>
	            			<div class="input-group mb-3">
							  	<input type="text" class="form-control" value="curl -s <?php echo e(route('cron.run')); ?>" id="cron--run" aria-describedby="basic-addon2" readonly="">
							 	 <div class="input-group-append pointer">
							    	<span class="input-group-text bg--success text--light" id="basic-addon2" onclick="cronJobRun()"><?php echo e(translate('Copy')); ?></span>
							  	</div>
							</div>
	            		</div>

	            		<div class="mb-3">
	            			<label for="timelocation" class="form-label"><?php echo e(translate('Queue Job In Other Hosting')); ?> <sup class="text--danger">* <?php echo e(translate('Set time for 1 minute')); ?></sup></label>
	            			<div class="input-group mb-3">
							  	<input type="text" class="form-control" value="curl -s <?php echo e(route('queue.work')); ?>" id="queue_url" aria-describedby="basic-addon2" readonly="">
							 	 <div class="input-group-append pointer">
							    	<span class="input-group-text bg--success text--light" id="basic-addon2" onclick="queue()"><?php echo e(translate('Copy')); ?></span>
							  	</div>
							</div>
	            		</div>

	            		<div class="mb-3">
	            			<label for="timelocation" class="form-label"><?php echo e(translate('Queue Job In cPanel')); ?> <sup class="text--danger">* <?php echo e(translate('Set time for 1 minute')); ?></sup></label>
	            			<div class="input-group mb-3">
							  	<input type="text" class="form-control" value="/usr/local/bin/php /home/you_project_location/src/artisan queue:work --stop-when-empty > /dev/null 2>&1" id="queue_cpanel" aria-describedby="basic-addon2" readonly="">
							 	 <div class="input-group-append pointer">
							    	<span class="input-group-text bg--success text--light" id="basic-addon2" onclick="queue_cpanel()"><?php echo e(translate('Copy')); ?></span>
							  	</div>
							</div>
	            		</div>
		            </div>
            	</div>
            </div>
            <div class="modal_button2">
                <button type="button" class="w-100" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="passportKeyGen" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="<?php echo e(route('admin.general.setting.passport.key')); ?>" method="GET">
				<?php echo csrf_field(); ?>
				<div class="modal_body2">
					<div class="modal_icon2">
						<i class="fa-solid fa-key"></i>
					</div>
					<div class="modal_text2 mt-3">
						<h6><?php echo e(translate('You are trying to generate a new passport api key!')); ?></h6>
					</div>
				</div>
				<div class="modal_button2">
					<button type="button" class="" data-bs-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
					<button type="submit" class="bg--success"><?php echo e(translate('Continue')); ?></button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scriptpush'); ?>
<script>
	"use strict";
	(function($){
		$('select[name=country_code]').on('change', function(){
			var value = $(this).val();
			$("#country--dial--code").text(value);
		});

		$('#maintenance_mode').on('click',function (e) {
			var status = $(this).val();
			if($(this).prop("checked") == true){
                $("#maintenance_mode_div").fadeIn();
            }
            else if($(this).prop("checked") == false){
                $("#maintenance_mode_div").fadeOut();
            }
		})
	})(jQuery);

    function cronJobRun() {
        var copyText = document.getElementById("cron--run");
        copyText.select();
        copyText.setSelectionRange(0, 99999)
        document.execCommand("copy");
        notify('success', 'Copied the text : ' + copyText.value);
    }

    function queue() {
        var copyText = document.getElementById("queue_url");
        copyText.select();
        copyText.setSelectionRange(0, 99999)
        document.execCommand("copy");
        notify('success', 'Copied the text : ' + copyText.value);
    }
    function queue_cpanel() {
        var copyText = document.getElementById("queue_cpanel");
        copyText.select();
        copyText.setSelectionRange(0, 99999)
        document.execCommand("copy");
        notify('success', 'Copied the text : ' + copyText.value);
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>