<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	 		<div class="col-lg-12 p-1">
	            <div class="rounded_box">
                	<div class="row align--center px-3">
                		<div class="col-12 col-md-4 col-lg-4 col-xl-5">
                    		<h6 class="my-3"><?php echo e(translate('Set Default Sending Gateway')); ?></h6>
                    	</div>

	                    <div class="col-12 col-md-8 col-lg-8 col-xl-7">
	                		<div class="row justify-content-end">
			                    <div class="col-12 col-lg-6 col-xl-6 px-2 py-1 ">
				                    <form action="<?php echo e(route('admin.sms.default.gateway')); ?>" method="POST" class="form-inline float-sm-right text-end">
				                    	<?php echo csrf_field(); ?>
				                     	<div class="input-group mb-3 w-100">
										  	<select class="form-control" name="sms_gateway" required="">
										  		<?php $__currentLoopData = $smsGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										  			<option value="<?php echo e($gateway->id); ?>" <?php if($general->sms_gateway_id == $gateway->id): ?> selected <?php endif; ?>><?php echo e(strtoupper($gateway->name)); ?></option>
										  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										  	</select>
										  	<button class="btn--primary input-group-text input-group-text" id="basic-addon2" type="submit"><?php echo e(translate('Send SMS Method')); ?></button>
										</div>
							        </form>
							    </div>
							</div>
	                	</div>
	                </div>

	                <div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
		                            <th><?php echo e(translate('Gateway Name')); ?></th>
		                            <th><?php echo e(translate('Status')); ?></th>
		                            <th><?php echo e(translate('Action')); ?></th>
		                        </tr>
		                    </thead>
		                    <?php $__empty_1 = true; $__currentLoopData = $smsGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smsGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			                    <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
				                    <td data-label="<?php echo e(translate('Gateway Name')); ?>">
				                    	<?php echo e(ucfirst($smsGateway->name)); ?>

				                    	<?php if($general->sms_gateway_id == $smsGateway->id): ?>
					                    	<span class="text--success fs-5">
					                    		<i class="las la-check-double"></i>
					                    	</span>
					                    <?php endif; ?>
				                    </td>

				                    <td data-label="<?php echo e(translate('Status')); ?>">
				                    	<?php if($smsGateway->status == 1): ?>
				                    		<span class="badge badge--success"><?php echo e(translate('Active')); ?></span>
				                    	<?php else: ?>
				                    		<span class="badge badge--danger"><?php echo e(translate('Inactive')); ?></span>
				                    	<?php endif; ?>
				                    </td>

				                    <td data-label=<?php echo e(translate('Action')); ?>>
			                    		<a href="<?php echo e(route('admin.gateway.sms.edit', $smsGateway->id)); ?>" class="btn--primary text--light brand" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="las la-pen"></i></a>
				                    </td>
			                    </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			                	<tr>
			                		<td class="text-muted text-center" colspan="100%"><?php echo e(translate('No Data Found')); ?></td>
			                	</tr>
			                <?php endif; ?>
		                </table>
		            </div>
	                <div class="m-3">
						<?php echo e($smsGateways->appends(request()->all())->links()); ?>

					</div>
	            </div>
	        </div>
	    </div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/sms_gateway/index.blade.php ENDPATH**/ ?>