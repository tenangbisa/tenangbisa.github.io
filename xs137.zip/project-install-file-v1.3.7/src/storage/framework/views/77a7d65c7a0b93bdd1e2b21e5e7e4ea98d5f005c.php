<?php $__env->startSection('panel'); ?>
<section class="mt-3">
    <div class="container-fluid p-0">
	    <div class="row">
	 		<div class="col-lg-12">
	            <div class="card mb-4">
	                <div class="responsive-table">
		                <table class="m-0 text-center table--light">
		                    <thead>
		                        <tr>
		                            <th> <?php echo e(translate('Name')); ?></th>
		                            <th> <?php echo e(translate('Image')); ?></th>
		                            <th> <?php echo e(translate('Method Currency')); ?></th>
		                            <th> <?php echo e(translate('Status')); ?></th>
		                            <th> <?php echo e(translate('Action')); ?></th>
		                        </tr>
		                    </thead>
		                    <?php $__empty_1 = true; $__currentLoopData = $manulaPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manulaPayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			                    <tr class="<?php if($loop->even): ?> table-light <?php endif; ?>">
				                    <td data-label=" <?php echo e(translate('Name')); ?>">
				                    	<?php echo e(__($manulaPayment->name)); ?>

				                    </td>

				                    <td data-label=" <?php echo e(translate('Logo')); ?>">
				                    	<img src="<?php echo e(showImage(filePath()['payment_method']['path'].'/'.$manulaPayment->image)); ?>" class="brandlogo">
				                    </td>

				                    <td data-label=" <?php echo e(translate('Currency')); ?>">
				                    	1 <?php echo e($general->currency_name); ?> = <?php echo e(shortAmount($manulaPayment->rate)); ?> <?php echo e(__($manulaPayment->currency->name)); ?>

				                    </td>
				                    <td data-label=" <?php echo e(translate('Status')); ?>">
				                    	<?php if($manulaPayment->status == 1): ?>
				                    		<span class="badge badge--success"> <?php echo e(translate('Active')); ?></span>
				                    	<?php else: ?>
				                    		<span class="badge badge--danger"> <?php echo e(translate('Inactive')); ?></span>
				                    	<?php endif; ?>
				                    </td>
				                    <td data-label= <?php echo e(translate('Action')); ?>>
			                    		<a href="<?php echo e(route('admin.manual.payment.edit',$manulaPayment->id)); ?>" class="btn--primary text--light"><i class="las la-pen"></i></a>

			                    		<a href="javascript:void(0)" class="btn--danger text--light gwdelete"
				                    		data-bs-toggle="modal"
				                    		data-bs-target="#delete"
				                    		data-delete_id="<?php echo e($manulaPayment->id); ?>"
				                    		><i class="las la-trash"></i>
				                    	</a>
				                    </td>
			                    </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			                	<tr>
			                		<td class="text-muted text-center" colspan="100%"> <?php echo e(translate('No Data Found')); ?></td>
			                	</tr>
			                <?php endif; ?>
		                </table>
	            	</div>
	                <div class="m-3">
	                	<?php echo e($manulaPayments->appends(request()->all())->links()); ?>

					</div>
	            </div>
	        </div>
	    </div>
	</div>
	<a href="<?php echo e(route('admin.manual.payment.create')); ?>" class="support-ticket-float-btn">
		<i class="fa fa-plus ticket-float"></i>
	</a>
</section>

<div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        	<form action="<?php echo e(route('admin.manual.payment.delete')); ?>" method="POST">
        		<?php echo csrf_field(); ?>
        		<input type="hidden" name="id" value="">
	            <div class="modal_body2">
	                <div class="modal_icon2">
	                    <i class="las la-trash-alt"></i>
	                </div>
	                <div class="modal_text2 mt-3">
	                    <h6>@ <?php echo e(translate('Are you sure to delete this payment method')); ?></h6>
	                </div>
	            </div>
	            <div class="modal_button2">
	                <button type="button" class="" data-bs-dismiss="modal"> <?php echo e(translate('Cancel')); ?></button>
	                <button type="submit" class="bg--danger"> <?php echo e(translate('Delete')); ?></button>
	            </div>
	        </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('stylepush'); ?>
	<style>
		.brandlogo{
			width: 50px;
		}
	</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scriptpush'); ?>
<script>
	(function($){
       	"use strict";

		$('.gwdelete').on('click', function(){
			var modal = $('#delete');
			modal.find('input[name=id]').val($(this).data('delete_id'));
			modal.modal('show');
		});
	})(jQuery);
</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xsender\src\resources\views/admin/manula_payment/index.blade.php ENDPATH**/ ?>